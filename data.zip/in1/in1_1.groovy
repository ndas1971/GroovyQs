@Grab(group='org.modelcatalogue', module='spreadsheet-builder-poi', version='0.4.1')
@Grab(group='commons-codec', module='commons-codec', version='1.10')
@GrabExclude('org.codehaus.groovy:groovy-all')

import org.modelcatalogue.spreadsheet.query.poi.PoiSpreadsheetCriteria

File file = new File("D:/Desktop/PPT/Groovy/code/recent/latest/toBeShared/data/sales_transactions.xlsx")
def query = PoiSpreadsheetCriteria.FACTORY.forFile(file)
//read sheet
def content = query.query{
    sheet("Sheet1")
 }.sheet
 def rows = content.rows  //get all rows of excel 
 
//account    name    order    sku    quantity    unit price    ext price
@groovy.transform.Canonical
@groovy.transform.ToString(includeNames=true)
class Row{
    Long account    
    String name    
    Long order    
    String sku    
    Long quantity    
    Double unit_price    
    Double ext_price
}
def types =[ Long.class, String.class, Long.class, String.class, Long.class, Double.class, Double.class]
//drop header and read 
def cells = rows.drop(1).collect{it.cells} //get all the cells -> List of List of cell
                .collect{lc ->
                    new Row(*lc.withIndex().collect{c,i -> c.read(types[i])})
                }

//Find mean quantity , unit price, ext price for each order 
def mean(lst){
    return (lst.sum()/lst.size().toDouble()).round(2)
}
def process(Closure pm, lst, String... cols){  //lst = List of Rows 
    return cols.collectEntries{col -> [col, pm(lst.collect{it."$col"})]  }
}
cells.groupBy{it.order}  //[it.order, list of Rows for that order]
     .collectEntries{k, v -> [k,process(this.&mean,v,"quantity" , "unit_price", "ext_price")]}
 
//What percentage of the  total order does each row represent? 
def sum(lst){
    return lst.sum()
}
def order_total = cells.groupBy{it.order}
                   .collectEntries{k,v -> [k, process(this.&sum, v, "ext_price")]}
cells.collect{[it.order, (it.ext_price/order_total[it.order].ext_price).round(2)]}

 
 