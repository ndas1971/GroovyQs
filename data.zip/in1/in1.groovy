def lst = [1,2,3]
def map = [ok:2, 'nok':3]

def fc = { it } //single arg, it is special variable name of that arg
def fc2 = { k, v -> "$k $v"}  //two arg 
//each 
lst.each{ println it}
//findAll 
map.findAll{k,v -> k == 'ok'}
//collect , returns list 
map.collect{k, v -> v}
//collectMany - collect().flatten()
lst.collectMany{ [it, it*it]}
//collectEntries, collect and then to map
lst.collectEntries{[it, it*it]}
//sort/max/min by a key 
lst.sort(false){ it } //false, return a new lst 
lst.max{ it }
lst.min{ it }
map.sort{kv -> kv.value} //kv is Entry
//groupBy 
lst.groupBy{ it % 2}  //returns a map, key=result of closure, value=list of all elements for that key 
//others 
lst.take(2)
lst.drop(1)
lst.head()
lst.first()
lst.tail()
lst.init()
lst.last()
//spread
lst2 = [*lst, *lst]
map2 = [*:map, *:map]


