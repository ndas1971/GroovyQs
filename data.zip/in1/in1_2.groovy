@Grab(group='org.modelcatalogue', module='spreadsheet-builder-poi', version='0.4.1')
@Grab(group='commons-codec', module='commons-codec', version='1.10')
@GrabExclude('org.codehaus.groovy:groovy-all')

import org.modelcatalogue.spreadsheet.query.poi.PoiSpreadsheetCriteria

File file = new File("D:/Desktop/PPT/Groovy/code/recent/latest/toBeShared/data/Nifty-17_Years_Data-V1.xlsx")
def query = PoiSpreadsheetCriteria.FACTORY.forFile(file)
//read sheet
def content = query.query{
    sheet("Sheet1")
 }.sheet
 def rows = content.rows  //get all rows of excel 
 //drop header and read 
 def cells = rows.drop(1).collect{it.cells}
                         .collect{ lc ->
                             [lc.head().read(Date.class),
                             *lc.tail().collect{c ->
                                         c.read(Double.class)
                                     }]
                         }

def result = cells.groupBy{it.first().year}
                  .collectEntries{k,v ->
                      [k+1900, ['max':v.collect{it[1]}.max(), 'min': v.collect{it[1]}.min()]]
                  }.max{kv -> kv.value['max'] - kv.value['min']}

def result2 = cells.groupBy{it.first().year}
                  .collectEntries{k,v ->
                      [k+1900, [max:v*.getAt(1).max(), min: v*.getAt(1).min()]]
                  }.max{kv -> kv.value.max - kv.value.min}
