Q: Given Nifty-17_Years_Data-V1.xlsx
Which is 17 years of Nifty data with Open, Close etc index 
Find out the year when stock market was crashed
(ie, year where change in maximum and minimum of Open index was maximum accross all years) 
Use functional techniques 
The excel is present in data directory 

Other libs are used 
For CSV 
@Grab('com.xlson.groovycsv:groovycsv:1.3')
import static com.xlson.groovycsv.CsvParser.parseCsv
import com.xlson.groovycsv.CsvIterator

For Excel 
@Grab(group='org.modelcatalogue', module='spreadsheet-builder-poi', version='0.4.1')
@Grab(group='commons-codec', module='commons-codec', version='1.10')
@GrabExclude('org.codehaus.groovy:groovy-all')

import org.modelcatalogue.spreadsheet.query.poi.PoiSpreadsheetCriteria


