1. Closure
2. Functional programming with List and Map
3. usage of external lib in gradle
Last two hrs: They need to redo the exercise again
4. Next assignment discussion 
---------------------------------------------
///* closure 
def fxc = {int xi -> println xi }
fxc = { println it }   //same as above 

fxc = { -> println "NoArgs"} // no Arg 

//no overloading of closure as variable 'fxc' gets overritten 
//can have multiline , don't use {} as it's closure syntax 
//last line is return 
fxc = { def xi1 -> 
            println "def" 
            xi1*2          
       }
fxc(2)
fxc(2.0)

//with default 
def f = {  x, y=2 -> x+y }
f(2)
f(2,3)

//the Java approach which prevents obscuring a variable in a nested scope 
//local variable can hide field, but not another local variable in nested scope
//nOte closure has local scope with above caveat 
//Means you can not do below 
def x = 5 
def get = { x -> x } //The current scope already contains a variable of the name x
//or 
def get = { p ->
            def x = p  //The current scope already contains a variable of the name x
            x}




///**** Groovy Functional with Collections
//map is called 'collect', filter is called 'findAll' , reduce is called 'inject'
//flatMap is called 'collectMany', sort is called 'sort'
//zip is called transpose, slide is called collate 
//Mapping of List to Map by collectEntries with map closure(outputs list of two elements)

//Conversions are toMap(), toSet(), toList() etc 


//For Map, closure takes one arg(Entry, .key, .value) or two k,v args(for allmost all, but check reference)
//For List,set, Closure takes one (each element) arg 
//For index operation , closure takes two, each_element, index arg 




//empty 
//list
lste = []
//Set 
sete = [] as Set 
//map 
mape = [:]

//Empty checking 
//list
lste.empty
lste.isEmpty()
//Set 
sete.empty 
sete.isEmpty()
//map 
mape.isEmpty()  //Note mape.empty would not work as empty would be taken as keyword 

//NonExistence member return null 
//list
lste[20] == null
//Set 
NA
//map 
mape["new"] == null 
mape.new == null 
def var = "new"
mape."$var" == null 

//creation
//list
lst = [1,2,3]
lst2 = [[1,2,3], [3,4,5]]
//Set 
set = [1,2,3,1,2] as Set 
//map 
map = [ 'ok': 2, nok:3]


//length 
//list
lst.size()
//Set 
set.size() 
//map 
map.size()

//containment checking 
//list
2 in lst 
//Set 
2 in set 
//map 
'ok' in map 

//append 
//list
lst.add(3)
lst << 3 
lst + [ 3,4]
lst += [3]

//Set 
set.add(4)
set << 5 
set += [6]

//map , no add method 
map << ['new': 6]
map += ['ko': 4]


//get/set/slice 
//list
lst[0] 
lst[0] = 20 
lst[0..2]
lst[0..<2]


//Set 
NA
//map 
map.ok 
map['ok']
map['oks'] = 20 //creation of new key 
map['ok'] = 2 //update

//each - return same collections again 
//list
lst.each{
    println it 
}
lst2.each{ x,y,z -> println x} 

//Set 
set.each{
    println it 
}
//map 
map.each{  
    println "${it.key} ${it.value}"
}
map.each{ k,v -> 
    println v 
}


//collect - returns new collections (map)
//list 
lst.collect{
    it*it
}
lst2.collect{ x,y,z -> x*x} 

//Set - result is List, use .toSet() to convert to Set 
set.collect{
    it*it 
}
//OR 
set.collect(new HashSet()){
    it*it
} //now result is set 
//map - result is list  , Use collectEntries to get a Map 
map.collect{  
    it
}//list of Entry 
map.collect{ k,v -> 
    v
}

//conversions 
//to list
set.toList()
map.collect{ it }
lst.collect{it}
//to Set 
lst.toSet()
map.collect(new HashSet()){ it }
set.collect(new HashSet()){it}
//map 
lst.collectEntries{ [it, it] }
set.collectEntries{ [it, it] }
map.collectEntries{ [it.key, it.value]}
map.collectEntries{k,v -> [k,v]}


//collectMany(flatmap), collect{}.flatten()
//list
lst.collectMany{
    [it*it]
}
lst2.collectMany{ x,y,z -> [x*x]} 

//Set - result is List, use .toSet() to convert to Set 
set.collectMany{
    [it*it] 
}
//OR 
set.collectMany(new HashSet()){
    [it*it]
} //now result is set 
//map - result is list  , Use collectEntries to get a Map 
map.collectMany{  
    [it]
}//list of Entry 
map.collectMany{ k,v -> 
    [v]
}


//findAll 
//list
lst.findAll{
    it > 1
}
lst2.findAll{ x,y,z -> x > 1} 

//Set - 
set.findAll{
    it > 1
}

//map - 
map.findAll{  
    it.key == 'ok'
}
map.findAll{ k,v -> 
    k == 'ok'
}




//inject 
//list - no destructuring 
lst.inject(0){r, e ->
    r+e
}
lst2.inject(0){ r, e -> r+e[0]} 

//Set - 
set.inject(0){r, e ->
    r+e
}

//map - 
map.inject(0){r, kv ->
    r+kv.value
}
map.inject(0){r, k,v ->
    r+v
}



//groupBy 
//list
lst.groupBy{
    it % 2 
}
lst2.groupBy{ x,y,z -> x% 2 } 
//can be multiple for subgroups
lst.groupBy({it % 2 }, {it%3})

//Set - 
set.groupBy{
    it % 2 
}

//map - 
map.groupBy{  
    it.value % 2 
}
map.groupBy{ k,v -> 
    v % 2 
}



//withIndex 
//list
lst.withIndex().each{ e, i ->
    println i 
}
lst2.withIndex().each{ e, i ->
    println i 
}
//Set - works, but what is the order?
set.withIndex().each{e, i ->
    println i 
}

//map - 
NA 


//transpose
//list
[lst, lst2].transpose() // [[1, [1, 2, 3]], [2, [3, 4, 5]]]

//Set , Map
NA  


//Sort by key , Max by and min by 
//list
lst.sort(false){  //false means return new copy 
    it 
}
lst2.sort(false){ e -> e[0]} 
//two arg means comparator version , must return -1,0,1
lst.sort(false){ e1, e2 ->
    e1 <=> e2
}
//reverse 
lst.sort(false){ e1, e2 ->
    e2 <=> e1
}
//or 
lst.toSorted{e1, e2-> e1 <=> e2}
lst.toSorted{it}
lst.toUnique{it}  //unique based on some condition 
lst.max{it}
lst.min{it}
lst.max{a, b -> a <=> b}
lst.min{a, b -> a <=> b}

//Set - result is List 
set.sort(false){ it} 

//map - always immutable , return SortedMap 
map.sort{ it.key} 
map.sort{entry1, entry2 -> entry1.value <=> entry2.value} 
map.toSorted{ it.key} 
map.toSorted{entry1, entry2 -> entry1.value <=> entry2.value} 
//return entry from below methods 
map.max{it.key}
map.min{it.key}
map.max{entry1, entry2 -> entry1.value <=> entry2.value} 
map.min{entry1, entry2 -> entry1.value <=> entry2.value}


//Take/drop 
//list
lst.take(2)
lst.drop(1)
//Set - which order?
set.take(2)
set.drop(1)
//map - which order?
map.take(2)
map.drop(1)

//head, tail, init, last, first
//list
lst.head()
lst.tail()
lst.first()
lst.last()
lst.init()
//Set , Map 
NA 






///*** Groovy CSV 
compile 'org.xerial:sqlite-jdbc:3.7.2'
compile 'com.xlson.groovycsv:groovycsv:1.3'

//Example iris.csv 
@Grab('com.xlson.groovycsv:groovycsv:1.3')
import static com.xlson.groovycsv.CsvParser.parseCsv
import com.xlson.groovycsv.CsvIterator


//for(line in parseCsv(new FileReader('D:/PPT/Groovy/data/iris.csv'))) {
//    println "$line.SepalLength,$line.SepalWidth,$line.PetalLength,$line.PetalWidth,$line.Name"
//}

@groovy.transform.Canonical     //toString, hash, equals, tuple constructor 
@groovy.transform.Sortable       //compareTo and compatorByFIELD based on Order 
@groovy.transform.ToString(includeNames=true)
@groovy.transform.AutoClone
class Iris implements Serializable{
    double sl
    double sw
    double pl 
    double pw 
    String name 
    def toList() {
        return [this.sl, this.sw, this.pl, this.pw , this.name]
    }
}

class CsvIteratorToIrisIterator {                                
    static Iterator toIris (CsvIterator self) {        
        return [hasNext: self.&hasNext, next: { 
            def line = self.next() 
            new Iris(line.SepalLength.toDouble(), 
                line.SepalWidth.toDouble(), 
                line.PetalLength.toDouble(), 
                line.PetalWidth.toDouble(), 
                line.Name)        
        }] as Iterator 
    }
}
def csviterator = parseCsv(new File('data/iris.csv').newReader())
def csvlist
use (CsvIteratorToIrisIterator)  {
   csvlist =csviterator.toIris().toList()
}
csvlist.each{println it}

csvlist.collect{it.name}.toSet().each{println it} //uique name 
csvlist.findAll{it.name == "Iris-setosa"}.collect{it.sl}.max()
csvlist.groupBy{it.name}.collectEntries{k,v -> 
    [k, ['max': v.collect{it.sl}.max()]] }.each{println it} 


///Another example 
:Attribute Information (in order):
    - CRIM     per capita crime rate by town
    - ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
    - INDUS    proportion of non-retail business acres per town
    - CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
    - NOX      nitric oxides concentration (parts per 10 million)
    - RM       average number of rooms per dwelling
    - AGE      proportion of owner-occupied units built prior to 1940
    - DIS      weighted distances to five Boston employment centres
    - RAD      index of accessibility to radial highways
    - TAX      full-value property-tax rate per $10,000
    - PTRATIO  pupil-teacher ratio by town
    - B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
    - LSTAT    % lower status of the population
    - MEDV     Median value of owner-occupied homes in $1000s

"crim", "zn",   "indus", "chas", "nox",  "rm",  "age",  "dis",  "rad", "tax", "ptratio", "b",   "lstat","medv"
0.00632, 18,     2.31,    "0",    0.538,  6.575, 65.2,   4.09,  1,      296,   15.3,      396.9, 4.98,   24

1. read data in boston 

2. Create a column crimxmedv = crim X medv 

3. select columns crimxmedv , tax 

4. what is the max value of crim 


5. what is max value of medv 

5. select rows of crim where medv is max 


6. select rows of medv where crim is max 


7. how many unique value in chas and rad 
7.1 How many chas in  each of chas value 

8. what is max and min value of medv for each chas 


9. put crimxmedv and tax in csv 


**ANS 
1. read data in boston 

@Grab('com.xlson.groovycsv:groovycsv:1.3')
import static com.xlson.groovycsv.CsvParser.parseCsv
import com.xlson.groovycsv.CsvIterator
import com.xlson.groovycsv.PropertyMapper



class Row implements Serializable{
    PropertyMapper data  //data.columns is Map[columnName:index], data.values [columnValues]
    Map dataType = [chas: {it.toString()} ]
    Closure defaultFn = { it.toDouble() }
    Map othercolumns = [:]
    
    def convert(String name, value){
        if (name in dataType){
            return dataType[name](value)
        }
        else {
            return defaultFn(value)
        }
    }
    String toString(){
        "Row(" + data.columns
                     .collectEntries{kv -> [kv.key, convert(kv.key, data.values[kv.value])]}
                     .toString() + othercolumns.toString()+")"
    }    
    //Setting 
    def propertyMissing(String name, value) { 
        othercolumns[name] = value          
    }      
    //getting 
    def propertyMissing(String name) { 
        othercolumns[name] ?: convert(name, data."$name") 
    }           
}
class CsvIteratorToRowIterator {                                
    static Iterator toRow (CsvIterator self) {        
        return [hasNext: self.&hasNext, next: { 
            def line = self.next() 
            new Row(data:line)        
        }] as Iterator 
    }
}
def csviterator = parseCsv(new File('data/boston.csv').newReader())
def csvlist
use (CsvIteratorToRowIterator)  {
   csvlist =csviterator.toRow().toList()
}
csvlist.each{println it}
  
2. Create a column crimxmedv = crim X medv 
csvlist.each{ it.crimxmedv = it.crim * it.medv}

3. select columns crimxmedv , tax 
csvlist.collect{ [it.crimxmedv, it.tax] }
   
4. what is the max value of crim 
csvlist.collect{it.crim }.max()

mc = csvlist.collect{it.crim }.max()

5. what is max value of medv 
mm = csvlist.collect{it.medv }.max()

5. select rows of crim where medv is max 
csvlist.findAll{ it.medv == mm }.collect{it.crim}

6. select rows of medv where crim is max 
csvlist.findAll{ it.crim == mc }.collect{it.medv}

7. how many unique value in chas and rad 
csvlist.collect{it.chas }.unique()
csvlist.collect{it.rad }.toSet()
7.1 How many chas in  each of chas value 
csvlist.groupBy{ it.chas }.collectEntries{k,v -> [k, v.size]}

8. what is max and min value of medv for each chas 
csvlist.groupBy{ it.chas }.collectEntries{k,v -> [k, [max:v.collect{it.medv}.max(), min:v.collect{it.medv}.min()]] }

9. put crimxmedv and tax in csv 
File file = new File('output.csv')
file << "crimxmedv,tax\r\n" 
csvlist.each { file << "${it.crimxmedv.round(2)},${it.tax}\r\n"}
//overwrites 
file.newWriter().withWriter { w ->
  w << "crimxmedv,tax\r\n" 
  csvlist.each { w << "${it.crimxmedv.round(2)},${it.tax}\r\n"}
}
  
  
/////////////////////////////////////
///*** Groovy XLS 
  
   
//in Gradle 
import builders.dsl.spreadsheet.builder.poi.PoiSpreadsheetBuilder

@Grab(group='org.modelcatalogue', module='spreadsheet-builder-poi', version='0.4.1')
// fixes bugs on Groovy 2.4.x
@Grab(group='commons-codec', module='commons-codec', version='1.10')
@GrabExclude('org.codehaus.groovy:groovy-all')

import org.modelcatalogue.spreadsheet.api.Cell
import org.modelcatalogue.spreadsheet.builder.poi.PoiSpreadsheetBuilder
import org.modelcatalogue.spreadsheet.query.api.SpreadsheetCriteria
import org.modelcatalogue.spreadsheet.query.poi.PoiSpreadsheetCriteria

File file = new File('spreadsheet.xlsx')

PoiSpreadsheetBuilder.INSTANCE.build {                                                  // <1>
    sheet('Sample') {                                                                   // <2>
        row {                                                                           // <3>
            cell 'A'                                                                    // <4>
            cell 'B'
            cell 'C'
        }
        row {
            cell 1
            cell 2
            cell 3
        }
    }
} writeTo file     
  
 
///Example 
@Grab(group='org.modelcatalogue', module='spreadsheet-builder-poi', version='0.4.1')
// fixes bugs on Groovy 2.4.x
@Grab(group='commons-codec', module='commons-codec', version='1.10')
@GrabExclude('org.codehaus.groovy:groovy-all')

import org.modelcatalogue.spreadsheet.query.poi.PoiSpreadsheetCriteria

File file = new File("data/sales_transactions.xlsx")
def query = PoiSpreadsheetCriteria.FACTORY.forFile(file)
            
def content = query.query {
 sheet('Sheet1')
}.sheet
//println(content)
def rows = content.rows 
//drop header row 
//account	name	order	sku	quantity	unit price	ext price
@groovy.transform.Canonical 
@groovy.transform.ToString(includeNames=true)
class Row {
    Long account	
    String name	
    Long order	
    String sku	
    Long quantity	
    Double unit_price	
    Double ext_price
}
def types = [Long.class , String.class, Long.class, String.class, Long.class, Double.class, Double.class]


def cells = rows.drop(1)
                .collect{it.cells}
                .collect{lc -> new Row(
                                    *lc.withIndex().collect{c,i -> c.read(types[i])}
                                )}
                

//println(cells.size())
//println(cells.first())

//Find mean quantity , unit price, ext price for each order 
def mean(lst){
    return (lst.sum()/lst.size.toDouble()).round(2)
}
def process(Closure pm, lst, String... cols){
    def out = [:]
    for (col in cols){
        out[col] = pm(lst.collect{it."$col"})
    }
    return out 
    //return cols.collectEntries{[it, pm(lst.collect{it."$col"})]}
}
cells.groupBy{it.order}
     .collectEntries{k,v -> [k, process(this.&mean, v, "quantity", "unit_price", "ext_price")]}


//Q= "What percentage of the  total order does each row represent?"
def sum(lst){
    return lst.sum()
}
order_total = cells.groupBy{it.order}
     .collectEntries{k,v -> [k, process(this.&sum, v, "ext_price")]}
     
cells.collect{(it.ext_price/order_total[it.order].ext_price).round(2)}



//HandsOn 
//If Grape fails, then check 
//https://stackoverflow.com/questions/16871792/groovy-grab-download-failed?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
//or use gradle 
@Grapes([
   @GrabResolver(name='jcenter', root='https://jcenter.bintray.com/'),
   @Grab('builders.dsl:spreadsheet-builder-poi:1.0.5'),
   @Grab('builders.dsl:spreadsheet-builder-groovy:1.0.5')])
   
//in gradle    
@Grab(group='org.modelcatalogue', module='spreadsheet-builder-poi', version='0.4.1')
// fixes bugs on Groovy 2.4.x
@Grab(group='commons-codec', module='commons-codec', version='1.10')
@GrabExclude('org.codehaus.groovy:groovy-all')

import org.modelcatalogue.spreadsheet.query.poi.PoiSpreadsheetCriteria

def filename = "data/Nifty-17_Years_Data-V1.xlsx"
File file = new File(filename)
def query = PoiSpreadsheetCriteria.FACTORY.forFile(file)                
def content = query.query {
 sheet('Sheet1')
}.sheet
//println(content)
def rows = content.rows 
//drop header row 
def cells = rows.drop(1).collect{it.cells}.collect{ lc -> [lc.head().read(Date.class), *lc.tail().collect{c -> c.read(Double.class)} ]}
//println(cells.size())
//println(cells.first())
def result = cells.groupBy{ it.first().year}.collectEntries{k,v -> [k, v.collect{l -> l[1]}.max()]}
println(result)
def result2 = cells.groupBy{ it.first().year}.collectEntries{k,v -> [k+1900, ['max': (1..4).toList().collect{i-> v.collect{l -> l[i]}.max()} ]]}
//println(result2)  
//which year max change in Open 
def result3 = cells.groupBy{ it.first().year}.collectEntries{k,v -> [k+1900, ['max': v.collect{l -> l[1]}.max(), 'min':v.collect{l -> l[1]}.min() ]]}
println(result3.max{kv -> kv.value['max']-kv.value['min']})
 



///*** GROOVY JSON 

import groovy.json.*
def slurper = new JsonSlurper()
def result = slurper.parse(new File('emp.json'))

//note 
result.details.firstName   //GPATH and all first name 
//Any time , break nested GPATH with one of List methods eg .collect, .findAll, etc 
//closures of these method take that element's value on which the method is called 
json.details.collect{it.firstName}  //here it is 'details' value 
//and again GPATH can be started 
result.collect{ it.details}.firstName  //here it is each element of root array
//Full Name 
result.details.collect{ it.firstName + it.lastName } //here it is 'details' value 
//Office phone number , here ar is 'phoneNumbers' value ie an array
result.details.phoneNumbers.collectMany { ar -> 
    ar.findAll{ it.type =="office"}.collect{ it.number}}
result.details.phoneNumbers.collectMany { ar -> 
    ar.findAll{ it.type =="office"}.number }

///Pretty print 
groovy.json.JsonOutput.prettyPrint(String jsonPayload) 
groovy.json.JsonOutput.toJson(Object object)
groovy.json.JsonOutput.toJson(Map m)

///* JsonBuilder

//from objects 
import groovy.json.*

class Me {
    String name
}

def o = new Me( name: 'tim' )

println new JsonBuilder( o ).toPrettyString()

//OR from builtin list/map
def in1 = [ok : 2 , nok : 3]
def li = [in1: [in2: in1.clone()]]

import groovy.json.* 
def b = new JsonBuilder(li)
def s = b.toPrettyString()
def lii = new JsonSlurper().parseText(s)
lii.in1.in2.ok = 20
lii
li


//OR directly 
def contact = [ 
    [ getFirstName : 'A' , getLastName :  'B' , getTitle :  'C'  ], 
    [ getFirstName :  'D' , getLastName :  'E' , getTitle :  'F'  ], 
    [ getFirstName :  'G' , getLastName :  'H' , getTitle :  'I'  ]     
]

def jsonBuilder = new groovy.json.JsonBuilder()
//Map with key contacts having another map 
jsonBuilder {
    onekey  'one value'
    onearray 120,133,134 
    oneobject {
                onekey 'onevalue'
        }
    contacts contact.collect { 
        [ 
            FirstName: it.getFirstName, 
            LastName: it.getLastName, 
            Title: it.getTitle 
        ] 
    }
}

println jsonBuilder.toPrettyString()
//array of Maps 
jsonBuilder(
    contact.collect { 
        [ 
            FirstName: it.getFirstName, 
            LastName: it.getLastName, 
            Title: it.getTitle 
        ]
    }
)
//Array of map with key contact and value is another map 
jsonBuilder(
    contact.collect { 
        [ 
            contact : [ 
                FirstName: it.getFirstName, 
                LastName: it.getLastName, 
                Title: it.getTitle
            ] 
        ]
    }
)




///*** Groovy XML - groovy.util and groovy.xml 
//groovy.util.XmlParser and groovy.util.XmlSlurper
//Use parseText(string) or parse(File)

//Both Support GPATH

//Both are based on SAX so they both are low memory footprint


//XmlSlurper.parse retuns GPathResult, use .element  to get text 
    
//XmlSlurper evaluates the structure lazily. 
//So if you update the xml you’ll have to evaluate the whole tree again.

//If you just have to read a few nodes XmlSlurper should be your choice, 
//since it will not have to create a complete structure in memory

//XMLSlurper does not require ns , but XMLParser requires ns like 'x:tag'
        
        
//XmlParser.parse returns Node , use element.text() to get text 
//If you want to update and read at the same time then XmlParser is the choice.

//XmlParser , NodeList is List of Node, hence has .collect/.findAll etc 
boolean append(Node child) //Appends a child to the current node. 
Node appendNode(Object name) //Creates a new node as a child of the current node.
Node appendNode(Object name, Map attributes) 
Node appendNode(Object name, Map attributes, Object value) 
Node appendNode(Object name, Object value) 
void plus(Closure c) //Adds sibling nodes (defined using builder-style notation via a Closure) after the current node.
boolean remove(Node child) 
Node replaceNode(Closure c) 
Node replaceNode(Node n) 

Object attribute(Object key) 
Map attributes() 
List children() 
Object clone() 

Object get(String key) 
NodeList getAt(QName name)   //http://docs.groovy-lang.org/latest/html/api/groovy/xml/QName.html
Iterator iterator() 

Object name() 
Node parent() 
String text() 
String toString()  
Object value() 

void print(PrintWriter out) 
void setParent(Node parent) 
void setValue(Object value) 




///GPath
//a.b.c → for XML, yields all the <c> elements inside <b> inside <a>
//a.b.c → all POJOs, yields the <c> properties for all the <b> properties of <a> (sort of like a.getB().getC() in JavaBeans)

//a["@href"] → the href attribute of all the a elements
//a.'@href' → an alternative way of expressing this
//a.@href → an alternative way of expressing this when using XmlSlurper

String books = '''
    <response version-api="2.0">
        <value>
            <books>
                <book available="20" id="1">
                    <title>Don Xijote</title>
                    <author id="1">Manuel De Cervantes</author>
                </book>
                <book available="14" id="2">
                    <title>Catcher in the Rye</title>
                   <author id="2">JD Salinger</author>
               </book>
               <book available="13" id="3">
                   <title>Alice in Wonderland</title>
                   <author id="3">Lewis Carroll</author>
               </book>
               <book available="5" id="4">
                   <title>Don Xijote</title>
                   <author id="4">Manuel De Cervantes</author>
               </book>
           </books>
       </value>
    </response>
'''

//Simply traversing the tree
def response = new XmlParser().parseText(books)
def authorResult = response.value.books.book[0].author
authorResult.text() // 'Manuel De Cervantes'

def book = response.value.books.book[0] 
def bookAuthorId1 = book.@id 
def bookAuthorId2 = book['@id'] 

bookAuthorId1.toInteger() //1 

//Some more , it is node , books is NodeList 
response.value.books.collectMany { it.book.'@id' }
response.value.books.book.collect{ it.'@id' }
//or 
response.value.books.book.'@id' 
response.value.books.book.title.text() //all text together , String
response.value.books.book.title*.text() //list of all texts, List 
response.value.books.book.findAll{ it.'@id'.toInteger()  >= 2}.title*.text()
//OR search any descendents , this would iterate all Node 
response.'**'.each{println it}
//for it.author.'@id' is only valid for book Node and author node, rest would be filtered out 
response.'**'.findAll{ it.name()== 'author' && it.'@id'.toInteger() > 2}*.text()



///With NameSpace 

/*
<?xml version="1.0" ?>
<bib:bibliography xmlns:bib="http://bibliography.org"
  xmlns:lit="http://literature.org">
  <bib:author >William Shakespeare</bib:author>
  <lit:play>
    <lit:year>1589</lit:year>
    <lit:title lang='Eng'>The Two Gentlemen of Verona.</lit:title>
  </lit:play>
  <lit:play>
    <lit:year>1594</lit:year>
    <lit:title lang='ita'>Love's Labour's Lost.</lit:title>
  </lit:play>
  <lit:play>
    <lit:year>1594</lit:year>
    <lit:title lang='Eng'>Romeo and Juliet.</lit:title>
  </lit:play>
  <lit:play>
    <lit:year>1595</lit:year>
    <lit:title lang='esp'>A Midsummer-Nights Dream.</lit:title>
  </lit:play>
</bib:bibliography>


*/



//bibliography becomes 'bibliography' root element from xml file 

//import groovy.util.*
def xmlSource = new File('data/example.xml')

def bibliographyP = new XmlParser().parse(xmlSource) // type is groovy.util.Node

// OR with Parser , must have FQN, Returns groovy.util.Node, hence text() method is needed
//
println bibliographyP.'bib:author'.text()
println bibliographyP.'lit:play'.'lit:title'*.text() //result is list 

// OR with Parser, searches child of play , Here it is play 
bibliographyP.'lit:play'
    .findAll { it.'lit:year'.text().toInteger() > 1592 }
    .each { println it.'lit:title'.text() }


//Using spread operator
bibliographyP.'lit:play'*.'lit:title'*.@lang.flatten()  //
// or GPATH way   
bibliographyP.'lit:play'.'lit:title'.@lang  //[Eng, ita, Eng, esp]
//size 
bibliographyP.'lit:play'.size()


//search across all the nodes of the document 
//(as opposed to a specific set of children, such as play), 

//seraching from root, we are looking for only element which has .title ie play element 
bibliographyP.'**'.findAll {                           
  it.'lit:title'.text().contains('Dream')  //text() is must, also note all childrens are searched (including author, hence .toInterger() would create problem)
}.each {                                
  println "- ${it.'lit:title'.text()}"
}

bibliographyP.'**'.findAll{ n ->
   def v = null
    try{
       v = n.'lit:year'.text().toInteger()
    }
    catch(Exception){
    }
    v > 1593 //null safe 
} .collect { it.'lit:title'.text() }

///HandsOn - country.xml 


def data = new XmlParser().parse(new File(/data\country.xml/))

//All ranks 
data.country.rank*.text()*.toInteger()
//All names 
data.country*.@name
//Country name vs neighbor names 
data.country.collectEntries{ [it.@name , it.'**'.findAll{n -> n.name() == 'neighbor'}*.@name]} 
//OR 
data.country.collectEntries{ [it.@name , it.neighbor*.@name]} 

///Pretty print 
//Note groovy.xml.XmlUtil.serialize
static String serialize(GPathResult node) 
static String serialize(Node node)   //Use this to convert to string 
static String serialize(String xmlString) 
static String serialize(Writable writable) //Return a pretty String version of the XML content produced by the Writable.



///* XMLBuilder
import groovy.xml.*
def writer = new StringWriter()
def xml = new MarkupBuilder(writer)

xml.bibliography {                                    // each closure creates sub section
          author 'William Shakespeare'                 //each method becomes xml tag
          play {
            year '1595'
            title 'A Midsummer-Night Dream.'
            status(['private':true], 'pendding')   //attributes in map
          }
        }

println writer

//With Namespace 
import groovy.xml.*
def writer = new StringWriter()
def xml = new MarkupBuilder(writer)
xml.'rec:records'('xmlns:rec': 'http://groovy.codehaus.org') {
  'rec:car'(name:'HSV Maloo', make:'Holden', year:2006) {
    country('Australia')
    record(type:'speed', ' Truck with speed of 271kph')
  }
}
def str = groovy.xml.XmlUtil.serialize(writer.toString() )  

//Another example 
def xmlWriter = new StringWriter()
def xmlMarkup = new MarkupBuilder(xmlWriter)

xmlMarkup
    .'x:movies'('xmlns:x':'http://www.groovy-lang.org') {
        (1..3).each { n -> 
            'x:movie'(id: n, "the godfather $n")
            if (n % 2 == 0) { 
                'x:movie'(id: n, "the godfather $n (Extended)")
            }
        }
    }

def movies = new XmlParser()
        .parseText(xmlWriter.toString())
        .declareNamespace(x:'http://www.groovy-lang.org')

assert movies.'x:movie'.size() == 4
assert movies.'x:movie'*.text().every { name -> name.startsWith('the')}
def str = groovy.xml.XmlUtil.serialize(movies ) 





///* Updating XML 
//XmlSlurper evaluates the structure lazily. 
//After Update, parse again 
//http://groovy-lang.org/processing-xml.html
//http://docs.groovy-lang.org/latest/html/api/groovy/xml/QName.html
//http://docs.groovy-lang.org/latest/html/api/groovy/util/Node.html

//Modifying a node 
def xml = """
<response version-api="2.0">
    <value>
        <books>
            <book id="2">
                <title>Don Xijote</title>
                <author id="1">Manuel De Cervantes</author>
            </book>
        </books>
    </value>
</response>
"""
//Note for Parser, you must use 'namespace:tag' if it has namespace, (check above)
def response = new XmlParser().parseText(xml)

/* Use the same syntax as groovy.xml.MarkupBuilder */
response.value.books.book[0].replaceNode{ 
   book(id:"3"){
       title( response.value.books.book[0].title.text())
       author(id:"3","Harper Lee")
   }
}
response.@numberOfResults = "2"  //adding one attribute 
response.value.books.book[0].appendNode(  //appending one node
    new groovy.xml.QName("http://literature.org", "numberOfResults", "lit"), //QName(String localPart) , QName(String namespaceURI, String localPart, String prefix) 
    [:],  //attributes as map 
    "1"  //value 
)
def str = groovy.xml.XmlUtil.serialize(response)  //get String value 

//Result 
 <?xml version="1.0" encoding="UTF-8"?><response version-api="2.0" numberOfResults="2">
  <value>
    <books>
      <book id="3">
        <title>Don Xijote</title>
        <author id="3">Harper Lee</author>
        <lit:numberOfResults xmlns:lit="http://literature.org">1</lit:numberOfResults>
      </book>
    </books>
  </value>
</response>




///*** Http rest api with HTTPBuilder 
//build.gradle 
compile 'io.github.http-builder-ng:http-builder-ng-core:1.0.3' 

//Some default parsers are provided:
HTML (when either the 'org.jsoup:jsoup:' or 'net.sourceforge.nekohtml:nekohtml:' library is on the classpath),
JSON (when either Groovy or the com.fasterxml.jackson.core:jackson-databind:2.8.1 library is on the classpath)
CSV (when the com.opencsv:opencsv:3.8 library is on the classpath)
XML (without any additional libraries, XMLSlurper)
TEXT (without any additional libraries)

//Sending GET 
def result = configure {
    request.uri = 'http://httpbin.org/get'
}.get {
    request.uri.query = [id: '234545', label: 'something interesting']
}
result  //Parsed json , groovy object 
//Posting json content 
@Grab('io.github.http-builder-ng:http-builder-ng-core:1.0.3')
import static groovyx.net.http.HttpBuilder.configure


def result = configure {
    request.uri = 'http://httpbin.org/'
    request.contentType = 'application/json'//, http://javadox.com/org.codehaus.groovy.modules.http-builder/http-builder/0.6/groovyx/net/http/ContentType.html#JSON
}.post {
    request.uri.path = '/post'
    request.body = [id: '234545', label: 'something interesting']
}
result  //Parsed json , groovy object 

///Example - REST 
https://api.openweathermap.org/data/2.5/forecast?q=London,us&mode=xml&units=metric&appid=d86ca3beb3c8bf8cce8409a0da74b4c9
https://api.openweathermap.org/data/2.5/forecast?q=HYDERABAD,IN&mode=json&units=metric&appid=d86ca3beb3c8bf8cce8409a0da74b4c9

//With query params 
@Grab('io.github.http-builder-ng:http-builder-ng-core:1.0.3')
@GrabExclude('org.codehaus.groovy:groovy-all')
import static groovyx.net.http.HttpBuilder.configure

def location = "HYDERABAD,IN"
def result = configure {
        request.uri = 'https://api.openweathermap.org/data/2.5/forecast'
    }.get {
        request.uri.query = [q: location, mode:'json', units:'metric', appid:'d86ca3beb3c8bf8cce8409a0da74b4c9']
    }   
result //parsed json 
groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(result)) //Pretty print 


@groovy.transform.ToString(includeNames=true)
class Row{
    Date dt   //.date, .year, .month, .time, .day, .hours, .minutes, .seconds, boolean after(Date when),boolean before(Date when)
    Float temp 
    Float temp_min 
    Float temp_max 
    String text 
    Row(String... args){  //for XML        
        if (args[0].contains("T")){
            def format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
            this.dt =format.parse(args[0])
            } else {
            this.dt = new Date(args[0].toLong() *1000)
        }
        this.temp = args[1].toFloat()
        this.temp_min = args[2].toFloat()
        this.temp_max = args[3].toFloat()
        this.text = args[4]
    }
    Row(Object... args){  //for JSON
        this(*args.collect{it.toString()})
    }
}

def rows = result.list.collect{ new Row(it.dt , 
            it.main.temp ,
            it.main.temp_min,
            it.main.temp_max,
            it.weather[0].description) }
rows.groupBy{it.dt.date}.collectEntries{k, v -> [k, [
                                min: v.collect{it.temp_min}.min(),
                                max: v.collect{it.temp_max}.max(),
                                text: v.head().text
                                ]]}
'''
//list.dt Time of data forecasted, unix, UTC
//JSON output 
{"city":{"id":1851632,"name":"Shuzenji",
"coord":{"lon":138.933334,"lat":34.966671},
"country":"JP",
"cod":"200",
"message":0.0045,
"cnt":38,
"list":[{
        "dt":1406106000,
        "main":{
            "temp":298.77,
            "temp_min":298.77,
            "temp_max":298.774,
            "pressure":1005.93,
            "sea_level":1018.18,
            "grnd_level":1005.93,
            "humidity":87,
            "temp_kf":0.26},
        "weather":[{"id":804,"main":"Clouds","description":"overcast clouds","icon":"04d"}],
        "clouds":{"all":88},
        "wind":{"speed":5.71,"deg":229.501},
        "sys":{"pod":"d"},
        "dt_txt":"2014-07-23 09:00:00"}
        {"dt":....  }
        ...
]}
'''
//XML
def location = "HYDERABAD,IN"
def result = configure {  //XMLSlurper
        request.uri = 'https://api.openweathermap.org/data/2.5/forecast'
    }.get {
        request.uri.query = [q: location, mode:'xml', units:'metric', appid:'d86ca3beb3c8bf8cce8409a0da74b4c9']
    }   
//groovy.xml.XmlUtil.serialize(result) //pretty print 
//Make it Parser 
def weatherdata = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(result))
                                
//[[2019-04-06T12:00:00, [21.42]]
//weatherdata.forecast.time.collect{ [it.'@from', it.temperature.'@value']}   
weatherdata.forecast.time.collect{ [it.'@from', 
            it.temperature.'@value'[0],
            it.temperature.'@min'[0],
            it.temperature.'@max'[0],
            it.clouds.'@value'[0]
            ]} 

def rows = weatherdata.forecast.time.collect{ new Row(it.'@from'.toString() , 
            it.temperature.'@value'[0] ,
            it.temperature.'@min'[0],
            it.temperature.'@max'[0],
            it.clouds.'@value'[0]) }
            
rows.groupBy{it.dt.date}.collectEntries{k, v -> [k, [
                                min: v.collect{it.temp_min}.min(),
                                max: v.collect{it.temp_max}.max(),
                                text: v.head().text
                                ]]}

         
'''     
//XML output 
<weatherdata>
<location><name>London</name><type/><country>US</country><timezone/><location altitude="0" latitude="39.8865" longitude="-83.4483" geobase="geonames" geobaseid="4517009"/></location>
<credit/>
<meta><lastupdate/><calctime>0.0028</calctime><nextupdate/></meta>
<sun rise="2015-06-30T10:08:46" set="2015-07-01T01:06:20"/>
<forecast>
 <time from="2015-06-30T09:00:00" to="2015-06-30T12:00:00">
 <symbol number="500" name="light rain" var="10n"/>
 <precipitation value="5" unit="3h" type="rain"/>
 <windDirection deg="253.5" code="WSW" name="West-southwest"/>
 <windSpeed mps="4.9" name="Gentle Breeze"/>
 <temperature unit="celsius" value="16.89" min="16.89" max="17.375"/>
 <pressure unit="hPa" value="989.51"/>
 <humidity value="96" unit="%"/>
 <clouds value="broken clouds" all="64" unit="%"/>
</time>
 <time from="2015-06-30T12:00:00" to="2015-06-30T15:00:00">
 <symbol number="500" name="light rain" var="10d"/>
 <precipitation value="99" unit="3h" type="rain"/>
 <windDirection deg="248.001" code="WSW" name="West-southwest"/>
 <windSpeed mps="4.86" name="Gentle Breeze"/>
 <temperature unit="celsius" value="17.23" min="17.23" max="17.614"/>
 <pressure unit="hPa" value="991.29"/>
 <humidity value="97" unit="%"/>
 <clouds value="scattered clouds" all="44" unit="%"/>
 </time>

...

</forecast>
</weatherdata>


'''
/************************* Not from here ****************/
///* Groovy Closure - advanced 
println( {null} instanceof Closure ) //true 
Closure.methods.name 

def ic = Closure.IDENTITY
println(ic(200))


///* Currying- Partially applied function 
//only for Closure
def fc(x,y){
    x - y 
}
def fcc = this.&fc 
def fccl = fcc.curry(10)
println(fccl(20))    //-10
def fccr = fcc.rcurry(10)
println(fccr(20))  //10

///* Compose 
def plus2  = { it + 2 }
def times3 = { it * 3 }

def pt = times3 << plus2  //RHS first
println(pt(20))
def tp = times3 >> plus2  //LHS first 
println(tp(20))

///* Memoization 
def fibNoM                    //for recursive, this line is must
fibNoM = { long n -> n<2 ? n : fibNoM(n-1)+fibNoM(n-2) }          // no memoization
println(fibNoM(15)) // slow!

//with memoization
def fib 
fib = { long n -> n<2?n:fib(n-1)+fib(n-2) }.memoize()          // with memoization
println( fib(25) ) // fast! 

//check time 
def withTime = {Closure operation , n->
              def start = System.currentTimeMillis()
              def res = operation(n)
              def timeSpent = System.currentTimeMillis() - start
              println "TIME IS ~ ${timeSpent}ms"
              res
            }
    
withTime(fibNoM, 15 )
withTime( fib, 15 )

///*TCO - with accumulator and trampoline
def fibfast
fibfast= { def n,  prev = 0G, nxt = 1G ->          
          n<2 ? nxt : fibfast.trampoline( n-1, nxt, prev+nxt)         
        }

fibfast =fibfast.trampoline()

withTime(fibfast, 1000)

//With methods 
//Creates a memoized version of a function 
//Example 
@groovy.transform.Memoized
long longComputation(int seed) {
    // slow computation
    Thread.sleep(100*seed)
    System.nanoTime()
}
def x = longComputation(1) // returns after 100 milliseconds
def y = longComputation(1) // returns immediatly
def z = longComputation(2) // returns after 200 milliseconds

//Creates a TailRecursive function 
//Example 
@groovy.transform.TailRecursive
def mysum( List lst, BigInteger acc =0G){
    if(lst.empty)
        return acc 
    else 
        return mysum(lst.tail(), acc + lst.head())
}
def lst = (0..10000).toList 
mysum(lst)    



///* Groovy Closure - delegate  

//delegate=owner, owner=nesting closure or this, this=class instance
//default strategy OWNER_FIRST (then delegate) for unscoped variable
//use delegate always inside closure to access closure var as a clarity

//Example Delegate_First 
class Test {
     def x = 30
     def y = 40

     def run() {
         def data = [ x: 10, y: 20 ]
         def cl = { y = x + y }  //x,y from delegate ie from data, 
         cl.delegate = data
         cl.resolveStrategy = Closure.DELEGATE_FIRST //comment out this to see that this.y = 70
         cl()
         println x     //this.x //30
         println y     //this.y //40
         println data  //[x:10, y:30]
     }
 }

 new Test().run()
 

//Using delegate 
class Person2 {
    String name
}
class Thing2 {
    String name
}

def p = new Person2(name: 'Norman')
def t = new Thing2(name: 'Teapot')

//name = "OK" // Uncomment this, as by-default OWNER_FIRST, assertion fails
//Clear script context once above is commented
def upperCasedName = { delegate.name.toUpperCase() }    //use delegate.name.toUpperCase()

upperCasedName.delegate = p                // change delegate, behaviour is changed
assert upperCasedName() == 'NORMAN'
upperCasedName.delegate = t
assert upperCasedName() == 'TEAPOT'

