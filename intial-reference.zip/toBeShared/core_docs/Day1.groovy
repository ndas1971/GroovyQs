"""
Day-1
    Starting Groovy 
    Difference between Java and Groovy
    gradle as build tool 
    Groovy operators
    Groovy Imperative 
    Groovy  String, Collections
    Groovy Object Oriented and AST transformation
"""

///**** Starting Groovy & Difference between Java and Groovy

// groovy file
$ groovy hello.groovy
//hello.groovy
println("${args[0]}")  //command line handling

//or
//Test.groovy
package support 
class Test {
  public static void main(String[] args) {
     println("${args[0]}")
  }
}
//compile with groovyc 
$ groovyc -d ./classes Test.groovy
$ java -cp "./classes;%GROOVY_HOME%/lib/*"   support.Test 123


///* Groovy Default Imports 
//Note Groovy automatically imports below
java.io.*
java.lang.*
java.math.BigDecimal
java.math.BigInteger
java.net.*
java.util.*
groovy.lang.*
groovy.util.*


///* Groovy Extension methods - GDK 
//DefaultGroovyMethods  - http://www.groovy-lang.org/gdk.html
//This class defines new groovy methods which appear on normal JDK classes inside the Groovy environment. 

//Static methods are used with the first parameter being the destination class,
//public static String reverse(String self) //provides a reverse() method for String. 
groovy> groovy.ui.Console.consoleControllers[0].@maxOutputChars=1000000 
groovy> import org.codehaus.groovy.runtime.DefaultGroovyMethods 
groovy>  DefaultGroovyMethods.methods.each{println(it)} 


//In  Groovy, there is no need to access getter/setter by java way
//use 
a.text       // where object a has method getText()
a.text = ..  // where object a has method setText(..)  

//Note any getXYZ() without any arg can be coverted to a.xYZ 
//If there is any arg to getMethod(arg), then Use Java way 



//Note that do..while is not supported in Groovy
//Else all java code can be written inside groovy as it is

//Groovy is dynamic types, hence Generics does not have any meaning 


///* Accessing property/field and method with empty argument
//Parenthesis is must for no arg method 
obj.a    // a is property/field, or getA()
obj.a()  // a is method

//For any arg method, Parenthisis is optional 
println("OK")
println "OK"
obj.b 1,2,3 
obj.b(1,2,3)

///* Printing and interpolation 
def a = "OK"
println "$a has double length= ${a.size() * 2}"


///* no primitive 
int i               //primitives are initialized to zero , but converted to reference type 
Double k            //reference are initialized to null. 
def j = 20.2        //by default Bigdecimal 
def j = 20.2 as Double //now double 
println "${i.class}, ${j.class} ${k.class}"
//get/set 
println "${i.class} == ${i.getClass()}"

//Note all below are equal interms of type 
x = 1
def y = 1
int z = 1
Integer a = 1
[x.class, y.class, z.class, a.class]

///* GPATH expression 
a.b.c 
    for POJO((Plain Old Java Objects)s, yields all c properties for all the b properties of a 
    (sort of like a.getB().getC() in JavaBeans). 
    Note b, c  are properties only (not methods, get* is OK ) 
    and return could be a array if  any property yields a array even in between(flattened)
    If b,c are methods, use Spread Operators 
    a.b()*.c()
//Example 
String.methods.name
String.methods.name*.size() //[2,3,..]
String.methods.name.size() //76

///*Using Grape
@Grapes([ 
 @Grab('org.apache.httpcomponents:httpclient:4.2.1')
 ])
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.client.methods.HttpGet

def httpClient = new DefaultHttpClient()
def url = 'http://www.google.com/search?q=Groovy'
def httpGet = new HttpGet(url)
def httpResponse = httpClient.execute(httpGet)
new File('result.html').text =   httpResponse.entity.content.text
println  httpResponse.allHeaders.name 


///**** Gradle : gradle as build tool 
//Dir structure 
.
├── build.gradle
├── src
│   ├── main
│   │   ├── groovy
│   │   │   ├── examples
│   │   │   │   ├── Main.groovy
│   │   │   │   ├── model.groovy
│   │   │   │   └── refresh.groovy
│   │   │   ├── jxrs
│   │   │   │   └── Service.groovy
│   │   │   ├── org
│   │   │   │   └── hibernate
│   │   │   │       └── dialect
│   │   │   │           ├── SQLiteDialect.java
│   │   │   │           └── identity
│   │   │   │               └── SQLiteDialectIdentityColumnSupport.java
│   │   │   └── support
│   │   │       └── Person.groovy
│   │   ├── java
│   │   │   ├── examples
│   │   │   │   ├── GreetingService.java
│   │   │   │   └── JavaGreetingImpl.java
│   │   │   └── jsrx
│   │   │       ├── Book.java
│   │   │       └── BookService.java
│   │   └── resources
│   │       ├── Messenger.groovy
│   │       ├── beans.xml
│   │       └── log4j.properties
│   └── test
│       ├── groovy
│       │   └── support
│       │       └── test.groovy
│       └── java
└── anyOtherFiles 
//build.gradle 
//note groovy plugin compiles java as well 

apply plugin: 'groovy'
apply plugin:'application'
mainClassName = "examples.Main"   //gradle run 

repositories {
          mavenCentral()	
          jcenter()
        }

dependencies {    
    compile 'org.codehaus.groovy:groovy-all:2.5.0'    
    //for xls 
    compile 'builders.dsl:spreadsheet-builder-poi:1.0.5'
    // for groovy support
    compile 'builders.dsl:spreadsheet-builder-groovy:1.0.5'	
    //for GORM 
    compile "org.grails:grails-datastore-gorm-hibernate5:6.0.11.RELEASE"
    compile group:'org.grails', name:'grails-web', version:'2.3.11'
    compile 'org.springframework:spring-context:4.0.0.RELEASE'
    compile 'com.github.groovy-wslite:groovy-wslite:1.1.2'
    compile 'io.ratpack:ratpack-groovy:1.5.4'
    //compile 'org.codehaus.groovy.modules:groovyws:0.5.2'
    compile 'org.codehaus.gpars:gpars:1.2.1'    
    compile 'io.github.http-builder-ng:http-builder-ng-core:1.0.3'    
    compile 'org.jsoup:jsoup:1.9.2'
    compile group:'org.ccil.cowan.tagsoup', name:'tagsoup', version:'0.9.7'
    runtime "com.h2database:h2:1.4.192"
    runtime "org.xerial:sqlite-jdbc:3.7.2"
    runtime "org.apache.tomcat:tomcat-jdbc:8.5.0"
    runtime "org.apache.tomcat.embed:tomcat-embed-logging-log4j:8.5.0"
    runtime "org.slf4j:slf4j-api:1.7.10"
    runtime group: 'org.slf4j', name: 'slf4j-log4j12', version: '1.7.10'
    //testing
	testCompile 'junit:junit:4.10'
}

//gradle build and gradle -PmainClass=foo runApp
task runApp(type:JavaExec) {
    classpath = sourceSets.main.runtimeClasspath
    main = project.hasProperty("mainClass") ? project.getProperty("mainClass") : "examples.Main"
}

// check task list
$ gradle tasks
// execute as, it runs test as well
$ gradle build
$ gradle run   //runs mainClassName
$ gradle -q run   //runs mainClassName and only main class outputs 
$ gradle -PmainClass=foo runApp  //for multiple class , runs 'foo'
$ gradle -i test                 //if test code has any println
// check test report in build/reports/tests/index.html
//with java
$ java -cp "build\libs\*;%GROOVY_HOME%\lib\*" support.Person 123

///Level        Level Used for                      Option(that level and higher)
//By default, Gradle redirects standard output to the QUIET log level and standard error to the ERROR level
//higher to lower                           
ERROR           Error messages
QUIET           Important information messages      -q or --quiet
WARNING         Warning messages                    -w or --warn
LIFECYCLE       Progress information messages        no logging options
INFO            Information messages                -i or --info
DEBUG           Debug messages(all messages)        -d or --debug
 

 


///* Gradle : Build script structure

//There is a one-to-one relationship between a Project and a build.gradle file. During build initialisation, 

//Gradle assembles a Project object for each project which is to participate in the build, as follows:
•Create a Settings instance for the build.
•Evaluate the settings.gradle script, if present, against the Settings object to configure it.
•Use the configured Settings object to create the hierarchy of Project instances.
•Finally, evaluate each Project by executing its build.gradle file, if present, against the project. 
 The projects are evaluated in breadth-wise order, such that a project is evaluated before its child projects. 
 This order can be overridden by calling Project.evaluationDependsOnChildren() or by adding an explicit evaluation dependency using Project.evaluationDependsOn(java.lang.String).


///Tasks
//A project is essentially a collection of Task objects. 
//Each task performs some basic piece of work, such as compiling classes, or running unit tests, or zipping up a WAR 



///Project Properties
//Gradle executes the project's build file against the Project instance to configure the project. 
//Any property or method which script uses is delegated through to the associated Project object. 

//This means, use any of the methods and properties on the Project interface directly in build script. 
defaultTasks('some-task')  // Delegates to Project.defaultTasks()
reportsDir = file('reports') // Delegates to Project.file() and the Java Plugin

//You can also access the Project instance using the 'project' property. 
//For example, you could use project.name rather than name to access the project's name.

 
//A build script is made up of zero or more statements and script blocks. 
//Statements can include method calls, property assignments, and local variable definitions. 

//A script block is a method call which takes a closure as a parameter. 
//The closure is treated as a configuration closure which configures it's delegate object (can access it properties and methods)

//The top level script blocks are listed below.
allprojects { } 
    Configures this project and each of its sub-projects. 
artifacts { } 
    Configures the published artifacts for this project.  
buildscript { } 
    Configures the build script classpath for this project.  
configurations { } 
    Configures the dependency configurations for this project.  
dependencies { } 
    Configures the dependencies for this project.  
repositories { } 
    Configures the repositories for this project.  
sourceSets { } 
    Configures the source sets of this project.  
subprojects { } 
    Configures the sub-projects of this project. 
publishing { } 
    Configures the PublishingExtension added by the publishing plugin.
    
    


//To access enviornment variable 
def home = "$System.env.HOME"

//Gradle uses a directed acyclic graph (DAG) to build a dependency graph of tasks and then executes
//Gradle scripts are configuration scripts. 
//As the script executes, it configures an object of a particular type. 

//For example, as a build script executes, it configures an object of type Project. 
//This object is called the delegate object of the script
//The properties and methods of the delegate object are available  to use in the script.

///Type of script                               Delegates to instance of 
Build script                                    Project  
Init script(USER_HOME/.gradle/init.gradle)      Gradle      (also from Project.getGradle()) for build customizations
Settings(settings.gradle)                       Settings    for multiproject settings 


//Also each Gradle script implements the Script interface. 

//Check reference for all types 
//https://docs.gradle.org/4.8/dsl/

///The Project object provides some standard properties, which are available in  build script
allprojects 
	The set containing this project and its subprojects.
ant 
	The AntBuilder for this project. You can use this in your build file to execute ant tasks. See example below.
artifacts 
	Returns a handler for assigning artifacts produced by the project to configurations. 
buildDir 
	The build directory of this project. The build directory is the directory which all artifacts are generated into. The default value for the build directory is projectDir/build
buildFile 
	The build script for this project. 
buildscript 
	The build script handler for this project. You can use this handler to query details about the build script for this project, and manage the classpath used to compile and execute the project build script.
childProjects 
	The direct children of this project.
configurations 
	The configurations of this project. 
convention 
	The Convention for this project.
defaultTasks 
	The names of the default tasks of this project. These are used when no tasks names are provided when starting the build.
dependencies 
	The dependency handler of this project. The returned dependency handler instance can be used for adding new dependencies. For accessing already declared dependencies, the configurations can be used. 
description 
	The description of this project, if any.
extensions 
	Allows adding DSL extensions to the project. Useful for plugin authors.
gradle 
	The Gradle invocation which this project belongs to.
group 
	The group of this project. Gradle always uses the toString() value of the group. The group defaults to the path with dots as separators.
logger 
	The logger for this project. You can use this in your build file to write log messages.
logging 
	The LoggingManager which can be used to receive logging and to control the standard output/error capture for this project build script. By default, System.out is redirected to the Gradle logging system at the QUIET log level, and System.err is redirected at the ERROR log level.
name 
	The name of this project. The project name is not necessarily unique within a project hierarchy. You should use the Project.getPath() method for a unique identifier for the project.
parent 
	The parent project of this project, if any.
path 
	The path of this project. 
    The path is the fully qualified name of the project.
plugins 
	The container of plugins that have been applied to this object. 
project 
	Returns this project. This method is useful in build files to explicitly access project properties and methods. For example, using project.name can express your intent better than using name. This method also allows you to access project properties from a scope where the property may be hidden, such as, for example, from a method or closure. 
projectDir 
	The directory containing the project build file.
properties 
	The properties of this project. 
repositories 
	Returns a handler to create repositories which are used for retrieving dependencies and uploading artifacts produced by the project.
resources 
	Provides access to resource-specific utility methods, for example factory methods that create various resources.
rootDir 
	The root directory of this project. The root directory is the project directory of the root project.
rootProject 
	The root project for the hierarchy that this project belongs to. In the case of a single-project build, this method returns this project.
state 
	The evaluation state of this project. 
    You can use this to access information about the evaluation of this project, such as whether it has failed.
status 
	The status of this project. Gradle always uses the toString() value of the status. 
    The status defaults to release.
subprojects 
	The set containing the subprojects of this project.
tasks 
	The tasks of this project.
version 
	The version of this project. 
//Few project methods 
absoluteProjectPath(path) 
	Converts a name to an absolute project path, resolving names relative to this project.
afterEvaluate(closure) 
	Adds a closure to be called immediately after this project has been evaluated. 
    The project is passed to the closure as a parameter. 
    Such a listener gets notified when the build file belonging to this project has been executed. 
    A parent project may for example add such a listener to its child project. 
    Such a listener can further configure those child projects based on the state of the child projects after their build files have been run.
apply(closure) 
	Applies zero or more plugins or scripts. 
apply(options) 
	Applies a plugin or script, using the given options provided as a map. 
    Does nothing if the plugin has already been applied. 

artifacts(configureAction) 
	Configures the published artifacts for this project. 
beforeEvaluate(closure) 
	Adds a closure to be called immediately before this project is evaluated. 
    The project is passed to the closure as a parameter.
    
configure(objects, configureClosure) 
	Configures a collection of objects via a closure. 
    This is equivalent to calling Project.configure(java.lang.Object, groovy.lang.Closure) for each of the given objects.
copy(closure) 
	Copies the specified files. 
    The given closure is used to configure a CopySpec, which is then used to copy the files. 
    copy {
       from configurations.runtime
       into 'build/deploy/lib'
    }
    copy {
       into 'build/webroot'
       exclude '**/.svn/**'
       from('src/main/webapp') {
          include '**/*.jsp'
          filter(ReplaceTokens, tokens:[copyright:'2009', version:'2.3.1'])
       }
       from('src/main/js') {
          include '**/*.js'
       }
    }
delete(paths) 
	Deletes files and directories. 
    project.delete {
        delete 'somefile'
        followSymlinks = true
    }

exec(closure) 
	Executes an external command. The closure configures a ExecSpec.

file(path) 
	Resolves a file path relative to the project directory of this project. This method converts the supplied path based on its type:
file(path, validation) 
	Resolves a file path relative to the project directory of this project and validates it using the given scheme. See PathValidation for the list of possible validations.
fileTree(baseDir) 
	Creates a new ConfigurableFileTree using the given base directory. 
    The given baseDir path is evaluated as per Project.file(java.lang.Object).
    //Example 
    def myTree = fileTree("src")
    myTree.include "**/*.java"
    myTree.builtBy "someTask"

    task copy(type: Copy) {
       from myTree
    }
fileTree(baseDir, configureClosure) 
	Creates a new ConfigurableFileTree using the given base directory. The given baseDir path is evaluated as per Project.file(java.lang.Object). 
    The closure will be used to configure the new file tree. The file tree is passed to the closure as its delegate. 
    Example 
    def myTree = fileTree('src') {
       exclude '**/.data/**'
       builtBy 'someTask'
    }
fileTree(args) 
	Creates a new ConfigurableFileTree using the provided map of arguments. 
    The map will be applied as properties on the new file tree.

files(paths, configureClosure) 
	Creates a new ConfigurableFileCollection using the given paths. The paths are evaluated as per Project.files(java.lang.Object[]). The file collection is configured using the given closure. The file collection is passed to the closure as its delegate. Example:
files(paths) 
	Returns a ConfigurableFileCollection containing the given files. You can pass any of the following types to this method:

findProperty(propertyName) 
	Returns the value of the given property or null if not found. This method locates a property as follows:
getAllTasks(recursive) 
	Returns a map of the tasks contained in this project, and optionally its subprojects.
getTasksByName(name, recursive) 
	Returns the set of tasks with the given name contained in this project, and optionally its subprojects.
hasProperty(propertyName) 
	Determines if this project has the given property. See here for details of the properties which are available for a project.
javaexec(closure) 
	Executes a Java main class. The closure configures a JavaExecSpec.
    
mkdir(path) 
	Creates a directory and returns a file pointing to it.

project(path) 
	Locates a project by path. If the path is relative, it is interpreted relative to this project.
project(path, configureClosure) 
	Locates a project by path and configures it using the given closure. If the path is relative, it is interpreted relative to this project. The target project is passed to the closure as the closure delegate.
property(propertyName) 
	Returns the value of the given property. 
    
relativePath(path) 
	Returns the relative path from the project directory to the given path. The given path object is (logically) resolved as described for Project.file(java.lang.Object), from which a relative path is calculated.
relativeProjectPath(path) 
	Converts a name to a project path relative to this project.
setProperty(name, value) 
	Sets a property of this project. This method searches for a property with the given name in the following locations, and sets the property on the first location where it finds the property.

tarTree(tarPath) 
	Creates a new FileTree which contains the contents of the given TAR file. 
    
task(name) 
	Creates a Task with the given name and adds it to this project. Calling this method is equivalent to calling Project.task(java.util.Map, java.lang.String) with an empty options map.
task(name, configureClosure) 
	Creates a Task with the given name and adds it to this project. 
    Before the task is returned, the given closure is executed to configure the task.
task(args, name) 
	Creates a Task with the given name and adds it to this project. 
    A map of creation options can be passed to this method to control how the task is created. 

task(args, name, configureClosure) 
	Creates a Task with the given name and adds it to this project. Before the task is returned, the given closure is executed to configure the task. A map of creation options can be passed to this method to control how the task is created. See Project.task(java.util.Map, java.lang.String) for the available options.

uri(path) 
	Resolves a file path to a URI, relative to the project directory of this project. Evaluates the provided path object as described for Project.file(java.lang.Object), with the exception that any URI scheme is supported, not just 'file:' URIs.
zipTree(zipPath) 
	Creates a new FileTree which contains the contents of the given ZIP file. 
    The given zipPath path is evaluated as per Project.file(java.lang.Object). 
    ou can combine this method with the Project.copy(groovy.lang.Closure) method to unzip a ZIP file.

    
 
///* Gradle : Creating new build 
$ mkdir basic-demo
$ cd basic-demo
$ touch build.gradle 

//To see what tasks are available 
$ gradle tasks

//To see help on one task 
$ gradle help --task wrapper

//Run wrapper to get wrapper 
$ gradle wrapper

//all project properties 
$ gradle properties

//dependencies 
$ gradle dependencies

//projects 
$ gradle projects 

//Add few properties 
//build.gradle 
description = 'A trivial Gradle build'
version = '1.0'
$ gradle properties

//One example task 
//create dir src/in.txt 
//build.gradle 
task copy(type: Copy) {
    from 'src'
    into 'dest'
}

//check tasks 
$ gradle tasks --all

//execute 
$ gradle copy 

//Using plugins
//Many pluins are available , check - http://plugins.gradle.org/
//Many plugin are created on top the 'base' plugin, eg Zip task 
//plugins {} must be first block of build.gradle 
//build.gradle 
plugins {
    id 'base'
}

task zip(type: Zip) {
    from 'src'
}

$ gradle zip  //creates project_name-version.zip file under build\distributions\libraries

//running multiple task , also can specify any prefix to uniquely identify 
$ gradle z c 

//to exclude use -x 
$ gradle zip -x copy

//Forcing tasks to run
$ gradle --rerun-tasks zip

//Continue even if failure of other tasks 
$ gradle --continue zip 

//Obtaining information about projects //-q means quite, only log errors 
$ gradle -q projects

//Obtaining information about tasks
$ gradle -q tasks

//By default, this report shows only those tasks which have been assigned to a task group, visible tasks.
//to assign group , then zip would be shown under Build tasks 
zip {
    description = 'Builds the distribution'
    group = 'build'
}

//--all : show tasks which have not been assigned to a task group, so-called hidden tasks. 
$ gradle -q tasks --all

//Getting detailed help 
$ gradle -q help --task clean 


//Profiling a build
$ gradle build --profile  //build/reports/profile 


///* Gradle: Task 
//Everything in Gradle sits on top of two basic concepts: projects and tasks.
//Every Gradle build is made up of one or more projects. 
//Each project is made up of one or more tasks

///Few important properties/methods of TASK 
String name (read-only)
    The name of this task. The name uniquely identifies the task within its Project.
TaskOutputs outputs (read-only)
    The outputs of this task.
String path (read-only)
    The path of the task, which is a fully qualified name for the task. 
    The path of a task is the path of its Project plus the name of the task, separated by :
Project project (read-only)
    The Project which this task belongs to.
TaskState state (read-only)
    The execution state of this task. 
    This provides information about the execution of this task, such as whether it has executed, been skipped, has failed, etc.
TaskDependency taskDependencies (read-only)
    Returns a TaskDependency which contains all the tasks that this task depends on.
File temporaryDir (read-only)
    Returns a directory which this task can use to write temporary files to
Logger logger (read-only)
    The logger for this task. Use for  writing log messages.
LoggingManager logging (read-only)
    The LoggingManager which can be used to control the logging level and standard output/error capture for this task. By default, System.out is redirected to the Gradle logging system at the QUIET log level, and System.err is redirected at the ERROR log level.
String group
    The task group which this task belongs to

///Few methods of Task 
Task doFirst(Closure action)
    Adds the given closure to the beginning of this task action list, 
    The closure is passed this task as a parameter when executed.
Task doLast(Closure action)
    Adds the given closure to the end of this task action list. 
    The closure is passed this task as a parameter when executed.
Task leftShift(Closure action)
    Note: This method is deprecated and will be removed in the next major version of Gradle.
    Adds the given closure to the end of this tasks action list
void onlyIf(Closure onlyIfClosure)
    Execute the task only if the given closure returns true. 
    The closure will be evaluated at task execution time, not during configuration. 
    The closure will be passed a single parameter, this task. 
    If the closure returns false, the task will be skipped

///Various ways to define tasks
task(hello) {                //Task 
    doLast {
        println "hello"
    }
}

task('copy', type: Copy) {   //taking string
    from(file('srcDir'))
    into(buildDir)
}


tasks.create(name: 'copy', type: Copy) {
    from(file('srcDir'))
    into(buildDir)
}

///Accessing tasks as properties

task hello

println hello.name
println project.hello.name

///Accessing tasks via' tasks' collection
task hello

println tasks.hello.name
println tasks['hello'].name

///Accessing tasks by path
project(':projectA') {
    task hello
}

task hello

println tasks.getByPath('hello').path
println tasks.getByPath(':hello').path
println tasks.getByPath('projectA:hello').path
println tasks.getByPath(':projectA:hello').path

///Configuring a task - various ways
Copy myCopy = task(myCopy, type: Copy)
myCopy.from 'resources'
myCopy.into 'target'
myCopy.include('**/*.txt', '**/*.xml', '**/*.properties')

///Configuring a task - with closure
task myCopy(type: Copy)

myCopy {
   from 'resources'
   into 'target'
   include('**/*.txt', '**/*.xml', '**/*.properties')
}


///Defining and configuring  a task with closure
task copy(type: Copy) {
   from 'resources'
   into 'target'
   include('**/*.txt', '**/*.xml', '**/*.properties')
}



///doLast and doFirst 
//The calls doFirst and doLast can be executed multiple times. 
//When the task executes, these actions in the action list are executed in order. 

task hello {
    doLast {
        println 'Hello Earth'
    }
}
hello.doFirst {
    println 'Hello Venus'
}
hello.doLast {
    println 'Hello Mars'
}
hello {
    doLast {
        println 'Hello Jupiter'
    }
}


///Passing external properties to task 
task printProp  {
    println customProp
}


$ gradle -PcustomProp=myProp printProp
:printProp
myProp

///Tasks passing variables among them - use task.ext 
task myTask {
    ext.myProperty = "myValue"
}

task printTaskProperties {
    doLast {
        println myTask.myProperty
    }
}



///Dependencies to a task are controlled using 
//property 
dependsOn                value is path 
//methods 
Task dependsOn(paths)    
    Adds the given dependencies to this task
Task mustRunAfter(paths) 
    Specifies that this task must run after all of the supplied tasks.
    task taskY {
        mustRunAfter "taskX"
    }
//Note - paths maybe 
•A String, CharSequence or groovy.lang.GString task path(path syntax project:task) or name. 
 A relative path is interpreted relative to the tasks Project
•A Task.
•A closure. The closure may take a Task as parameter. 
 It may return any of the types listed here
•A Iterable, Collection, Map or array. May contain any of the types listed here, 
 Its return value is recursively converted to tasks
•A Callable. The call() method may return any of the types listed here, 
 Its return value is recursively converted to tasks

//Example 
//build.gradle 

task compile {
    doLast {
        println 'compiling source'
    }
}

task compileTest(dependsOn: compile) {
    doLast {
        println 'compiling unit tests'
    }
}

task test(dependsOn: [compile, compileTest]) {
    doLast {
        println 'running unit tests'
    }
}

task dist(dependsOn: [compile, test]) {
    doLast {
        println 'building the distribution'
    }
}

$ gradle dist test


///Adding dependency on task from another project
project('projectA') {
    task taskX(dependsOn: ':projectB:taskY') {
        doLast {
            println 'taskX'
        }
    }
}

project('projectB') {
    task taskY {
        doLast {
            println 'taskY'
        }
    }
}


///Adding dependency using task object

task taskX {
    doLast {
        println 'taskX'
    }
}

task taskY {
    doLast {
        println 'taskY'
    }
}

taskX.dependsOn taskY


///Adding dependency using closure

task taskX {
    doLast {
        println 'taskX'
    }
}

taskX.dependsOn {
    tasks.findAll { task -> task.name.startsWith('lib') }
}

task lib1 {
    doLast {
        println 'lib1'
    }
}

task lib2 {
    doLast {
        println 'lib2'
    }
}

task notALib {
    doLast {
        println 'notALib'
    }
}


///Defining a default task
defaultTasks 'clean', 'run'

task clean {
    doLast {
        println 'Default Cleaning!'
    }
}

task run {
    doLast {
        println 'Default Running!'
    }
}

task other {
    doLast {
        println "I'm not a default task!"
    }
}


/// Using local variables

def dest = "dest"

task copy(type: Copy) {
    from "source"
    into dest
}

///Extra properties
//All objects in Gradle domain model can hold extra user-defined properties by 'ext' property 
apply plugin: "java"

ext {  //these are Project's extra 
    springVersion = "3.1.0.RELEASE"
    emailNotification = "build@master.org"
}

sourceSets.all { ext.purpose = null }

sourceSets {
    main {
        purpose = "production"
    }
    test {
        purpose = "test"
    }
    plugin {
        purpose = "production"
    }
}

task printProperties {
    doLast {
        println springVersion
        println emailNotification
        sourceSets.matching { it.purpose == "production" }.each { println it.name }
    }
}


$ gradle -q printProperties



///Task Ordering 
//Task.mustRunAfter(args) , Task.shouldRunAfter(args) 
//args is  a task instance, a task name or any other input accepted by Task.dependsOn(java.lang.Object[]). 

//Note that B.mustRunAfter(A) or B.shouldRunAfter(A) does not imply any execution dependency between the tasks
•It is possible to execute tasks A and B independently. 
 The ordering rule only has an effect when both tasks are scheduled for execution.
•When run with --continue, it is possible for B to execute in the event that A fails.

//A 'should run after' task ordering is ignored if it introduces an ordering cycle

///Adding a 'must run after' task ordering

task taskX {
    doLast {
        println 'taskX'
    }
}
task taskY {
    doLast {
        println 'taskY'
    }
}
taskY.mustRunAfter taskX



> gradle -q taskY taskX
taskX
taskY


///Adding a 'should run after' task ordering

task taskX {
    doLast {
        println 'taskX'
    }
}
task taskY {
    doLast {
        println 'taskY'
    }
}
taskY.shouldRunAfter taskX


> gradle -q taskY taskX
taskX
taskY

//Task ordering does not imply task execution
> gradle -q taskY
taskY





///Adding a description to a task
//This description is displayed when executing gradle tasks. 

task copy(type: Copy) {
   description 'Copies the resource directory to the target directory.'
   from 'resources'
   into 'target'
   include('**/*.txt', '**/*.xml', '**/*.properties')
}


///Replacing tasks /Overwriting a task

task copy(type: Copy)

task copy(overwrite: true) {
    doLast {
        println('I am the new one.')
    }
}


///Skipping a task using a predicate
task hello {
    doLast {
        println 'hello world'
    }
}

hello.onlyIf { !project.hasProperty('skipHello') }


$ gradle hello -PskipHello


///Skipping tasks with StopExecutionException
task compile {
    doLast {
        println 'We are doing the compile.'
    }
}

compile.doFirst {
    // Here you would put arbitrary conditions in real life.
    // But this is used in an integration test so we want defined behavior.
    if (true) { throw new StopExecutionException() }
}
task myTask(dependsOn: 'compile') {
    doLast {
        println 'I am not affected'
    }
}


$ gradle -q myTask

 
///Enabling and disabling tasks
task disableMe {
    doLast {
        println 'This should not be printed if the task is disabled.'
    }
}
disableMe.enabled = false




///* Gradle: dependencies, Repositeris and plugins 

//build.gradle
apply plugin: 'java'

repositories {
    mavenCentral()
}

dependencies {
    compile group: 'org.hibernate', name: 'hibernate-core', version: '3.6.7.Final'
    testCompile group: 'junit', name: 'junit', version: '4.+'
}

//Listing project dependencies
$ gradle dependencies

//to a particular configuration - Note testCompile must be there 
$ gradle dependencies --configuration testCompile

//To get insight 
$ gradle dependencyInsight --dependency java --configuration compile


//In Gradle dependencies are grouped into configurations(eg configurations.compile from java plugin)
//Configurations have a name, a number of other properties, and they can extend each other. 

//Many Gradle plugins add pre-defined configurations to a project.
//for example java(groovy) plugin brings below configurations 
compile runtime testCompile testRuntime

 
//To define and the re-configure 
configurations {
    my_compile {
        description = 'compile classpath'
        transitive = true
    }
    my_runtime {
        extendsFrom compile
    }
}
configurations.my_compile {
    description = 'compile classpath'
}

//accessing 
println configurations.my_compile.name
println configurations['my_compile'].name

//Example - Iterating over a configuration
task listJars {
    doLast {
        configurations.compile.each { File file -> println file.name }
    }
}

$ gradle -q listJars


//local Files dependencies
dependencies {
    runtime files('libs/a.jar', 'libs/b.jar')
    runtime fileTree(dir: 'libs', include: '*.jar')
}


//Dependencies on generated files - Note $ is GSTRING , buildDir is Project properties 
dependencies {
    compile files("$buildDir/classes") {
        builtBy 'compile'
    }
}

task compile {
    doLast {
        println 'compiling classes'
    }
}

task list(dependsOn: configurations.compile) {
    doLast {
        println "classpath = ${configurations.compile.collect { File file -> file.name }}"
    }
}

$ gradle -q list

//Gradle's Groovy dependencies
dependencies {
    compile localGroovy()
}

///Artifact (ie jar )only notation
//Gradle looks for a module descriptor file (pom.xml or ivy.xml) in the repositories
//it is parsed and downloaded 

//In Maven, a module can have one and only one artifact(jar). 
//In Gradle and Ivy, a module can have multiple artifacts.
//Each artifact can have a different set of dependencies. 

//In Gradle, when you declare a dependency on an Ivy module, 
//you actually declare a dependency on the default configuration of that module

dependencies {
    runtime "org.groovy:groovy:2.2.0@jar"
    runtime group: 'org.groovy', name: 'groovy', version: '2.2.0', ext: 'jar'
}
//Dependency with classifier(maven has a notion of classifier)
compile "org.gradle.test.classifiers:service:1.0:jdk15@jar"
otherConf group: 'org.gradle.test.classifiers', name: 'service', version: '1.0', classifier: 'jdk14'

//Gradle API dependencies
dependencies {
    compile gradleApi()
}

///local groovy dependencies 
dependencies {
    compile localGroovy()
}

///Excluding transitive dependencies- Check https://docs.gradle.org/4.8/userguide/dependency_management.html
//one can exclude transitive dependencies that are either not required by runtime 
//or that are guaranteed to be available on the target environment/platform

//note  All attributes for a dependency are optional, except the name


dependencies {
    runtime group: 'org.springframework', name: 'spring-core', version: '2.5'
    runtime 'org.springframework:spring-core:2.5',
            'org.springframework:spring-aop:2.5'
    runtime(
        [group: 'org.springframework', name: 'spring-core', version: '2.5'],
        [group: 'org.springframework', name: 'spring-aop', version: '2.5']
    )
    runtime('org.hibernate:hibernate:3.0.5') {
        transitive = true
    }
    runtime group: 'org.hibernate', name: 'hibernate', version: '3.0.5', transitive: false
    runtime(group: 'org.hibernate', name: 'hibernate', version: '3.0.5') {
        transitive = false
    }
}
//or 
configurations {
    compile.exclude module: 'commons'   // exclude 'commons' module for 'compile' configuration
    all*.exclude group: 'org.gradle.test.excludes', module: 'reports'  //to exclude  transitive dependency from all configurations using spread notation
}

dependencies {
    compile("org.gradle.test.excludes:api:1.0") {
        exclude module: 'shared'
    }
}


//Maven central repository
repositories {
    mavenCentral()
}

//Local file repositories along with maven central and local maven 
repositories {
   mavenCentral()
   flatDir {
       dirs 'libs1','libs2','libs3'
   }
   mavenLocal()  
}
dependencies {
   compile name: 'gson-2.2.4'
   compile ("com.company:utility:0.0.1") //from local maven 
}
//Note to install a file in local maven 
$ mvn install:install-file -Dfile=utility.jar -DgroupId=com.company -DartifactId=utility -Dversion=0.0.1 -Dpackaging=jar

//OR directly
compile fileTree(dir: 'libs', includes: ['*.jar'])
compile fileTree(dir: 'libs', include: '*.jar')


//Bintray's JCenter:
repositories {
    jcenter()
}

//a remote Maven repository
repositories {
    maven {
        url "http://repo.mycompany.com/maven2"
    }
}

//a remote Ivy repository:
repositories {
    ivy {
        url "http://repo.mycompany.com/repo"
    }
}

//a local Ivy directory
repositories {
    ivy {
        // URL can refer to a local directory
        url "../local-repo"
    }
}

//Publishing to an Ivy repository
uploadArchives {
    repositories {
        ivy {
            credentials {
                username "username"
                password "pw"
            }
            url "http://repo.mycompany.com"
        }
    }
}

$ gradle uploadArchives

//Publishing to a Maven repository
apply plugin: 'maven'

uploadArchives {
    repositories {
        mavenDeployer {
            repository(url: "file://localhost/tmp/myRepo/")
        }
    }
}





///* Gradle: Standard Task : Exec - Executes a command line process
//check https://docs.gradle.org/4.8/dsl/

task stopTomcat(type:Exec) {
  workingDir '../tomcat/bin'

  //on windows:
  commandLine 'cmd', '/c', 'stop.bat'

  //on linux
  commandLine './stop.sh'

  //store the output instead of printing to the console:
  standardOutput = new ByteArrayOutputStream()

  //extension method stopTomcat.output() can be used to obtain the output:
  ext.output = {
    return standardOutput.toString()
  }
}


///* Gradle: Standard Task : Copy - Copies files into a destination directory


task copyDocs(type: Copy) {
    from 'src/main/doc'
    into 'build/target/doc'
}

//for Ant filter
import org.apache.tools.ant.filters.ReplaceTokens

//for including in the copy task
def dataContent = copySpec {
    from 'src/data'
    include '*.data'
}

task initConfig(type: Copy) {
    from('src/main/config') {
        include '**/*.properties'
        include '**/*.xml'
        filter(ReplaceTokens, tokens: [version: '2.3.1'])
    }
    from('src/main/config') {
        exclude '**/*.properties', '**/*.xml'
    }
    from('src/main/languages') {
        rename 'EN_US_(.*)', '$1'
    }
    into 'build/target/config'
    exclude '**/*.bak'

    includeEmptyDirs = false

    with dataContent
}


///* Gradle: Standard Task : Delete - Deletes files or directories
task makePretty(type: Delete) {
  delete 'uglyFolder', 'uglyFile'
  followSymlinks = true
}


///* Gradle: Standard Task : test - Executes JUnit (3.8.x or 4.x) or TestNG tests. 
//Test are always run in (one or more) separate JVMs. 

apply plugin: 'java' // adds 'test' task

test {
  // enable TestNG support (default is JUnit)
  useTestNG()

  // set a system property for the test JVM(s)
  systemProperty 'some.prop', 'value'

  // explicitly include or exclude tests
  include 'org/foo/**'
  exclude 'org/boo/**'

  // show standard out and standard error of the test JVM(s) on the console
  testLogging.showStandardStreams = true

  // set heap size for the test JVM(s)
  minHeapSize = "128m"
  maxHeapSize = "512m"

  // set JVM arguments for the test JVM(s)
  jvmArgs '-XX:MaxPermSize=256m'

  // listen to events in the test execution lifecycle
  beforeTest { descriptor ->
     logger.lifecycle("Running test: " + descriptor)
  }

  // listen to standard out and standard error of the test JVM(s)
  onOutput { descriptor, event ->
     logger.lifecycle("Test: " + descriptor + " produced standard out/err: " + event.message )
  }
}


//to start in  in debug mode 
$ gradle test --debug-jvm




///* Gradle: Standard Task : Sync - like copy, but dest would only contain filed copied, other fies are deleted 


// Sync can be used like a Copy task
// See the Copy documentation for more examples
task syncDependencies(type: Sync) {
    from 'my/shared/dependencyDir'
    into 'build/deps/compile'
}

// You can preserve output that already exists in the
// destination directory. Files matching the preserve
// filter will not be deleted.
task sync(type: Sync) {
    from 'source'
    into 'dest'
    preserve {
        include 'extraDir/**'
        include 'dir1/**'
        exclude 'dir1/extra.txt'
    }
}




///* Gradle: Standard Task : JavaExec - Executes a Java application in a child process. 

apply plugin: 'java'

task runApp(type: JavaExec) {
  classpath = sourceSets.main.runtimeClasspath

  main = 'package.Main'

  // arguments to pass to the application
  args 'appArg1'
}

//debug mode 
$ gradle someJavaExecTask --debug-jvm



///* Gradle : Plugin 
//Note plugins{} must first block in build.gradle 


//To apply a core plugin, the short name can be used:
//build.gradle
plugins {
    id 'java'
}
//or legacy 
apply plugin: 'java'


//To apply a community plugin from the portal, 
//the fully qualified plugin id must be used:
//build.gradle
plugins {
    id 'com.jfrog.bintray' version '0.4.1'
}


//The pluginManagement {} block may only appear in either the settings.gradle file, 
//where it must be the first block in the file, or in an Initialization Script.

//settings.gradle
pluginManagement {
    resolutionStrategy {
    }
    repositories {
    }
}

//.gradle/init.gradle
settingsEvaluated { settings ->
    settings.pluginManagement {
        resolutionStrategy {
        }
        repositories {
        }
    }
}

//By default, the plugins {} DSL resolves plugins from the public Gradle Plugin Portal
//OR use settings.gradle


//Plugin resolution rules allow  to modify plugin requests made in plugins {} blocks, 
//e.g. changing the requested version or explicitly specifying the implementation artifact coordinates
//settings.gradle
pluginManagement {
  resolutionStrategy {
      eachPlugin {
          if (requested.id.namespace == 'org.gradle.sample') {
              useModule('org.gradle.sample:sample-plugins:1.0.0')
          }
      }
  }
  repositories {
      maven {
        url 'maven-repo'
      }
      gradlePluginPortal()
      ivy {
        url 'ivy-repo'
      }
  }
}




///Applying plugins with the buildscript block
//Binary plugins that have been published as external jar files can be added to a project 
//by adding the plugin to the build script classpath and then applying the plugin. 

//External jars can be added to the build script classpath using the buildscript {} block 
//build.gradle
buildscript {
    repositories {
        jcenter()
    }
    dependencies {
        classpath "com.jfrog.bintray.gradle:gradle-bintray-plugin:0.4.1"
    }
}

apply plugin: "com.jfrog.bintray"





///* Gradle: Standard plugin : init-build plugin
//https://docs.gradle.org/4.8/userguide/build_init_plugin.html
//To use the plugin, execute the task named init where you would like to create the Gradle build. 
 

 
$ gradle init --type ...

--type     Set type of build to create.
   Available values are:
        basic               creates a sample build.gradle file, with comments and links to help get started. 
        groovy-library      Uses Spock testing framework for testing
        java-application    Uses the “application” plugin to produce a command-line application implemented using Java
        java-library 
        pom                 convert an Apache Maven build to a Gradle build
        scala-library       Scala2.10, Uses ScalaTest for testing

 
///it Uses JUnit for testing
//or change by  --test-framework argument value.

$ gradle init --type java-application --test-framework spock      //Uses Spock for testing instead of JUnit
$ gradle init --type java-application --test-framework testng    //Uses TestNG for testing instead of JUnit



///* Gradle: Standard plugin : java plugin 
// It serves as the basis for many of the other Gradle plugins. 

//build.gradle
apply plugin: 'java'

//A source set is a group of source files which are compiled and executed together
//A source set has an associated compile classpath, and runtime classpath. 



///Details 
Tasks
    compileJava(type: JavaCompile)
    processResources(type: Copy)
    classes(type: Task)
    compileTestJava(type: JavaCompile)
    processTestResources(type: Copy)
    testClasses(type: Task)
    jar(type: Jar)
    javadoc(type: Javadoc)
    test(type: Test)
    uploadArchives(type: Upload)
    clean(type: Delete)
    cleanTaskName(type: Delete)
SourceSet Tasks
    compileSourceSetJava(type: JavaCompile)
    processSourceSetResources(type: Copy)
    sourceSetClasses(type: Task)
Lifecycle Tasks
    assemble(type: Task)
    check(type: Task)
    build(type: Task)
    buildNeeded(type: Task)
    buildDependents(type: Task)
    buildConfigName(type: Task)
    uploadConfigName(type: Upload)
Project layout 
    src/main/java           Production Java source 
    src/main/resources      Production resources 
    src/test/java           Test Java source 
    src/test/resources      Test resources 
    src/sourceSet/java      Java source for the given source set 
    src/sourceSet/resources Resources for the given source set 
Name of dependency configurations
    compile
    implementation extends compile
    compileOnly
    compileClasspath extends compile, compileOnly, implementation
    annotationProcessor
    runtime extends compile
    runtimeOnly
    runtimeClasspath extends runtimeOnly, runtime, implementation
    testCompile(Deprecated) extends compile
    testImplementation extends testCompile, implementation
    testCompileOnly
    testCompileClasspath extends testCompile, testCompileOnly, testImplementation
    testRuntime(Deprecated) extends runtime, testCompile
    testRuntimeOnly extends runtimeOnly
    testRuntimeClasspath extends testRuntimeOnly, testRuntime, testImplementation
    archives
    default extends runtime
Name of source set dependency configurations
    sourceSetCompile
    sourceSetImplementation extends sourceSetCompile
    sourceSetCompileOnly
    sourceSetCompileClasspath extends compileSourceSetJava
    sourceSetAnnotationProcessor
    sourceSetRuntime
    sourceSetRuntimeOnly
    sourceSetRuntimeClasspath extends sourceSetRuntimeOnly, sourceSetRuntime, sourceSetImplementation
Convention properties
    Use these properties in build script as though they were properties of the project object.
    (read-only) SourceSetContainer sourceSets
        Contains the project’s source sets. Default value: Not null SourceSetContainer
    JavaVersion sourceCompatibility
        Java version compatibility to use when compiling Java source. 
        Default value: version of the current JVM in use JavaVersion. 
        Can also set using a String or a Number, e.g. '1.5' or 1.5.
    JavaVersion targetCompatibility
        Java version to generate classes for. Default value: sourceCompatibility. 
        Can also set using a String or Number, e.g. '1.5' or 1.5.
    String archivesBaseName
        The basename to use for archives, such as JAR or ZIP files. Default value: projectName
    Manifest manifest
        The manifest to include in all JAR files. Default value: an empty manifest.
    String reporting.baseDir
        The name of the directory to generate reports into, relative to the build directory. Default value: reports
    (read-only) File reportsDir
        The directory to generate reports into. Default value: buildDir/reporting.baseDir
    String testResultsDirName
        The name of the directory to generate test result .xml files into, relative to the build directory. Default value: test-results
    (read-only) File testResultsDir
        The directory to generate test result .xml files into. Default value: buildDir/testResultsDirName
    String testReportDirName
        The name of the directory to generate the test report into, relative to the reports directory. Default value: tests
    (read-only) File testReportDir
        The directory to generate the test report into. Default value: reportsDir/testReportDirName
    String libsDirName
        The name of the directory to generate libraries into, relative to the build directory. Default value: libs
    (read-only) File libsDir
        The directory to generate libraries into. Default value: buildDir/libsDirName
    String distsDirName
        The name of the directory to generate distributions into, relative to the build directory. Default value: distributions
    (read-only) File distsDir
        The directory to generate distributions into. Default value: buildDir/distsDirName
    String docsDirName
        The name of the directory to generate documentation into, relative to the build directory._ Default value: docs
    (read-only) File docsDir
        The directory to generate documentation into. Default value: buildDir/docsDirName
    String dependencyCacheDirName
        The name of the directory to use to cache source dependency information, relative to the build directory. Default value: dependency-cache
Java plugin SourceSet 
    main
    test
Source set properties
    (read-only) String name
    (read-only) SourceSetOutput output
    FileCollection output.classesDirs
    File output.resourcesDir
    FileCollection compileClasspath
    FileCollection annotationProcessorPath
    FileCollection runtimeClasspath
    (read-only) SourceDirectorySet java
    Set<File> java.srcDirs
    File java.outputDir
    (read-only) SourceDirectorySet resources
    Set<File> resources.srcDirs
    (read-only) SourceDirectorySet allJava
    (read-only) SourceDirectorySet allSource
JavaCompile task  properties 
    classpath 
    destinationDir 
    excludes 
    includes 
    options 
    source 
    sourceCompatibility 
    targetCompatibility 
    toolChain 
    exclude(excludeSpec) 
    exclude(excludes) 
    exclude(excludes) 
    exclude(excludeSpec) 
    include(includeSpec) 
    include(includes) 
    include(includes) 
    include(includeSpec) 
    source(sources) 
Jar type Properties 
    appendix 
    archiveName 
    archivePath 
    baseName 
    caseSensitive 
    classifier 
    destinationDir 
    dirMode 
    duplicatesStrategy 
    entryCompression 
    excludes 
    extension 
    fileMode 
    includeEmptyDirs 
    includes 
    manifest 
    metadataCharset 
    preserveFileTimestamps 
    reproducibleFileOrder 
    source 
    version 
    zip64 
    //Methods 
    eachFile(closure) 
    eachFile(action) 
    exclude(excludeSpec) 
    exclude(excludes) 
    exclude(excludes) 
    exclude(excludeSpec) 
    expand(properties) 
    filesMatching(patterns, action) 
    filesMatching(pattern, action) 
    filesNotMatching(patterns, action) 
    filesNotMatching(pattern, action) 
    filter(closure) 
    filter(filterType) 
    filter(properties, filterType) 
    filter(transformer) 
    from(sourcePath, c) 
    from(sourcePath, configureAction) 
    from(sourcePaths) 
    include(includeSpec) 
    include(includes) 
    include(includes) 
    include(includeSpec) 
    into(destPath) 
    into(destPath, configureClosure) 
    into(destPath, copySpec) 
    manifest(configureClosure) Incubating
    manifest(configureAction) Incubating
    metaInf(configureClosure) Incubating
    metaInf(configureAction) Incubating
    rename(closure) 
    rename(sourceRegEx, replaceWith) 
    rename(sourceRegEx, replaceWith) 
    rename(renamer) 
    with(sourceSpecs) 
JavExec type property
    Executes a Java application in a child process. 
    Similar to Exec, but starts a JVM with the given classpath and application class. 
    apply plugin: 'java'
    task runApp(type: JavaExec) {
      classpath = sourceSets.main.runtimeClasspath
      main = 'package.Main'
      // arguments to pass to the application
      args 'appArg1'
    }
    The process can be started in debug mode (see JavaExec.getDebug()) in an ad-hoc manner 
    by supplying the `--debug-jvm` switch when invoking the build. 
    gradle runApp --debug-jvm
    //Properties 
    allJvmArgs 
    args 
    argumentProviders 
    bootstrapClasspath 
    classpath 
    commandLine 
    debug 
    enableAssertions 
    environment 
    errorOutput 
    executable 
    ignoreExitValue 
    jvmArgs 
    jvmArgumentProviders 
    main 
    maxHeapSize 
    standardInput 
    standardOutput 
    systemProperties 
    workingDir 
    //Methods 
    args(args) 
    args(args) 
    bootstrapClasspath(classpath) 
    classpath(paths) 
    copyTo(options) 
    copyTo(target) 
    environment(name, value) 
    environment(environmentVariables) 
    executable(executable) 
    jvmArgs(arguments) 
    jvmArgs(arguments) 
    systemProperties(properties) 
    workingDir(dir)  

//example 
jar.doFirst{
      manifest {
            attributes("Manifest-Version"   : "1.0",
                "Created-By"         : vendor,
                "Specification-Title" : appName,
                "Specification-Version": version,
                "Specification-Vendor" : vendor,
                "Implementation-Title" : appName,
                "Implementation-Version" : version,
                "Implementation-Vendor": vendor,
                "Main-Class"           : "com.dcx.epep.Start",
                "Class-Path"           : configurations.compile.collect { it.getName() }.join(' ') )
      }
}

///Creating Fat  Jar 
//https://docs.gradle.org/current/dsl/org.gradle.api.tasks.bundling.Jar.html
mainClassName = "com.company.application.Main"

jar {
  manifest { 
    attributes "Main-Class": "$mainClassName"
  }  
  zip64 = true //if dependencies are big 
  from {
    configurations.runtime.collect { it.isDirectory() ? it : zipTree(it) }
  }
}
//Or addl task fatJar 
jar {
  manifest {
    attributes(
      'Main-Class': 'my.project.main',
    )
  }
}

task fatJar(type: Jar) {
  manifest.from jar.manifest
  //classifier = 'all'
  //or 
  baseName = project.name + '-all'
  from {
    configurations.runtime.collect { it.isDirectory() ? it : zipTree(it) }
  } {
        exclude "META-INF/*.SF"
        exclude "META-INF/*.DSA"
        exclude "META-INF/*.RSA"
  }
  with jar
}

//To add this to the standard assemble or build task, add:
artifacts {
    archives fatJar
}


///Accessing source set 
//Example - configuring sourceset - Custom Java source layout
sourceSets {
    main {
        java {
            srcDirs = ['src/java']
        }
        resources {
            srcDirs = ['src/resources']
        }
    }
}



/// Various ways to access the main source set
println sourceSets.main.output.classesDir
println sourceSets['main'].output.classesDir
sourceSets {
    println main.output.classesDir
}
sourceSets {
    main {
        println output.classesDir
    }
}

///Iterate over the source sets
sourceSets.all {
    println name
}

//The Java plugin adds a JavaCompile instance for each source set in the project. 
//Some of the most common configuration options are shown below. 
classpath  source destinationDir

///Defining a source set
sourceSets {
    intTest
}

dependencies {
    intTestCompile 'junit:junit:4.12'
    intTestRuntime 'org.ow2.asm:asm-all:4.0'
}

> gradle intTestClasses

// Assembling a JAR for a source set
task intTestJar(type: Jar) {
    from sourceSets.intTest.output
}
//creating javadoc 
task intTestJavadoc(type: Javadoc) {
    source sourceSets.intTest.allJava
}

//running test in source set 
task intTest(type: Test) {
    testClassesDir = sourceSets.intTest.output.classesDir
    classpath = sourceSets.intTest.runtimeClasspath
}

///* Gradle: plugin : application plugin 
//build.gradle
apply plugin: 'application'

//The Application plugin facilitates creating an executable JVM application. 
//It makes it easy to start the application locally during development, 
//and to package the application as a TAR and/or ZIP including operating system specific start scripts.

//Applying the Application plugin also implicitly applies the Java plugin. 
//The main source set is “application”.

//Applying the Application plugin also implicitly applies the Distribution plugin.
// A 'main' distribution is created that packages up the application, including code dependencies 

///Configure the application main class
mainClassName = "org.gradle.sample.Main"

$ gradle run 
$ gradle run --debug-jvm 

//Configure default JVM settings
applicationDefaultJvmArgs = ["-Dgreeting.language=en"]

//Configure custom directory for start scripts
executableDir = "custom_bin_dir"

//A main distribution is created with the following content:
//Distribution content          Location Content 
(root dir)                      src/dist
lib                             All runtime dependencies and main source set class files.
bin                             Start scripts (generated by createStartScripts task).
 

//Include output from other tasks in the application distribution
task createDocs {
    def docs = file("$buildDir/docs")
    outputs.dir docs
    doLast {
        docs.mkdirs()
        new File(docs, "readme.txt").write("Read me!")
    }
}

distributions {
    main {
        contents {
            from(createDocs) {
                into "docs"
            }
        }
    }
}
//Creates OS specific scripts to run the project as a JVM application.
$ gradle startScripts
 
 
//Automatically creating files for distribution
$ gradle installDist 
$ gradle distTar 
$ gradle assemble 
$ gradle distZip
> Task :createDocs
> Task :compileJava
> Task :processResources NO-SOURCE
> Task :classes
> Task :jar
> Task :startScripts
> Task :distZip






///*Gradle :init build : Building Java Application (application means command line application)
//check reference - https://docs.gradle.org/4.8/userguide/application_plugin.html

$ mkdir java-demo
$ cd java-demo
$ gradle init --type java-application


//dir structure 
+-- build.gradle
+-- gradle    
¦   +-- wrapper
¦       +-- gradle-wrapper.jar
¦       +-- gradle-wrapper.properties
+-- gradlew
+-- gradlew.bat
+-- settings.gradle
+-- src
    +-- main
    ¦   +-- java  
    ¦       +-- App.java
    +-- test      
        +-- java
            +-- AppTest.java

//Check settings.gradle 
rootProject.name = 'java-demo'

//check build.gradle 
apply plugin: 'java'
apply plugin: 'application'

repositories {
    jcenter()  //public Bintray Artifactory repository
}

dependencies {
    compile 'com.google.guava:guava:20.0'  
    testCompile 'junit:junit:4.12'         
}

mainClassName = 'App'  

//application plugin designates one class as having a main method, 
//which can be executed by the build from the command line


//src/main/java/App.java
public class App {
    public String getGreeting() {
        return "Hello world.";
    }

    public static void main(String[] args) {  
        System.out.println(new App().getGreeting());
    }
}

//src/test/java/AppTest.java 
import org.junit.Test;
import static org.junit.Assert.*;

public class AppTest {
    @Test public void testAppHasAGreeting() {
        App classUnderTest = new App();
        assertNotNull("app should have a greeting",
                       classUnderTest.getGreeting());
    }
}
//build 
$ gradle build 
//run the main class 
$ gradle run 
//test 
$ gradle -i test    // include -i (loglevel=info) to get any stdout(println) output from Test script
//Creates a full distribution ZIP archive including runtime libraries and OS specific scripts.
$ gradle distZip  //distTar
//Creates OS specific scripts to run the project as a JVM application.
$ gradle startScripts 








///*Gradle :init build : Building java Library  - https://docs.gradle.org/4.8/userguide/java_library_plugin.html
//Note - Other plugins, such as the Groovy plugin, may not behave correctly with this plugin 
$ mkdir building-java-libraries
$ cd building-java-libraries

$ gradle init --type java-library

//settings.gradle
rootProject.name = 'building-java-libraries' 1

//build.gradle 
apply plugin: 'java-library'

repositories {
    jcenter() 1
}

dependencies {
    api 'org.apache.commons:commons-math3:3.6.1' //a dependency which is exported to consumers, that is to say found on their compile classpath. 
    implementation 'com.google.guava:guava:21.0' //a dependency which is used internally, and not exposed to consumers on their own compile classpath. 
    testImplementation 'junit:junit:4.12' 
}

//src/main/java/Library.java 
public class Library {
    public boolean someLibraryMethod() {
        return true;
    }
}
//src/test/java/LibraryTest.java
import org.junit.Test;

public class LibraryTest {
    @Test public void testSomeLibraryMethod() {
        Library classUnderTest = new Library();
        assertTrue("someLibraryMethod should return 'true'", classUnderTest.someLibraryMethod());
    }
}

//build 
$ gradle build 

//test report at build/reports/tests/test/index.html.
//jar at build/libs 


//To customize the build 
//build.gradle
version = '0.1.0'

//to customise generated MANIFEST.MF 
//build.gradle
jar {
    manifest {
        attributes('Implementation-Title': project.name,
                   'Implementation-Version': project.version)
    }
}

$ gradle jar 

//For adding distribution 
apply plugin: 'java-library-distribution'

distributions {
    main{
        baseName = 'my-name'
    }
}


$ gradle distZip   //Creates a full distribution ZIP archive including runtime libraries including all files under src/main/dist added to root of zip 


//The java-library plugin has built-in support for Java’s API documentation tool via the javadoc task.
//Change javadoc comment 
/** This java source file was generated by the Gradle 'init' task.
 */
public class Library {
    public boolean someLibraryMethod() {
        return true;
    }
}
$ gradle javadoc 



///* Gradle: Plugin : Using Groovy Plugin 
//The Groovy plugin extends the Java plugin to add support for Groovy projects. 
//It can deal with Groovy code, mixed Groovy and Java code, and even pure Java code

//The Groovy compiler will always be executed with the same version of Java that was used to start Gradle

//Using the Groovy plugin
apply plugin: 'groovy'

///Details 
project layout
    src/main/java           Production Java source 
    src/main/resources      Production resources 
    src/main/groovy         Production Groovy sources. May also contain Java sources for joint compilation. 
    src/test/java           Test Java source 
    src/test/resources      Test resources 
    src/test/groovy         Test Groovy sources. May also contain Java sources for joint compilation. 
    src/sourceSet/java      Java source for the given source set 
    src/sourceSet/resources Resources for the given source set 
    src/sourceSet/groovy    Groovy sources for the given source set. May also contain Java sources for joint compilation. 
Groovy plugin - tasks
    Since extends 'java' plugin , all java tasks are available 
    compileGroovy
        dependsOn:compileJava
        type:GroovyCompile
        Compiles production Groovy source files.
    compileTestGroovy
        dependsOn:compileTestJava 
        type:GroovyCompile 
        Compiles test Groovy source files.
    compileSourceSetGroovy 
        dependsOn:compileSourceSetJava 
        type:GroovyCompile 
        Compiles the given source set’s Groovy source files.
    groovydoc 
        type:Groovydoc
        Generates API documentation for the production Groovy source files. 
Dependencies to tasks added by the Java plugin
    classes  dependsOn:compileGroovy
    testClasses  dependsOn:compileTestGroovy
    sourceSetClasses  dependsOn:compileSourceSetGroovy
Source set properties
    The Groovy plugin adds the following convention properties to each source set in the project. 
    Use these properties in  build script as though they were properties of the source set object.
    groovy          :SourceDirectorySet (read-only)
    groovy.srcDirs  :Set<File>
    allGroovy       :FileTree (read-only)
    allJava 
    allSource
GroovyCompile properties 
    classpath 
    destinationDir 
    excludes 
    groovyClasspath 
    groovyOptions 
    includes 
    options 
    source 
    sourceCompatibility 
    targetCompatibility 
    //Methods 
    exclude(excludeSpec) 
    exclude(excludes) 
    exclude(excludes) 
    exclude(excludeSpec) 
    include(includeSpec) 
    include(includes) 
    include(includes) 
    include(includeSpec) 
    source(sources) 


//Configuration of Groovy dependency
repositories {
    mavenCentral()
}

dependencies {
    compile 'org.codehaus.groovy:groovy-all:2.4.10'
    testCompile 'org.codehaus.groovy:groovy-all:2.4.10'

}





///*Gradle :init build : Building Groovy Library 
$ mkdir building-groovy-libraries
$ cd building-groovy-libraries
$ gradle init --type groovy-library


//settings.gradle
rootProject.name = 'building-groovy-libraries' 

//build.gradle 
apply plugin: 'groovy'

repositories {
    jcenter() 1
}

dependencies {
    compile 'org.codehaus.groovy:groovy-all:2.4.10' 
    testCompile 'org.spockframework:spock-core:1.0-groovy-2.4' 
    testCompile 'junit:junit:4.12' 
}


//src/main/groovy/Library.groovy
class Library {
    boolean someLibraryMethod() {
        true
    }
}


//src/test/groovy/LibraryTest.groovy 
import spock.lang.Specification

class LibraryTest extends Specification {
    def "someLibraryMethod returns true"() {
        setup:
        def lib = new Library()

        when:
        def result = lib.someLibraryMethod()

        then:
        result == true
    }
}


$ gradle build 


///**** Groovy Test - Spock 
//Spock can be used for unit, integration or BDD (behavior-driven-development) testing, 


//Testing with Specifications
@Grab('org.spockframework:spock-core:1.0-groovy-2.4')
import spock.lang.*

class StackSpec extends spock.lang.Specification {

    def "adding an element leads to size increase"() {  
        setup: "a new stack instance is created"        //Setup block
            def stack = new Stack()

        when:                                          //pre condition , can access setup block's var
            stack.push 42

        then:                                           //result
            stack.size() == 1
    }
}


///Testing with Table

class HelloSpockSpec extends spock.lang.Specification {
  def "length of Spock's and his friends' names"() {
    expect:
    name.size() == length

    where:
    name     | length
    "Spock"  | 5
    "Kirk"   | 4
    "Scotty" | 6
  }
}  

///Specification with expect

import spock.lang.*

// Hit 'Run Script' below
class MyFirstSpec extends Specification {
  def "let's try this!"() {
    expect:
    Math.max(1, 2) == 3
  }
}

//Data Driven spock
import spock.lang.*

@Unroll
class DataDrivenSpec extends Specification {
  def "maximum of two numbers"() {
    expect:
    Math.max(a, b) == c

    where:
    a << [3, 5, 9]
    b << [7, 4, 9]
    c << [7, 5, 9]
  }

  def "minimum of #a and #b is #c"() {
    expect:
    Math.min(a, b) == c

    where:
    a | b || c
    3 | 7 || 3
    5 | 4 || 4
    9 | 9 || 9
  }

  def "#person.name is a #sex.toLowerCase() person"() {
    expect:
    person.getSex() == sex

    where:
    person                    || sex
    new Person(name: "Fred")  || "Male"
    new Person(name: "Wilma") || "Female"
  }

  static class Person {
    String name
    String getSex() {
      name == "Fred" ? "Male" : "Female"
    }
  }
}


//Database Driven

import groovy.sql.Sql
import spock.lang.Shared
import spock.lang.Specification

class DatabaseDrivenSpec extends Specification {
  @Shared sql = Sql.newInstance('jdbc:mysql://localhost:3306/groovy', 'root', '', 'com.mysql.jdbc.Driver')
  
  // insert data (usually the database would already contain the data)
  def setupSpec() {
    sql.execute("create table maxdata (id int primary key, a int, b int, c int)")
    sql.execute("insert into maxdata values (1, 3, 7, 7), (2, 5, 4, 5), (3, 9, 9, 9)")
  }

  def "maximum of two numbers"() {
    expect:
    Math.max(a, b) == c

    where:
    [a, b, c] << sql.rows("select a, b, c from maxdata")
  }
}






///**** Groovy operators

///* if else 
//Anything nonempty is true , else false (= 0,"", [],[:] null)
def x = 0
x as Boolean 

if(!x) {
  println "OK"
}

///* Space ship operator <=> , returns -1, 0, +1
1 <=> 2  //-1 

//All comparison operators are null-safe in groovy, 
//and null is always less than any non-null value

//content checking: == , uses a.compareTo(b) at first ,if not available, then a.equals(b) 
//identity checking : 'is'  (in java == for object), Note .is(arg) isa method, not operator 
new Integer(1) ==  new Long(1)  //type conversion
new Integer(1).is new Long(1)

//boolean operator && , ||, !
//Shorts circuit 


///HandsOn 
define two variables , name and age 
if name is "XYZ" and age is below 40, 
print "suitable" 
else if age is greater than 50, print "old", 
else print "OK"
For all other names, print "not known" 

///* for/while  loop (like java), no do..while loop 
def c = 0 
while(c < 3) {
    println c 
    c++
}
def lc = [1,2,3] 
for(def i = 0; i< 3; i++){
    println lc[i]
}
//OR 
for(def e: lc){
    println(e)
}


///* Few operations on Numeric 
//BigInteger and BigDecimal supports +, -, *, ** etc via GDK
//BigDecimal / with Double, float => Double , / with Integer => BigDecimal 
// BigDecimal / BigDecimal => BigDecimal with certain percision
//for extra precision, Use BigDecimal.divide(BigDecimal, new java.math.MathContext(precision)) 
//** for power , Result can be Integer or Long or Double 
//for Integer , bitwise and, or, xor are  - &, |, ^ 
//Integer has .intdiv(Integer) to get int division else int/int => BigDecimal, int/double => Double

def  x = "7"  as Integer
def y = 22 as BigDecimal 
z = y/x 
[z, z.class]  //Result: [3.1428571429, class java.math.BigDecimal]

def  x = "7"  as Integer
def y = 22 as BigDecimal 
z = y.divide(x)       //BigDecimal division, Error 

z = y.divide(x, new java.math.MathContext(10)) //10 digits 
[z, z.class]
[3.142857143, class java.math.BigDecimal]

def  x = "7"  as Integer 
def y = 22  
z = y.intdiv(x) 
[z, z.class]   //Result: [3, class java.lang.Integer]

///* To convert from one Numeric, String to another Numeric, use 
//toBigDecimal()   toBigInteger() toDouble()  toFloat()  toInteger()  toLong() 


///* GSTRNG- var Interpolation 
def name = "Das"
println "May is name is $name"
println "My name is ${name.toUpperCase()}"
println "My name is ${name + ' ....'}"

///*Multiple assignments, swapping
def (aa,ba) = [1,2]
println("$aa $ba")
(ba,aa) = [aa,ba] 
println("$aa $ba")

///* Number type suffixes
//Type			Suffix
BigInteger		G or g
Long			L or l
Integer			I or i or no suffix
BigDecimal		no suffix
Double			D or d
Float			F or f


///Operator precedence from highest to lowest:
//Level Operator(s) 	                    Name(s)
1       new   ()                            object creation, explicit parentheses
        ()   {}   []                        method call, closure, literal list/map
        .   .&   .@                         member access, method closure, field/attribute access
        ?.   *   *.   *:                    safe dereferencing, spread, spread-dot, spread-map
        ~   !   (type)                      bitwise negate/pattern, not, typecast
        []   ++   --                        list/map/array index, post inc/decrement
        
2       **                                  power
        
3       ++   --   +   -                     pre inc/decrement, unary plus, unary minus
        
4       *   /   %                           multiply, div, remainder
        
5       +   -                               addition, subtraction
        
6       <<   >>   >>>   ..   ..<            left/right (unsigned) shift, inclusive/exclusive range
        
7       <  <=  >  >=  in  instanceof  as    less/greater than/or equal, in, instanceof, type coercion

8       ==   !=   <=>                       equals, not equals, compare to	
        =~   ==~                            regex find, regex match

9       &                                   binary/bitwise and

10      ^                                   binary/bitwise xor

11      |                                   binary/bitwise or

12      &&                                  logical and

13      ||                                  logical or

14      ? :                                 ternary conditional
        ?:                                  elvis operator

15      =   **=   *=   /=   %=   +=   -=    various assignments
        <<=   >>=   >>>=   &=   ^=   |=
	

///Special operators
Spaceship
    <=>			
    Used in comparisons, returns -1 if left is smaller 0 if == to right or 1 if greater than the right
    //Example 
        3 <=> 4   //-1
Regex find				
    =~			
    Find with a regular expresion
    //Example 
        def x = "I am OK"
        def m = x =~ /(\w+)/
        m as Boolean //true 
        m[0]  //[I,I] ie [fullMatch, firstGroup, 2ndGroup..]
        m[1]  //[am, am]
        m[2]  //[OK, OK]
        m.size() //3
        m.class.methods.name.toSet()
        // [getClass, hasTransparentBounds, requireEnd, wait, useTransparentBounds, notifyAll, pattern, replaceFirst, regionStart, replaceAll, notify, lookingAt, toMatchResult, quoteReplacement, find, hashCode, end, group, start, regionEnd, matches, hasAnchoringBounds, appendReplacement, appendTail, groupCount, equals, reset, toString, region, hitEnd, useAnchoringBounds, usePattern]
Regex match				
    ==~			
    Get a match via a regex, (only for full string  match ), ie java matches() of String
    //Example 
        def x = "I am OK"
        x ==~ "I am OK"   //true 
Java Field Override 	
    .@			
    Direct access to field bypassing getter/setter
    //Example 
        class X
        {
            def field
            def getField()
            {
                field + 1
            }
        }
        x = new X(field:1) //x.field = 1
        println x.field    // getField(), 2
        println x.@field   // 1
Spread					
    *.			
    Used to invoke an action on all items of an aggregate object, ie, parent.collect{ each -> each?.action }
    //Example 
        def a = 1
        a.class.methods*.name
        //OR
        a.class.methods.name    //GPath, only for property/field and getXYZ() 
        //in function 
        int function(int x, int y, int z) {
            x*y+z
        }
        def args = [4,5,6]
        assert function(*args) == 26
        //Spread list elements by *list
        def items = [4,5]                      
        def list = [1,2,3,*items,6]            
        assert list == [1,2,3,4,5,6]           
        //Spread map elements, by *:map
        def m1 = [c:3, d:4]                   
        def map = [a:1, b:2, *:m1]            
        assert map == [a:1, b:2, c:3, d:4]    
Spread Java Field		
    *.@			
    Amalgamation of the above two
Method Reference		
    .&			
    Get a reference to a method, can be useful for creating closures from methods
    //Example 
        def fun (x ) { x}
        def a = this.&fun           // inside script or inside class
        def str = 'example of method reference'          
        def fun = str.&toUpperCase          	//for particular's intance              
        def upper = fun()                                  
        assert upper == str.toUpperCase() 
asType Operator			
    as			
    Used for groovy casting, coercing one type to another.
    //Example 
        Integer x = 123
        String s = (String) x         
        //OR
        String s = x as String   
        //OR
        String s = x.asType(String)
Membership Operator		
    in			
    Can be used as replacement for collection.contains()
    //Example 
        def list = ['Grace','Rob','Emmy']
        assert ('Emmy' in list)    
        def map = [ 1:'Grace', 2:'Rob', 3:'Emmy']
        1 in map //true
Safe Navigation			
    ?.			
    returns null instead of throwing NullPointerExceptions when accessing member
    //Example 
        String x = null
        println x?.size() //null 
Elvis Operator 			
    ?:			
    Shorter ternary operator, a ?: "default" is equivalent to 'a ? a : "default"'
    //Example 
        def user = null
        def displayName = user ? user : "Anonymous" 	//traditional ternary operator usage
        println  user ?: "Anonymous"  	// more compact Elvis operator - does same as above



        
///**** Groovy - Closure and Function 

///* closure 
def fxc = {int xi -> println xi }
fxc = { println it }   //same as above 

fxc = { -> println "NoArgs"} // no Arg 

//no overloading as variable 'fxc' gets overritten 
//can have multiline , don't use {} as it's closure syntax 
//last line is return 
fxc = { def xi1 -> 
            println "def" 
            xi1*2          
       }
fxc(2)
fxc(2.0)

//with default 
def f = {  x, y=2 -> x+y }
f(2)
f(2,3)


///* Number functional 
//Check GDK -  http://www.groovy-lang.org/gdk.html

0.1.upto( 10 ) {  //inclusive , BigDecimal, Integer, step = 1
  println it
}

0.step( 10, 2 ) { //only for BigDecimal Integer 
  println it
}

10.times {  //for for BigDecimal, Integer
  println it
}
10.5.downto(0) { // inclusive , BigDecimal, Integer, step =1 
  println it
}

///Hands on -Find Pythogorous triplets below 100 


def res = [] as Set
def limit = 99
3.upto(limit){ x ->
  x.upto(limit){ y ->
    y.upto(limit){ z ->
       if ( z*z == (x*x + y*y) )
           res << [z,y,x]
           }
        }
    }
res.size()




///* Function 
//last line is return , or use 'return' explicitly 
def  fun( x, y=20) {
  def z = x * y
  z
}

//Various way arg passing 
println fun(y=20, x=10)
println fun(10) 
println fun(10, y=30)  

///Hands On - convert the above Pythogrous triplets into two arg function 


//Nested funtion not possible, but nested closure possible 
//ERROR
def fun(x){
    def z(y){
        x+y 
    }
    z
} 
//OK 
def fun(x){
    def z= { y -> x+y}
    z
} 
fun(2)(3)


//first arg is Map 
def fun1(m) {
  m.x * 2
}
println fun1(x:2)

//Scope - LEGB 
def x = 23 
def println = 3 
println(x) //G , hence Error 

def fun(y){
    println z+y 
}
fun(2) //Error 
//OK 
z=20
fun(2) //22


///* Function - Overloading OK as long as type differs
//Note def is Object 
def fx(int x){  //1
  println 'fx(int x)'
}

def fx( def y){  //2
  println 'fx( def y)'
  }
  
def fx( def x, def y){  //3
    println "fx( def x, def y)"
} 

def fx( Integer... x){   //4
    println "Int ${x?.size()}"
} 
   
def fx( Object... x){   //5
    println "Obj ${x?.size()}"
} 
   
fx(2)  //1
fx("OK")   //2
fx(2,3) //3
fx() //5 
fx(1,"OK",3.0)  //5 
fx(1,2,3) //4

 


///**** Groovy  String, Range, Collections - basic operations 

///*** Groovy - String and Character 
'a single quoted string'
"a double quoted string"

'''line one
line two
line three'''

assert 'ab' == 'a' + 'b'  //concatenation

//\n, \t .. etc are allowed as escaping characters

//Slashy string  /..../  , no need to escape backslashes, use with regex
//escape only forward slashes, can be multiline and can be GString via ${} interpolation
//An empty slashy string is not //  , it is comment


//Dollar slashy string    $/..../$   , like /.../ but escape character is $, 
//can not have GString


///* Characters 
//Must use explicit type char or as or (char) casting because '..' is String in Groovy
char c1 = 'A' 
assert c1 instanceof Character

def c2 = 'B' as char 
assert c2 instanceof Character

def c3 = (char)'C' 
assert c3 instanceof Character

Character.methods.name


///* String is CharSequence, hence all Collection methods can be used on each Char 
//http://www.groovy-lang.org/gdk.html

def sx = "Groovy"

sx.size()
sx[0]
"o" in sx.toList() //for only char , 'in 'with String not possible , use contains(str)
sx.contains("oo")  //checking

//iteration
for(ch in sx){
   println ch 
}
for(def ch : sx){
   println ch 
}
sx.each { ch -> println ch }

//String is immutable 
def sx1 = sx << " Grrovy" //Appends, converts to new String

sx[0..2] //inclusive 
sx[-2..<-5] //exclusive 
sx[-1]
sx[-1..-sx.size()]  // reverse ===> nhoj  , size() or length() are same

//All Java methods, eg trim, startsWith, endsWith(suffix) , startsWith(prefix)
//split(deliminator),  length(), isEmpty(), trim(), toLowerCase(), 
//And many GDK methods on String and CharSequence 
sx.toUpperCase()
sx.trim()
sx.startsWith("G")   //===> true
//convert to List of chars 
sx as List 
sx.toList()
sx.split(/\s+/)  //split takes Regex 

//COnverion to number , toDouble(), toInteger()
try{
    "123.k".toDouble()
} catch(ex){
    println(ex)
}

//command execution 
def x = "ls -al".execute()  //executing command
println(x.text)  //x.err or x.in or x.out are err or in or out
def lines = x.text.split(/\n/)


///HandsOn - can you download "http://www.google.com"

def x = "http://www.google.com"
x.toURL().text

///HandsOn  - encode/decode base 64 

def s = 'Hello Groovy '
String encoded = s.bytes.encodeBase64().toString()
byte[] decoded = encoded.decodeBase64()
assert s == new String(decoded)


///HandsOn =given string 
def str =  "Hello Groovy Hello"
//Print frquency of alphabets 



str.each { ch ->
    count = 0
    str.each { ch1 -> 
     if (ch == ch1) 
         count++         
         }
     println "$ch $count"
     
   }


     

///*** Groovy - Regex 
//Note =~, ==~ can take String as regex or java.util.regex.Pattern
// str=~pattern returns Matcher and str==~pattern returns bool if full String contains the Pattern 

def str = "Groovy Groovy"

if (str ==~ /\w+\s+\w+/){ //string must fully match the pattern 
    println "found"
}

//FInding all pattern 
str.findAll(/\w+/) //returns list of all found match, note grouping () does not work 
//Spliting 
str.split( /\s+/)   //Returns list, String is regex pattern, dont pass java.util.regex.Pattern

//Matcher Object 
def match = ( str =~ /(\w+)/)   //returns Matcher 
match[0] //[fullmatch, group1, group2,...] 
match[1][1]  //2nd match, group1

//Iteration of matcher 
match.each { m -> println m[1] }  //for any number of groups 
match.each { m, g -> println g }  // fullmatch, group1, group2, ...
//OR Use eachMatch of the String 
//if no group 
res.eachMatch(/\w+/) {m ->
  println m
}
//If groups , then m is array ie [fullmatch, group1, group2,...] 
res.eachMatch(/(\w+)/) {m ->
  println m
}
//in this case, destructure as m, g1,g2,...
res.eachMatch(/(\w+)/) {m,g ->
  println g
}

//replaceFirst, replaceAll 
str.replaceAll(/(\w+)/, /$1s/)
//If Pattern does not contain group, m is found String 
str.replaceAll(/\w+/){ m -> m.toUpperCase() }
//If pattern contains group, then m is array ie [fullmatch, group1, group2,...] 
def str = "Name Groovy"
str.replaceAll(/Name\s+(\w+)/){ m -> println "${m.class}:$m"}   //class java.util.ArrayList:[Name Groovy, Groovy]
//in this case, destructure as m, g 
str.replaceAll(/Name\s+(\w+)/){ m,g -> println "$m,$g"} //Name Groovy,Groovy


//Note ~/ / , converts a string to Pattern 
def pat = ~/(\s+)/
pat.class // java.util.regex.Pattern
pat.split("A B C")



   


///*** Groovy - StringBuffer 
//StringBuffer is mutable
def x = new StringBuffer()

x.append("OK")
x.append(" I am ")

x[0]        //K
x[0..<1] = 'K' as char   //KK I am 


///*** Groovy - List 
def le = []
println le.empty  // or le.isEmpty()

def l = [1,2,3, *[1,2,3]] //spreading 

//heterogeneous and mutable 
def ll = [1,2,"OK", [1,2,3]]
ll[-1][-1] = 30
println ll //[1,2,"OK", [1,2,30]]

//List operations 
le << 2 << 3  //append element 

ll + [2,3,4]  // append list , immutable , RHS can be Iterable, Collection , List, Object 
ll.plus(1, ll) //1st arg, index 

ll += [2,3,4] 
ll -= [2]  //all 2 removed 
println(ll)
ll.remove(0) //index based remove 
println(ll)

ll.clone() //shallow copy , deepCopy,- convert to json and then read it back 

"OK" in ll   //member existance 
le == [2,3]  //content checking 
le.is([2,3]) //reference checking 
//le < [30,40] - no comparison 
println ll.size()
println ll[0]

//advanced slicing 
println ll[0..2]
ll[0..<2] = ["changed", 2] //delete 0,1 and replace by RHS 
println ll    //[changed, 2, OK, [1, 2, 3]]
ll[0..<0] = ["changed", 2] //prepend 
ll[ll.size()..<ll.size()] = ["changed", 2] //append 
ll[2..<2] = ["changed", 2] //insert at i 


//beyond size
ll[25] == null //index returns null
ll[10] = 200   ///intermidiate values are null

//careful , reference copying , use clone()
def ll = [1,2,3]
def lg = [ll,ll]
println(lg)
lg[-1][0] = 200  //change lg
println(ll)     //ll is changed 


//Iterating on a list
def list= ['a',2,'c',4]

for (def ele: list) {  //def is must 
   println("Item: $ele")
}

//Or
list.each {
    println "Item: $it" // `it` is an implicit parameter corresponding to the current element
}
for (e in list) {   //using in
    println e
}

///HandsOn  - Given [1,2,3], do [1,4,9]




///*** Groovy - Range 
///Range - list in disguise
def r1 = 0..15 
def r2 = 0..<15 
println r1.size()
println r2.size()
//all list methods can be used
12 in r1 

def ri = 0..15
def rc = 'a'..<'l'

println ri.toList()
println rc.toList()
'b' in rc 
ri.each { e ->  }


///*** Groovy - Array
//Java Arrays - by 'as T[]', homogeneous contents, does not grow/shrink, fixed size, 
//all List methods can be used except sort

String[] arrStr = ['Ananas', 'Banana', 'Kiwi']  
assert arrStr instanceof String[] 

//or with initial size
def p = new Integer[10]
p[0] = 2  //[2, null, null, null, null, null, null, null, null, null]

   
//Create using type cast 
def numArr = [1, 2, 3] as int[]      
assert numArr.size() == 3
numArr[0] = 200
//numArr[10] = 6      		// Does not grow/shrink. fixed size , java.lang.ArrayIndexOutOfBoundsException
//numArr[0..<0]  = [2,3]   // Can not grow/shrink
println(numArr[0..1])     //OK
// << not possible on Array as Array does not grow

//Conversion to List by ' as List'
def numArr = [1, 2, 3] as int[]   
assert (numArr as List) instanceof List

//Multidimensional by as [][] 
def matrix3 = new Integer[3][3]       
assert matrix3.size() == 3

Integer[][] matrix2                    
matrix2 = [[1, 2], [3, 4]]
assert matrix2 instanceof Integer[][]

def matrix1 = [[1, 2], [3, 4]] as Integer[][]
assert matrix1.size() == 2





///*** Groovy - Set 
//unordered non duplicates 

def se = [1,2,3,4,1,2,3,4] as Set //as SortedSet  for SortedSet 
se = [1,2,3,4,1,2,3,4].toSet()

se << 100            //add 
se -= [100] as Set  //removing 

se[0]                       // Ok, but unordered, hence no meaning, 
//se[0..1]                  //ERROR
//se[0]  = 200              //ERROR

se +  ([100,200,1] as Set)                    //Union , returns new Set
se.intersect( [100,200,1] as Set)      // Intersect , [1]
se.disjoint( [100,200,1] as Set)        //false
se - [1,2,3] as Set                    //Set difference [4,5]
//All list methods  can be used 

//Returns true if the two sets have the same size, and every member of the specified set is contained in this set 
Set s1 = ["a", 2]
def s2 = [2, 'a'] as Set
Set s3 = [3, 'a']
def s4 = [2.0, 'a'] as Set
def s5 = [2L, 'a'] as Set
assert s1.equals(s2)
assert !s1.equals(s3)
assert s1.equals(s4)
assert s1.equals(s5)



///HandON: how many methods are extra in SortedSet compared to Set 
(SortedSet.methods.name as Set) - (Set.methods.name as Set)


///Handson: frequency of words using list methods , remove duplicates 
//note split returns Array, hence convert to List 
def str =  "Hello Groovy Hello"

str.split(/\s+/).toList().toSet().each { wd ->     
      println "$wd ${str.split(/\s+/).count{wd2 -> wd == wd2}}"  
}


///*** Groovy - Queue 
def qu = [1,2,3] as Queue //actually DeQueue
qu.addFirst(20)
qu.addLast(30)
qu.removeFirst()
qu.removeLast()


///*** Groovy - Stack 
def st = [1,2,3] as Stack 
st.push(20)
st.pop()





///*** Groovy - Map
def me = [:]
println me.isEmpty()  //checking empty 

me.entrySet()
me.keySet()   //keys 
me.values()  //values

def mll = ['ok': 1, nok: 2, 3:4]  //by default, Key is string if not Numeric or specify by "key", 

me << [ok: 2] //append element 
mll + [new:2]  // append another Map, immutable  
mll += [new: 30] 
mll -= [new:30]  // newremoved 
println(mll)

mll.clone() //shallow copy //for deepcopy converts to json and read it back 

"ok" in mll 
me == [ok:2] //content checking

println mll.size()
println mll['nok']
println mll.nok   //only for string key 

mll[10] = 200   //ading new key 

println mll

//non existing key 
mll[25] == null //index returns null
mll.get(100) //get lso returns null 
//or return default value 
mll.get(100, "default")



//iteration 
for(kv in mll) { //kv is EntrySet .key, .value
  println kv.key
}

//either take Entry(use .key, .value) or two args k,v 
mll.each {kv -> println(kv.key) }
mll.each {k,v -> println(v) }




///*** Groovy - List, Set, Map - Synchronized 
lst.asSynchronized()
set.asSynchronized()
map.asSynchronized()

///*** Groovy - List, Set, Map - Immutable 
lst.asImmutable()
set.asImmutable()
map.asImmutable()


        
///**** Groovy - switch 
// switch(a) {case b: } means b.isCase(a) 
//So class b can customize meaning of isCase 
//for example, for list.isCase(a) means "Does a in list", same for Range ie range.isCase() means "is a in rnage"
//For Map, map.isCase(a) means "Does a in Map's key"
//For Class, class.isCase(a) means " Is a instanceof class"
//For Regex , regex.isCase(a) means " a ==~ regex"
//For Closure , closure.isCase(a) means " is return of closure(a) a true"


def values= [
    'abc': 'abc',
    'xyz': 'list',
       18: 'range',
       31: BigInteger,
       40: Integer,
       50.5d:Double ,
  'dream': 'something beginning with dr',
     1.23: 'none',]


def sres = values.each{
  def result  
  switch( it.key ){               //if switched expression matches case-expression, execute all
                                //statements until 'break'

    case 'abc':                 // object equal to ,  it.key == 'abc'
      result= 'abc'
      break

    case [4, 5, 6, 'xyz']:        // list membership  it.key in [4,5,6, 'xyz'] or [4,5,6, 'xyz'].isCase(it.key)
      result= 'list'
      break
      
    case [foo:true, bar:false]:  //Map membership,  it.key in [foo:true, bar:false]
     result= 'map'                
     break

    case 'xyz':                 //this case is never chosen because 'xyz' is matched by
                                //previous case, then 'break' executed
      result= 'xyz'
      break

    case 12..30:                // range membership,   it.key in 12..30
      result= 'range'
      break

    case Integer:                // instanceOf ,   it.key instanceOf Integer

      result= Integer             //because this case doesn't have a 'break', result
                                  //overwritten by BigInteger in next line

    case BigInteger:            // instanceof ,  it.key instanceof BigInteger
      result= BigInteger
      break

    case ~/dr.*/:                // RegEx checking  it.key ==~  ~/dr.*/
      result= 'something beginning with dr'
      break

    case { it instanceof Double && it>30.0}:     //use Closure, returns true for it's case,  key is accessed by 'it'
      result= 'result is > 30'                  
      break

    default:                    // for 1.23 case
      result= 'none'
  }
  
  println result

}

println sres

  
  
  
///**** Groovy Object Oriented and AST transformation
//don't use field (instance variable with access control) as recomended as Groovy really does not follow access modifier  
//private/protected fields/methods do not restrict access from public Groovy user from same/different package
//Only subclass can not access private super fields/methods, subclass can access protected fields/methods

//Note - instance variable without access control(ie public) - property 

class Person implements Serializable{
  private String first
  String last
  
}

def x = new Person(first:"D", last:"N")
x.first //can access 
def xd = new Person() //default

//Note by default only default and maplike ctor is generated(and tuple ctor with TupleConstructor)
//Any user defined ctor would remove those including TupleConstructor 


//AST does not take field into account 
//(for that explicitly mention includeFields=True), Many such options are there 
//http://groovy-lang.org/metaprogramming.html#_available_ast_transformations

@groovy.transform.Canonical     //toString, hash, equals, tuple constructor 
@groovy.transform.Sortable       //compareTo and compatorByFIELD based on Order 
@groovy.transform.AutoClone
class Person implements Serializable{
    String firstName          //property, auto get*()/set*() generated (not for field)
    String lastName           //property
}


def cl = new Person('Ada1','Lovelace1')            //tuple constructor
Person lt = ['Ada2','Lovelace2']                        // list constructors, order matters 
def mp = [firstName:'Ada3', lastName:'Lovelace3'] as Person     // map constructor,order does not matter 
def mpLike = new Person (firstName:'Ada', lastName:'Lovelace') //map like constructor, order does not matter 

println mpLike

def de  = new Person()                                     //default constructor
//inside 'with', this = de 
de.with {        
       setFirstName("Das")       
       lastName = "Das" 
       }              

println(de)    
//shallow copy
def de1 = de.clone()
println (de1.is(de))
println(de1 == de)

//few properties changed 
def y = x.clone().with{
  last ="ND"
  delegate   //return delegate 
}
//Easy construction 
@groovy.lang.Newify([Person])  //[class1, class2, ...]
def pl = [ Person("N","D"), Person("M","E")] //python style 
def pl = [ Person.new("N","D"), Person.new("M","E")] //ruby style 


//Sort 
def lp = [ cl, lt, mp, mpLike, de] 
println( lp[0] > lp[1])  //from Sortable 
lp.sort() //inplace 
lp.sort(false){ p -> p.first } //sortBy
println( lp.sort(false).reverse()*.lastName)
println( lp.sort(false).reverse().lastName) //GPATH

println(lp.sort(false, Person.comparatorByFirstName())*.toString())
Person.methods.name

///* spread operator 
def i = 0
i.class.methods*.name 
//equivalent, GPATH 
i.class.methods.name 

///* null safe operator 
class Person{
  String name 
  }
  
def p = new Person()
println (p?.name?.size())

def p = new Person(name:"Das") //by default , default and map ctor

p.name?.size()

///Above all are dynamic code , 
//But with below annotation, code generated is equivalent to java 
@groovy.transform.TypeChecked
    1. type inference is activated only for local variables and return of closure 
       Field, methods args and returns must be static typed 
    2. method calls are resolved at compile time
    3. all the compile time errors are shown 
    4. But methods are selected based on the inferred types of the arguments, not on the declared types
       Exactly like dynamic groovy 
        //In java 
        public Integer compute(String str) {
            return str.length();
        }
        public String compute(Object o) {
            return "Nope";
        }
        // ...
        Object string = "Some string";          
        Object result = compute(string);        
        System.out.println(result); //Nope 
        //in groovy 
        int compute(String string) { string.length() }
        String compute(Object o) { "Nope" }
        Object o = 'string'
        def result = compute(o)
        println result  //6 
    5.  But if runtime metaprogramming is used , this annotation would not be to catch 
        and program might fail at runtime 
        class Computer {
            int compute(String str) {
                str.length()
            }
            String compute(int x) {
                String.valueOf(x)
            }
        }

        @groovy.transform.TypeChecked
        void test() {
            def computer = new Computer()
            computer.with {
                assert compute(compute('foobar')) =='6'
            }
        }
        //monkey patching or runtime metaprogramming 
        Computer.metaClass.compute = { String str -> new Date() }
        test() //compilation successful but fails at runtime as runtime called metaClass version
    
@groovy.transform.CompileStatic
    1. All of the above 
    2. as well as immune to Monkey patching 
    4. statically compilation like Java , hence performance improvement (more visible for CPU bound code (close to java))
    Note: Performace of invokedynamic(JVM support ie in java bytecode) version of Groovy(Groovy 2 with >=JDK8) 
          is very close to statically compilation(using groovy-x-y-z-indy.jar)
          Use groovy\indy\* jar for this , by default non indy jars are used 
          and use groovy --indy foo.groovy  (--indy flag)
          OR in gradle 
            compileJava {
                sourceCompatibility = 1.7
                targetCompatibility = 1.7
            }             
            compileGroovy {
                groovyOptions.optimizationOptions.indy = true
            }             
            dependencies {
                compile 'org.codehaus.groovy:groovy-all:2.4.11:indy'
            }
            //OR in code 
            def compilerConfig = new CompilerConfiguration()
            compilerConfig.optimizationOptions.indy = true
             
            def shell = new GroovyShell(compilerConfig)


    
    
    

///*** Groovy - AST configuration 
//http://groovy-lang.org/metaprogramming.html#_available_ast_transformations
//Many AST has arguments/options 


@groovy.transform.ToString 
    creates 'String toString()' method of an class
    By default stringify only properties and does not include Super
    Options could be 
    includeNames, excludes, includes, includeSuper, includeFields, ignoreNulls	, 
    includeSuperProperties, includePackage	
@groovy.transform.EqualsAndHashCode 
    generates 'Boolean equals(Object o)' and 'int hashCode()' methods  
    After that can use == methods for comparing two objects
    By default includes properties and does not call Super
    Options could be 
    excludes, includes, callSuper, includeFields	
    //Examples:
        @EqualsAndHashCode(excludes=['firstName'])
        @EqualsAndHashCode(includes=['lastName'])
        @EqualsAndHashCode(callSuper=true)   //Whether to include super in equals and hashCode calculations
@groovy.transform.TupleConstructor  
    Creates tuple constructor . 
    Generates combinations of constructors, Any user defined constructor would removed these generated ones 
    By default includes properties
    Options could be 
    excludes, includes, includeProperties, includeFields, includeSuperFields, includeSuperProperties, force
    //Example
        @TupleConstructor(excludes=['lastName'])
        @TupleConstructor(includes=['firstName'])
        @TupleConstructor(includeFields=true)  
        @TupleConstructor(includeProperties=false)  
        @TupleConstructor(includeSuperFields=true)  
        @TupleConstructor(includeSuperProperties=true)
        @TupleConstructor(includeSuperProperties = true, callSuper=true)  //Should super properties be called within a call to the parent constructor rather than set as properties
        @TupleConstructor(force=true)  //By default, if class has any user defined constructor, no tuple constructor is generated. it inverses this default
@groovy.transform.Canonical
    The @Canonical meta-annotation combines 
    the @ToString, @EqualsAndHashCode and @TupleConstructor annotations
@groovy.transform.Immutable
    Similar to @Canonical and  all properties are made Immutable (ie properties are final)
    and all properties must be  well known Immutable object (builtin or userdefined with @ImmutableOptions)
@groovy.transform.ImmutableOptions
    Groovy’s immutability support relies on a predefined list of known immutable classes (like java.net.URI or java.lang.String)
    and fails if you use a type which is not in that list.
    Use @ImmutableOptions to specify a new type 
    //Example 
    import groovy.transform.Immutable
    import groovy.transform.TupleConstructor
    @TupleConstructor
    final class Point {
        final int x
        final int y
        public String toString() { "($x,$y)" }
    }
    @Immutable(knownImmutableClasses=[Point])
    class Triangle {
        Point a,b,c
    }
@groovy.transform.Memoized
    Creates a memoized version of a function 
    //Example 
    @Memoized
    long longComputation(int seed) {
        // slow computation
        Thread.sleep(100*seed)
        System.nanoTime()
    }
    def x = longComputation(1) // returns after 100 milliseconds
    def y = longComputation(1) // returns immediatly
    def z = longComputation(2) // returns after 200 milliseconds
@groovy.transform.TailRecursive
    Creates a TailRecursive function 
    //Example 
    @groovy.transform.TailRecursive
    def mysum( List lst, BigInteger acc =0G){
        if(lst.empty)
            return acc 
        else 
            return mysum(lst.tail(), acc + lst.head())
    }
    def lst = (0..10000).toList 
    mysum(lst)    
@groovy.transform.IndexedProperty
    Generates indexed getters/setters for properties of list/array types.
    //Example 
    class SomeBean {
        @IndexedProperty String[] someArray = new String[2]
        @IndexedProperty List someList = []
    }
    def bean = new SomeBean()
    bean.setSomeArray(0, 'value')
    bean.setSomeList(0, 123)
    assert bean.someArray[0] == 'value'
    assert bean.someList == [123]
@groovy.lang.Lazy
    The @Lazy AST transformation implements lazy initialization of fields. 
    //Example 
    class SomeBean {
        @Lazy LinkedList myField  //= { ['a','b','c']}() , if initialization is required 
    }
    // will produce the following code:
    List $myField
    List getMyField() {
        if ($myField!=null) { return $myField }
        else {
            $myField = new LinkedList() //$myField = { ['a','b','c']}(), where initialization is given 
            return $myField
        }
    }
@groovy.util.logging.Log
    @Log annotation which relies on the JDK logging framework
    //Exmaple 
    @groovy.util.logging.Log //generates private static final Logger log = Logger.getLogger(Greeter.name)
    class Greeter {
        void greet() {
            log.info 'Called greeter'
            println 'Hello, world!'
        }
    }
@groovy.util.logging.Commons
    For apache commons 
    Generates 
         private static final Log log = LogFactory.getLog(Greeter)
@groovy.util.logging.Log4j
    For  Apache Log4j 1.x 
    Generates 
        private static final Logger log = Logger.getLogger(Greeter)
@groovy.util.logging.Log4j2
    For For  Apache Log4j 1.x 
    Generates 
        private static final Logger log = LogManager.getLogger(Greeter)
@groovy.util.logging.Slf4j
    Groovy supports the Simple Logging Facade for Java (SLF4J) framework using to the @Slf4j annotation
    Generates 
        private static final Logger log = LoggerFactory.getLogger(Greeter)      
@groovy.transform.AutoClone       
        Implements java.lang.Cloneable interface 
@groovy.transform.AutoExternalize      
    Implements  java.io.Externalizable interface 
@groovy.transform.WithReadLock 
@groovy.transform.WithWriteLock   
@groovy.transform.Synchronized
@groovy.transform.ThreadInterrupt
@groovy.transform.TimedInterrupt
@groovy.transform.ConditionalInterrupt
    For thread handling, check Thread content 
@groovy.transform.Field  
    only for script, creates a field of Script class
    Note method can not access def var , no such problem with closure
    //Example 
    def x = 2		//use @Field def x=2,  without which becomes local variable in run
    String line() {
        "=" * x
    }
    line()             //groovy.lang.MissingPropertyException: No such property: x for class
@groovy.transform.PackageScope
    Creates a package private field instead of a property
@groovy.transform.TypeChecked
    @TypeChecked activates compile-time type checking on your Groovy code. 
@groovy.transform.CompileStatic
    @CompileStatic activates static compilation on your Groovy code.
@groovy.transform.CompileDynamic
    @CompileDynamic disables static compilation on parts of your Groovy code. 
@groovy.lang.DelegatesTo
    It is aimed at documenting code and helping the compiler 
    while using CompileStatic, TypeChecked
@groovy.beans.Bindable
@groovy.beans.ListenerList
@groovy.beans.Vetoable
    Swing Patterns 
@groovy.lang.Grab
@groovy.lang.GrabConfig
@groovy.lang.GrabExclude
@groovy.lang.GrabResolver
@groovy.lang.Grapes
    Grab configurations (dependencies managements)
    //http://docs.groovy-lang.org/latest/html/documentation/grape.html
    //Example for JDBC 
    @GrabConfig(systemClassLoader=true)
    @Grab(group='mysql', module='mysql-connector-java', version='5.1.6')
    //excluding transitive dependencies 
    @Grab('net.sourceforge.htmlunit:htmlunit:2.8')
    @GrabExclude('xml-apis:xml-apis')
    //multiple grab 
    @Grapes([
       @Grab(group='commons-primitives', module='commons-primitives', version='1.0'),
       @Grab(group='org.ccil.cowan.tagsoup', module='tagsoup', version='0.9.7')])
    class Example {
    // ...
    }
    
 
 
    
    
///Hands-On - Use @groovy.lang.Singleton to create Singleton class <*>
@groovy.lang.Singleton 
@groovy.transform.ToString
class Person implements Serializable{
  String first = "N"
  String last = "D" 
}

def x = Person.instance
def y =  Person.instance
x.is y 





///*** Groovy - Inheritance 
//Note  default and map ctor are genereated for derived class which takes base properties correctly 
//any user defined ctor would remove those 

@groovy.transform.ToString
class A{
  String p
  }
  
@groovy.transform.ToString(includeSuper=true) //default not to include super 
class B extends A {
   String q 
}

def b = new B ( p: "Ok", q: "NOK")
println b 


//Many AST by default does not include Super properties , use explicitely 
@groovy.transform.TupleConstructor(includeSuperProperties=true)
@groovy.transform.ToString(includeSuper=true)
@EqualsAndHashCode(callSuper=true)

//by default, no user defined constructors are inherited
//you must write Derived class constructors calling 'super(args)' at the first line
//or use @InheritConstructors, generates derived class ctor matching Base class user defined ctor 
//but only for if Derived class does not have any new property

//Example with user defined ctor 
@groovy.transform.ToString(includeNames = true)
class BaseClass {
  def  propB
  def BaseClass(Map options) {    //simulate map arg pattern by taking Map option
    this.propB = options.propB    
  }
  def meth1(x) { "baseClass"  }
}

@groovy.transform.ToString(includeNames = true, includeSuper = true)    // Include super's property 
class AnotherClass extends BaseClass {
  def propD

  def AnotherClass(options) {
    super(options)
	this.propD = options.propD
  }
  def meth1(x) { super.meth1(x) + "Derived"  }
  
}

def fun(BaseClass p) { p.meth1(2) }
//or
def fun(p) { p.meth1(2) }
//or
def String fun(def p) { p.meth1(2) }

def p = new AnotherClass(propB : 1, propD: 2)
println(p)
p.meth1(1)
fun(p)				//passing as BaseClass is OK


//OR, using InheritConstructors, but only for if Derived class does not have any new property

@groovy.transform.InheritConstructors			//will create the constructors corresponding to the superclass constructors 
@groovy.transform.ToString(includeNames = true, includeSuper = true) 
class AnotherClass extends BaseClass {
   def propD   //remove this for InheritConstructors to work 
   }

def p = new AnotherClass(propB : 1, propD: 2)  // But propD is not initialized!!, hence use with care!!
println(p)										// but without 'InheritConstructors' it gives error


//Good Example is Exception 
import groovy.transform.InheritConstructors

@InheritConstructors
class CustomException extends Exception {}

// all those are generated constructors
new CustomException()
new CustomException("A custom message")
new CustomException("A custom message", new RuntimeException())
new CustomException(new RuntimeException())









