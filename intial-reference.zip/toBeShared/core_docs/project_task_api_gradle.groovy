///https://docs.gradle.org/current/dsl/org.gradle.api.Project.html
///*** Project API 
//A project has 5 property 'scopes', which it searches for properties. 
//The scopes are: (in order and first found one wins)
•The Project object itself. 
 This scope includes any property getters and setters declared by the Project implementation class. 
 For example, Project.getRootProject() is accessible as the rootProject property. 
 The properties of this scope are readable or writable depending on the presence of the corresponding getter or setter method.
•The extra properties of the project. 
 Each project maintains a map of extra properties, which can contain any arbitrary name -> value pair. 
 Once defined, the properties of this scope are readable and writable. 
•The extensions added to the project by the plugins. 
 Each extension is available as a read-only property with the same name as the extension.
•The convention properties added to the project by the plugins. 
 A plugin can add properties and methods to a project through the project Convention object. 
 The properties of this scope may be readable or writable, depending on the convention objects.
•The tasks of the project. 
 A task is accessible by using its name as a property name. 
 The properties of this scope are read-only. 
 For example, a task called compile is accessible as the compile property.
•The extra properties and convention properties are inherited from the project parent, 
 recursively up to the root project. The properties of this scope are read-only.

///Extra Properties
//All extra properties must be defined through the "ext" namespace. 
//Once an extra property has been defined, it is available directly the Project, Task, and sub-projects respectively) 

project.ext.prop1 = "foo"
task doStuff {
    ext.prop2 = "bar"
}
subprojects { ext.${prop3} = false }
//Reading extra properties is done through the "ext" or through the owning object. 
ext.isSnapshot = version.endsWith("-SNAPSHOT")
if (isSnapshot) {
    // do snapshot stuff
}

///Dynamic Methods
//A project has 5 method copes', which it searches for methods:
•The Project object itself.
•The build file. 
 The project searches for a matching method declared in the build file.
•The extensions added to the project by the plugins. 
 Each extension is available as a method which takes a closure or Action as a parameter.
•The convention methods added to the project by the plugins. 
 A plugin can add properties and method to a project through the project Convention object.
•The tasks of the project. 
 A method is added for each task, using the name of the task as the method name 
 and taking a single closure or Action parameter. 
 The method calls the Task.configure(groovy.lang.Closure) method for the associated task with the provided closure. For example, if the project has a task called compile, then a method is added with the following signature: void compile(Closure configureClosure).
•The methods of the parent project, recursively up to the root project.
•A property of the project whose value is a closure. 
 The closure is treated as a method and called with the provided parameters. 
 The property is located as described above.

///Properties
allprojects 
	The set containing this project and its subprojects.
ant 
	The AntBuilder for this project. You can use this in your build file to execute ant tasks. See example below.
artifacts 
	Returns a handler for assigning artifacts produced by the project to configurations. 
buildDir 
	The build directory of this project. The build directory is the directory which all artifacts are generated into. The default value for the build directory is projectDir/build
buildFile 
	The build script for this project. 
buildscript 
	The build script handler for this project. You can use this handler to query details about the build script for this project, and manage the classpath used to compile and execute the project build script.
childProjects 
	The direct children of this project.
configurations 
	The configurations of this project. 
convention 
	The Convention for this project.
defaultTasks 
	The names of the default tasks of this project. These are used when no tasks names are provided when starting the build.
dependencies 
	The dependency handler of this project. The returned dependency handler instance can be used for adding new dependencies. For accessing already declared dependencies, the configurations can be used. 
description 
	The description of this project, if any.
extensions 
	Allows adding DSL extensions to the project. Useful for plugin authors.
gradle 
	The Gradle invocation which this project belongs to.
group 
	The group of this project. Gradle always uses the toString() value of the group. The group defaults to the path with dots as separators.
logger 
	The logger for this project. You can use this in your build file to write log messages.
logging 
	The LoggingManager which can be used to receive logging and to control the standard output/error capture for this project build script. By default, System.out is redirected to the Gradle logging system at the QUIET log level, and System.err is redirected at the ERROR log level.
name 
	The name of this project. The project name is not necessarily unique within a project hierarchy. You should use the Project.getPath() method for a unique identifier for the project.
normalization Incubating
	Provides access to configuring input normalization.
parent 
	The parent project of this project, if any.
path 
	The path of this project. The path is the fully qualified name of the project.
pluginManager Incubating
	The plugin manager for this plugin aware object.
plugins 
	The container of plugins that have been applied to this object. 
project 
	Returns this project. This method is useful in build files to explicitly access project properties and methods. For example, using project.name can express your intent better than using name. This method also allows you to access project properties from a scope where the property may be hidden, such as, for example, from a method or closure. 
projectDir 
	The directory containing the project build file.
properties 
	The properties of this project. See here for details of the properties which are available for a project.
repositories 
	Returns a handler to create repositories which are used for retrieving dependencies and uploading artifacts produced by the project.
resources 
	Provides access to resource-specific utility methods, for example factory methods that create various resources.
rootDir 
	The root directory of this project. The root directory is the project directory of the root project.
rootProject 
	The root project for the hierarchy that this project belongs to. In the case of a single-project build, this method returns this project.
state 
	The evaluation state of this project. You can use this to access information about the evaluation of this project, such as whether it has failed.
status 
	The status of this project. Gradle always uses the toString() value of the status. The status defaults to release.
subprojects 
	The set containing the subprojects of this project.
tasks 
	The tasks of this project.
version 
	The version of this project. Gradle always uses the toString() value of the version. The version defaults to unspecified.
///Properties added by the announce plugin
announce 
	The AnnouncePluginExtension added by the announce plugin.
///Properties added by the application plugin
applicationDefaultJvmArgs 
	Array of string arguments to pass to the JVM when running the application
applicationDistribution 
	The specification of the contents of the distribution.
applicationName 
	The name of the application.
mainClassName 
	The fully qualified name of the application main class.
///Properties added by the checkstyle plugin
checkstyle 
	The CheckstyleExtension added by the checkstyle plugin.
///Properties added by the codenarc plugin
codenarc 
    The CodeNarcExtension added by the codenarc plugin.
///Properties added by the distribution plugin
distributions 
    The DistributionContainer added by the distribution plugin.
///Properties added by the ear plugin
appDirName 
	The name of the application directory, relative to the project directory. Default is "src/main/application".
deploymentDescriptor 
	A custom deployment descriptor configuration. Default is an "application.xml" with sensible defaults.
libDirName 
	The name of the library directory in the EAR file. Default is "lib".
///Properties added by the eclipse plugin
eclipse 
    The EclipseModel added by the eclipse plugin.
///Properties added by the findbugs plugin
findbugs 
    The FindBugsExtension added by the findbugs plugin.
///Properties added by the idea plugin
idea 
    The IdeaModel added by the idea plugin.
///Properties added by the jacoco plugin
jacoco 
    The JacocoPluginExtension added by the jacoco plugin.
///Properties added by the java plugin
archivesBaseName 
	The base name to use for archive files.
distsDir 
	The directory to generate TAR and ZIP archives into.
distsDirName 
	The name for the distributions directory. This in interpreted relative to the project build directory.
docsDir 
	Returns a file pointing to the root directory supposed to be used for all docs.
docsDirName 
	The name of the docs directory. Can be a name or a path relative to the build dir.
libsDir 
	The directory to generate JAR and WAR archives into.
libsDirName 
	The name for the libs directory. This in interpreted relative to the project build directory.
reporting 
	The ReportingExtension added by the java plugin.
sourceCompatibility 
	The source compatibility used for compiling Java sources.
sourceSets 
	The source sets container.
targetCompatibility 
	The target compatibility used for compiling Java sources.
testReportDir 
	Returns a file pointing to the root directory to be used for reports.
testReportDirName 
	The name of the test reports directory. Can be a name or a path relative to ReportingExtension.getBaseDir().
testResultsDir 
	Returns a file pointing to the root directory of the test results.
testResultsDirName 
	The name of the test results directory. Can be a name or a path relative to the build dir.
///Properties added by the jdepend plugin
jdepend 
    The JDependExtension added by the jdepend plugin.
///Properties added by the maven plugin
conf2ScopeMappings 
    The set of rules for how to map Gradle dependencies to Maven scopes.
mavenPomDir 
    The directory to generate Maven POMs into.
///Properties added by the pmd plugin
pmd 
    The PmdExtension added by the pmd plugin.
///Properties added by the project-report plugin
projectReportDir 
    The directory to generate the project reports into.
projectReportDirName 
    The name of the directory to generate the project reports into, relative to the project reports dir.
/// Properties added by the publishing plugin
publishing 
    The PublishingExtension added by the publishing plugin.
///Properties added by the signing plugin
signing 
    The SigningExtension added by the signing plugin.
///Properties added by the visual-studio plugin
visualStudio 
    The VisualStudioRootExtension added by the visual-studio plugin.
///Properties added by the war plugin
webAppDir 
    The web application directory.
webAppDirName 
    The name of the web application directory, relative to the project directory.
 
 
///*Methods
absoluteProjectPath(path) 
	Converts a name to an absolute project path, resolving names relative to this project.
afterEvaluate(closure) 
	Adds a closure to be called immediately after this project has been evaluated. The project is passed to the closure as a parameter. Such a listener gets notified when the build file belonging to this project has been executed. A parent project may for example add such a listener to its child project. Such a listener can further configure those child projects based on the state of the child projects after their build files have been run.
afterEvaluate(action) 
	Adds an action to execute immediately after this project is evaluated.
allprojects(action) 
	Configures this project and each of its sub-projects.
ant(configureAction) 
	Executes the given action against the AntBuilder for this project. You can use this in your build file to execute ant tasks. See example in javadoc for Project.getAnt()
apply(closure) 
	Applies zero or more plugins or scripts. 
apply(options) 
	Applies a plugin or script, using the given options provided as a map. Does nothing if the plugin has already been applied. 
apply(action) 
	Applies zero or more plugins or scripts. 
artifacts(configureAction) 
	Configures the published artifacts for this project. 
beforeEvaluate(closure) 
	Adds a closure to be called immediately before this project is evaluated. The project is passed to the closure as a parameter.
beforeEvaluate(action) 
	Adds an action to execute immediately before this project is evaluated.
configure(objects, configureClosure) 
	Configures a collection of objects via a closure. This is equivalent to calling Project.configure(java.lang.Object, groovy.lang.Closure) for each of the given objects.
configure(objects, configureAction) 
	Configures a collection of objects via an action.
configure(object, configureClosure) 
	Configures an object via a closure, with the closure delegate set to the supplied object. This way you donot have to specify the context of a configuration statement multiple times. 
container(type) 
	Creates a container for managing named objects of the specified type. The specified type must have a public constructor which takes the name as a String parameter.
container(type, factoryClosure) 
	Creates a container for managing named objects of the specified type. The given closure is used to create object instances. The name of the instance to be created is passed as a parameter to the closure.
container(type, factory) 
	Creates a container for managing named objects of the specified type. The given factory is used to create object instances.
copy(closure) 
	Copies the specified files. The given closure is used to configure a CopySpec, which is then used to copy the files. Example: 
copy(action) 
	Copies the specified files. The given action is used to configure a CopySpec, which is then used to copy the files.
copySpec() 
	Creates a CopySpec which can later be used to copy files or create an archive.
copySpec(closure) 
	Creates a CopySpec which can later be used to copy files or create an archive. The given closure is used to configure the CopySpec before it is returned by this method. 
copySpec(action) 
	Creates a CopySpec which can later be used to copy files or create an archive. The given action is used to configure the CopySpec before it is returned by this method.
delete(paths) 
	Deletes files and directories. 
delete(action) 
	Deletes the specified files. The given action is used to configure a DeleteSpec, which is then used to delete the files. 
evaluationDependsOn(path) 
	Declares that this project has an evaluation dependency on the project with the given path.
exec(closure) 
	Executes an external command. The closure configures a ExecSpec.
exec(action) 
	Executes an external command. 
file(path) 
	Resolves a file path relative to the project directory of this project. This method converts the supplied path based on its type:
file(path, validation) 
	Resolves a file path relative to the project directory of this project and validates it using the given scheme. See PathValidation for the list of possible validations.
fileTree(baseDir) 
	Creates a new ConfigurableFileTree using the given base directory. The given baseDir path is evaluated as per Project.file(java.lang.Object).
fileTree(baseDir, configureClosure) 
	Creates a new ConfigurableFileTree using the given base directory. The given baseDir path is evaluated as per Project.file(java.lang.Object). The closure will be used to configure the new file tree. The file tree is passed to the closure as its delegate. Example:
fileTree(baseDir, configureAction) 
	Creates a new ConfigurableFileTree using the given base directory. The given baseDir path is evaluated as per Project.file(java.lang.Object). The action will be used to configure the new file tree. Example:
fileTree(args) 
	Creates a new ConfigurableFileTree using the provided map of arguments. The map will be applied as properties on the new file tree. Example:
files(paths, configureClosure) 
	Creates a new ConfigurableFileCollection using the given paths. The paths are evaluated as per Project.files(java.lang.Object[]). The file collection is configured using the given closure. The file collection is passed to the closure as its delegate. Example:
files(paths, configureAction) 
	Creates a new ConfigurableFileCollection using the given paths. The paths are evaluated as per Project.files(java.lang.Object[]). The file collection is configured using the given action. Example:
files(paths) 
	Returns a ConfigurableFileCollection containing the given files. You can pass any of the following types to this method:
findProject(path) 
	Locates a project by path. If the path is relative, it is interpreted relative to this project.
findProperty(propertyName) 
	Returns the value of the given property or null if not found. This method locates a property as follows:
getAllTasks(recursive) 
	Returns a map of the tasks contained in this project, and optionally its subprojects.
getTasksByName(name, recursive) 
	Returns the set of tasks with the given name contained in this project, and optionally its subprojects.
hasProperty(propertyName) 
	Determines if this project has the given property. See here for details of the properties which are available for a project.
javaexec(closure) 
	Executes a Java main class. The closure configures a JavaExecSpec.
javaexec(action) 
	Executes an external Java process. 
mkdir(path) 
	Creates a directory and returns a file pointing to it.
normalization(configuration) Incubating
	Configures input normalization.
project(path) 
	Locates a project by path. If the path is relative, it is interpreted relative to this project.
project(path, configureClosure) 
	Locates a project by path and configures it using the given closure. If the path is relative, it is interpreted relative to this project. The target project is passed to the closure as the closure delegate.
project(path, configureAction) 
	Locates a project by path and configures it using the given action. If the path is relative, it is interpreted relative to this project.
property(clazz) DeprecatedIncubating
	Creates a PropertyState implementation based on the provided class.
property(propertyName) 
	Returns the value of the given property. This method locates a property as follows:
relativePath(path) 
	Returns the relative path from the project directory to the given path. The given path object is (logically) resolved as described for Project.file(java.lang.Object), from which a relative path is calculated.
relativeProjectPath(path) 
	Converts a name to a project path relative to this project.
setProperty(name, value) 
	Sets a property of this project. This method searches for a property with the given name in the following locations, and sets the property on the first location where it finds the property.
subprojects(action) 
	Configures the sub-projects of this project
sync(action) 
	Synchronizes the contents of a destination directory with some source directories and files. The given action is used to configure a CopySpec, which is then used to synchronize the files. 
tarTree(tarPath) 
	Creates a new FileTree which contains the contents of the given TAR file. The given tarPath path can be: 
task(name) 
	Creates a Task with the given name and adds it to this project. Calling this method is equivalent to calling Project.task(java.util.Map, java.lang.String) with an empty options map.
task(name, configureClosure) 
	Creates a Task with the given name and adds it to this project. Before the task is returned, the given closure is executed to configure the task.
task(args, name) 
	Creates a Task with the given name and adds it to this project. A map of creation options can be passed to this method to control how the task is created. The following options are available:
task(args, name, configureClosure) 
	Creates a Task with the given name and adds it to this project. Before the task is returned, the given closure is executed to configure the task. A map of creation options can be passed to this method to control how the task is created. See Project.task(java.util.Map, java.lang.String) for the available options.
uri(path) 
	Resolves a file path to a URI, relative to the project directory of this project. Evaluates the provided path object as described for Project.file(java.lang.Object), with the exception that any URI scheme is supported, not just 'file:' URIs.
zipTree(zipPath) 
	Creates a new FileTree which contains the contents of the given ZIP file. The given zipPath path is evaluated as per Project.file(java.lang.Object). You can combine this method with the Project.copy(groovy.lang.Closure) method to unzip a ZIP file.
///Methods added by the ear plugin
appDirName(appDirName) 
	Allows changing the application directory. Default is "src/main/application".
deploymentDescriptor(configureAction) 
	Configures the deployment descriptor for this EAR archive. 
libDirName(libDirName) 
	Allows changing the library directory in the EAR file. Default is "lib".
///Methods added by the java plugin
manifest() 
	Creates a new instance of a Manifest.
manifest(closure) 
	Creates and configures a new instance of a Manifest. The given closure configures the new manifest instance before it is returned.
manifest(action) 
	Creates and configures a new instance of a Manifest.
///Methods added by the maven plugin
pom() 
	Creates a new MavenPom.
pom(configureClosure) 
	Creates and configures a new MavenPom. The given closure is executed to configure the new POM instance.
pom(configureAction) 
	Creates and configures a new MavenPom. The given action is executed to configure the new POM instance.
///Methods added by the osgi plugin
osgiManifest() 
    Creates a new instance of OsgiManifest. The returned object is preconfigured with: 
osgiManifest(closure) 
    Creates and configures a new instance of an OsgiManifest . The closure configures the new manifest instance before it is returned.
osgiManifest(action) 
    Creates and configures a new instance of an OsgiManifest. The action configures the new manifest instance before it is returned.

///*Script blocks
allprojects 
	Configures this project and each of its sub-projects.
ant 
	Executes the given closure against the AntBuilder for this project. You can use this in your build file to execute ant tasks. The AntBuild is passed to the closure as the closure delegate. See example in javadoc for Project.getAnt()
artifacts 
	Configures the published artifacts for this project. 
buildscript 
	Configures the build script classpath for this project. 
configurations 
	Configures the dependency configurations for this project. 
dependencies 
	Configures the dependencies for this project. 
repositories 
	Configures the repositories for this project. 
subprojects 
	Configures the sub-projects of this project.
///Script blocks added by the announce plugin
announce 
    Configures the AnnouncePluginExtension added by the announce plugin.
///Script blocks added by the checkstyle plugin
checkstyle 
    Configures the CheckstyleExtension added by the checkstyle plugin.
///Script blocks added by the codenarc plugin
codenarc 
    Configures the CodeNarcExtension added by the codenarc plugin.
///Script blocks added by the distribution plugin
distributions 
    Configures the DistributionContainer added by the distribution plugin.
///Script blocks added by the ear plugin
deploymentDescriptor 
    Configures the deployment descriptor for this EAR archive. 
///Script blocks added by the eclipse plugin
eclipse 
    Configures the EclipseModel added by the eclipse plugin.
///Script blocks added by the findbugs plugin
findbugs 
    Configures the FindBugsExtension added by the findbugs plugin.
///Script blocks added by the idea plugin
idea 
    Configures the IdeaModel added by the idea plugin.
///Script blocks added by the jacoco plugin
jacoco 
    Configures the JacocoPluginExtension added by the jacoco plugin.
///Script blocks added by the java plugin
reporting 
    Configures the ReportingExtension added by the java plugin.
sourceSets 
    Configures the source sets of this project. 
///Script blocks added by the jdepend plugin
jdepend 
    Configures the JDependExtension added by the jdepend plugin.
///Script blocks added by the pmd plugin
pmd 
    Configures the PmdExtension added by the pmd plugin.
///Script blocks added by the publishing plugin
publishing 
    onfigures the PublishingExtension added by the publishing plugin.
///Script blocks added by the signing plugin
signing 
    Configures the SigningExtension added by the signing plugin.

    
    
///*** Task Api 
/A Task has 4 copes for properties. 
///You can access these properties by name from the build file 
•The Task object itself. 
 This includes any property getters and setters declared by the Task implementation class. 
 The properties of this scope are readable or writable based on the presence of the corresponding getter 
 and setter methods.
•The extensions added to the task by plugins. 
 Each extension is available as a read-only property with the same name as the extension.
•The convention properties added to the task by plugins. 
 A plugin can add properties and methods to a task through the task Convention object. 
 The properties of this scope may be readable or writable, depending on the convention objects.
•The extra properties of the task. 
 Each task object maintains a map of additional properties. 
 These are arbitrary name -> value pairs which you can use to dynamically add properties to a task object. 
 Once defined, the properties of this scope are readable and writable.

///Properties
actions 
	The sequence of Action objects which will be executed by this task, in the order of execution.
ant 
	The AntBuilder for this task. You can use this in your build file to execute ant tasks.
convention 
	The Convention object for this task. A Plugin can use the convention object to contribute properties and methods to this task.
dependsOn 
	The dependencies of this task.
description 
	The description of this task.
destroyables Incubating
	The destroyables of this task.
didWork 
	Checks if the task actually did any work. Even if a Task executes, it may determine that it has nothing to do. For example, a compilation task may determine that source files have not changed since the last time a the task was run.
enabled 
	Returns if this task is enabled or not.
extensions 
	The container of extensions.
finalizedBy Incubating
	Returns tasks that finalize this task.
group 
	The task group which this task belongs to. The task group is used in reports and user interfaces to group related tasks together when presenting a list of tasks to the user.
inputs 
	The inputs of this task.
logger 
	The logger for this task. You can use this in your build file to write log messages.
logging 
	The LoggingManager which can be used to receive logging and to control the standard output/error capture for this task. By default, System.out is redirected to the Gradle logging system at the QUIET log level, and System.err is redirected at the ERROR log level.
mustRunAfter Incubating
	Returns tasks that this task must run after.
name 
	The name of this task. The name uniquely identifies the task within its Project.
outputs 
	The outputs of this task.
path 
	The path of the task, which is a fully qualified name for the task. The path of a task is the path of its Project plus the name of the task, separated by :.
project 
	The Project which this task belongs to.
state 
	The execution state of this task. This provides information about the execution of this task, such as whether it has executed, been skipped, has failed, etc.
taskDependencies 
	Returns a TaskDependency which contains all the tasks that this task depends on.
temporaryDir 
	Returns a directory which this task can use to write temporary files to. Each task instance is provided with a separate temporary directory. There are no guarantees that the contents of this directory will be kept beyond the execution of the task.

///*Methods
deleteAllActions() Deprecated
	Removes all the actions of this task.
dependsOn(paths) 
	Adds the given dependencies to this task. See here for a description of the types of objects which can be used as task dependencies.
doFirst(action) 
	Adds the given closure to the beginning of this task action list. The closure is passed this task as a parameter when executed.
doFirst(actionName, action) Incubating
	Adds the given Action to the beginning of this task action list.
doFirst(action) 
	Adds the given Action to the beginning of this task action list.
doLast(action) 
	Adds the given closure to the end of this task action list. The closure is passed this task as a parameter when executed.
doLast(actionName, action) Incubating
	Adds the given Action to the end of this task action list.
doLast(action) 
	Adds the given Action to the end of this task action list.
finalizedBy(paths) Incubating
	Adds the given finalizer tasks for this task.
hasProperty(propertyName) 
	Determines if this task has the given property. See here for details of the properties which are available for a task.
leftShift(action) Deprecated
	Adds the given closure to the end of this task action list. The closure is passed this task as a parameter when executed. You can call this method from your build script using the << left shift operator.
mustRunAfter(paths) Incubating
	Specifies that this task must run after all of the supplied tasks.
onlyIf(onlyIfClosure) 
	Execute the task only if the given closure returns true. The closure will be evaluated at task execution time, not during configuration. The closure will be passed a single parameter, this task. If the closure returns false, the task will be skipped.
onlyIf(onlyIfSpec) 
	Execute the task only if the given spec is satisfied. The spec will be evaluated at task execution time, not during configuration. If the Spec is not satisfied, the task will be skipped.
property(propertyName) 
	Returns the value of the given property of this task. This method locates a property as follows:
setProperty(name, value) 
	Sets a property of this task. This method searches for a property with the given name in the following locations, and sets the property on the first location where it finds the property.

///* Task types
AntlrTask
BuildEnvironmentReportTask
Checkstyle
CodeNarc
CompareGradleBuilds
Copy
CreateStartScripts
Delete
Ear
Exec
FindBugs
GenerateIvyDescriptor
GenerateMavenPom
GenerateBuildDashboard
GradleBuild
GroovyCompile
Groovydoc
HtmlDependencyReportTask
JacocoReport
JacocoMerge
JacocoCoverageVerification
Jar
JavaCompile
Javadoc
JavaExec
JDepend
Pmd
PublishToIvyRepository
PublishToMavenRepository
ScalaCompile
ScalaDoc
InitBuild
Sign
Sync
Tar
AbstractTestTask
Test
TestReport
Upload
War
Wrapper
WriteProperties
Zip