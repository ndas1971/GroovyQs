package jsrx;

import javax.jws.*;
import javax.xml.ws.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Book {
	public String name;
	public String author;
}
