package examples;

public interface GreetingService {
  String greet(final String name);
}