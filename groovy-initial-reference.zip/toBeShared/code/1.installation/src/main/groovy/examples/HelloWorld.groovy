package examples

class HelloWorld {

    public static void main(String[] args) {
       args.each{ println it }
       println("helloWorld")
    }

}