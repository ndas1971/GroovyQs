
println "Args are ${args[0]} ${args[1]}" 

/*
define two variables , name and age 
if name is "XYZ" and age is below 40, 
print "suitable" 
else if age is greater than 50, print "old", 
else print "OK"
For all other names, print "not known" 
*/
