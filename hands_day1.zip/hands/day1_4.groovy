//List - mu, io, du, indexing 
def lst = [1, "OK", 1.2, [1,2,3]]
le = []
println le.empty //true 

//mu
lst[-1][-1]=30
println lst 

//append 
le << 2 << 3 
println(le)
//2
le += [3,4,5]
//3
le.add(40)
println(le)
//cont 
l2 = le + [1,2,3]
//le remains same 
//l2 is new list 

lst = [1, "OK", 1.2, [1,2,3]]
lst[-1]  //last element 
lst[-1] = 30  //mu 
lst[0..<2]  // [1, "OK"]

lst[0..<0] = ["prepend"]
lst[lst.size()..lst.size()] = ["append"]
lst[2..<2] = ["insert"]  //[prepend, 1, insert, OK, 1.2, 30, append]
lst[0..3] = ["updated"] //can grow or shrink - splice 
println(lst)

//membership checking 
"append" in lst //true 
lst == [1,2]  //value comparison 
for (e in lst){
    println(e)
}
//fp iteration 
lst.each{
    println it 
}.each{ e ->
    println e+e
}
///beyond size 
println(lst.size())
lst[100] == null //true //.size() is original size 
lst[20] = "OK"  //.size() is 20 
//intermediate values are null 
lst = [1,2,3] //list 
arry = lst as int[]  //int[] 
s = [1,1,1,1,2] as Set //dumplicates are removed 
st = lst as Stack //check java reference 
q = lst as Queue //check java reference

//map pattern 
input = [1,5,6,10]
output = [1,25,36,100]

output = []
input.each{
    output << it*it
}

//.toList(), .toSet()
s = "Hello World"
s.toList()
//HandsOn
input = '[1,2,3,4]'
output = [1,2,3,4] //list of int

output = []
input[1..<input.size()-1].split(",").each{
        output << it.toInteger()
}

println(output)
//transpose = zip 
[['a', 'b', 'c', 'd'], [10,20,30]].transpose()
//[[a, 10], [b, 20], [c, 30]]

//find checksum
input = "ABCDEF1234567890"
def checksum(input){
    slice = { start, end, step ->
                            output = []
                            start.step(end,step){  //end exclusive
                                output << it
                            }
                            output
                        }    
    s1 = slice(0, input.size() ,2)
    s2 = slice(1,input.size(),2)
    output = []
    [s1,s2].transpose().each { //[[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
        hex = input[it[0]] + input[it[1]]
        i = Integer.parseInt(hex,16)
        output << i
    }
    output.sum() % 255
}
ch = checksum(input)
assert checksum( input + Integer.toString(255-ch,16)) == 0 
















