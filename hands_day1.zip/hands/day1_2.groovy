//void  upto(Number to, Closure closure)  
0.1.upto(10){
   // println it
}
0.step(10,2){
   // println it
}
10.times{
   // println it 
}
10.5.downto(0){
   // println it
}

///Print Pythogorous triplets below 100 
//int limit = 100 
def pythogorous(limit){
    int count = 0
        3.upto(limit){ x ->
            x.upto(limit){ y ->
                y.upto(limit){z ->
                    if( z*z == x*x + y*y){
                        //println("($x,$y,$z)")
                        count += 1 //count++, count= count+1
                        //return 
                    }
                }
            }
        }
    count
}
count = pythogorous(200)
println count
//functions 
def add(x, y=20){
    z = x+y 
    z  //return z
}
add(2,3)
add(2) //ERROR is there is no default of y 
add(y=2,x=3)
add(2,y=100)

//nested function not possible 
//closure is possible 
def f(x){
    def g = { y -> x+y}  //scope of y is in 'g' ,
    //def g1 = {x -> x*x}  //Error: The current scope already contains a variable of the name x
    g(x+20)
    //g1(x+20)
}

f(2)
//var args 
def fx(Integer... x){
    println(x)
}
fx(1) 
fx(1,2)  //[1, 2]
fx()




























































