set1 = [1,2,3,1,2] as Set 
set2 = [3,4,5] as Set 
println "$set1 $set2"
set2 == [5,3,4] as Set
set2.each {
    println it
}
set2.size()
3 in set2  //checking existence 
//set2[0]  //DOn't believe this 
//set specific 
su = set1 + set2  //union 
si = set1.intersect(set2) //intersect
sd = set1 - set2 //difference 
println "$su $si $sd"
//application 
def freq(s){
    for (ch in s.toSet()){
        count = 0 
        for (ch1 in s){
            if (ch == ch1)
                count++
        }
        println("$ch -> $count")
    }
}
s = "Hello World"
freq(s)
//MAP 
em = [:]
map = [ 'ok': 1, 'nok':2, 3: [4, 5] ] //only for string key and if not keyword, '' is optional
println map.isEmpty() // correc tsyntax 

map.keySet()
map.values()
map.entrySet()

//groovy
map << ['new': 2] //creation of new key 
map1 = map - ['new':2]

map['new1'] = 20 //first time assignment 
map['ok'] = 20 //update 
map.size() //how many elements 
println map['ok'] //access given a key 
println(map.ok) //valid if key is string 
"ok" in map //true 

map.each { k,v ->
    println "$k $v"
}
map.each { kv ->
    println "${kv.key} ${kv.value}"
}
//
for (kv in map){
    println "${kv.key} ${kv.value}"
}
//
map['hjk']  // null 
map.get('hjk') 
map.get('hjk', "default") // get and updated "default"

map.asImmutable()  //immutable 
map.asSynchronized() //multithreaded
println(map)

//switch 

def match(x) {    
    switch(x) {
        case "ABC" :            // literal matching
                println("ABC")
                break
        case 2..9 :
                println("range")
                break
        case 'a'..'f':
                println("a to f")
                break
        case [10,20,30] :
                println("in list")
                break
        case  ['ok':2, 'nok':3] :
                println("in map keys")
                break
        case BigDecimal :
                println("BigDecimal")
                break               
        case ~/dr.*/ :
                println("pattern matched")
                break               
        case { it == 1G} :  //if closure returns true, this is matched, G = BigInteger
                println("closure returned true")
                break   
        default:
            println("default")
    }
}
match("ABC") //ABC
match(2)  // range 
match('e') //a to f 
match(20) // in list 
match('ok') //"in map keys"
match(1.2) //bigDecimal 
match("drown") //"pattern matched"
match(1G)  //"closure returned true"
match(1.2f) // "default"


//Write a function to return frequency of words(ignoring cases)
s = "Groovy and Groovy console are used for Groovy"


def frequency(s){
    ed = [:]
    lst = s.split(/\s+/)   //.split(" ")
    lst.each{ 
        ed << [ (it): lst.count(it)]
    }
    ed
}
frequency(s)

















