@groovy.transform.Canonical //toString, equals
@groovy.transform.ToString(includeNames=true)
class Person{
    String firstName
    String lastName
    def fullName(){
        this.firstName + " " + this.lastName
    }
    def decorate(prefix='Mr.'){
        prefix + " " + this.fullName()
    }    
}
def p = new Person(firstName: 'ABC', lastName: 'xyz') //groovy ctor
def p2 = new Person('ABC', 'xyz') //tuple ctor 
p.firstName = 'YX'
println "$p, ${p == p2}, ${p.decorate('Miss')}"


