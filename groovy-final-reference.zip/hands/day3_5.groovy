//Dynamic Meta programming 
ExpandoMetaClass.enableGlobally()
List.metaClass.sizeDoubled = { -> delegate.size()*2}
List.metaClass.freq = { -> 
    delegate.collectEntries{ e-> [e, delegate.count{it == e}]}
}
def list = [1,2,1,1,1,2,3,4]
println list.sizeDoubled()
println list.freq()
//Threading 
def ths = []
def th = null
10.times{
     th = Thread.start{
        Thread.sleep(1000)  //ms
        println "${Thread.currentThread().name} working"
    }
    ths << th
}
ths.each{it.join()}
println("Main thread")
 




