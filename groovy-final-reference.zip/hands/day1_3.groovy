//list - mutable, duplicates allowed, heterogeneous . can grow dynamically
//array - mutable, homogeneous and fixed size, duplicates allowed 

//list
def list = [1, 2.3, "OK", [1,2,3]]
list.class  //java.util.ArrayList
def el = []
el.empty //true 
//operations
list.size()
"OK" in list //true 
list == [1,2,4]
//access
list[0]  //1
list[-1]  // [1,2,3]
list[-1] = 30
//slice 
list[0..2]
list[0..<2]
//append/concat 
def list2 = list + [1,2,3]
list << 30 << 40
list  //[1, 2.3, OK, 30, 30, 40]
//iteration 
list.each {
    println it
}
for (element in list){
    println element
}
//remove 
list.remove('OK')
//other operation
[1,2,3,4].sum()
[1,2,3,4].max() 
[1,2,3,4].min()
//nested list 
def list3 = [[1,2,3], [4,5]]
list3[-1][-1] = 30
list3 //[[1, 2, 3], [4, 30]]

//Prob-1: Given input= [3,4,6,5] , output = [9,16,36,25]
/*
create empty list 
Pick each element,e from input 
    square e and append to empty list 
*/
def input = [3,4,6,5]
def ele = []
input.each { ele << it * it }
//or
ele = []
for (e in input){
    ele << e * e
}
println ele 


//Prob-2: Given input= [3,4,6,5] , output = [9,25]
/*
create empty list 
Pick each element,e from input 
    if e is odd
        square e and append to empty list 
*/
ele = []
for (e in input){
    if (e % 2 == 1){
        ele << e * e
    }
}
println ele 

//Prob-3: Given input= "The world is round and round"
//print no of words and average length of word
def average(lst){
    return lst.sum()/lst.size()
}
def stats(str){
    def words = str.split(" ")
    def no = words.size()
    def el = []
    words.each { el << it.size()} //same as Prob1 
    def alw = average(el)
    return [no, alw]
}
println stats("The world is round and round")

//Prob-4:  Given input = "[1,2,3,4]", print sum ie 10
input = "[1,2,3,4]"
input.toList() //['[', '1', ',', '2', ',', '3', ',', '4', ']']
def ell = []
input.toList().each { ch ->
    if (!(ch in "[,]".toList())){ // ! means not
        ell << ch.toInteger()
    }
}
ell.sum()
//Set - no Duplicates 
[1,1,1,1,2,3].toSet()
def set1 = [1,1,1,2] as Set   //no direct syntax, convert list to set 
set1.class  //java.util.LinkedHashSet
//all operations of list are available 
//remove duplicates via Set 
def str = "Hello World"
str.toSet().each {ch1 ->
   def counter = 0
   str.each { ch2 ->
       if(ch1 == ch2){
           counter++         // = counter + 1
       }
    }
    println "$ch1 $counter"
}
