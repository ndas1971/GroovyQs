trait Greet{
    abstract String name()   
    def greet(prefix="hello"){ 
        "$prefix ${name()}" 
     }      
}
trait Food{
     abstract String foodchoice() 
}

class Person{
    String firstName
    String lastName
}
//infusing trait to person
//inheritance 
class PersonG extends Person implements Greet, Food{    
    String name(){
        "$firstName $lastName"
    }   
    String foodchoice(choice='veg'){
        "${greet()} having $choice"
    }
    def greet(){ 
        "hi ${name()}" 
     }
}

def p = new PersonG(firstName: 'XYZ', lastName: 'ABC')
p.greet()
p.foodchoice()
//runtime mixin
trait Name{
    String name(){
        "Mr. $firstName $lastName"
    }
}
def p2 = new Person(firstName: 'XYZ', lastName: 'ABC')
def pg2 = p2.withTraits Name, Greet
pg2.greet()
//SAM coercion 
trait Work{
    abstract def where(designation)
    def greet(){ "greeting"}
}
def wk = {deg -> "Mr. X ($deg) working"} as Work
wk.where("VP")
wk.greet()

