//spread 
def lst2 = [1,2,3]
def llist = [lst2,lst2,lst2]  //[[1, 2, 3], [1, 2, 3], [1, 2, 3]]
llist = [*lst2,*lst2,lst2]  //[1, 2, 3, 1, 2, 3, [1, 2, 3]]

//file handling 
//import java.io.*  //Groovy imports java.io.* by default , so no need
//writing 
def file2 = new File(/D:\Desktop\PPT\Groovy\hands\output.txt/)
file2.text = "hello\r\n"  //replace content
file2 << "World\r\n" 
file2 << "Hello " << "Earth\r\n" //append 
//read all lines together , returns string of all lines 
def all_lines = file2.text
//read 
def file = new File(/D:\Desktop\PPT\Groovy\hands\data\iris.csv/)
def rows = file.readLines() //reading , returns list of lines
//["SepalLength,SepalWidth,PetalLength,PetalWidth,Name",
// "5.1,3.5,1.4,0.2,Iris-setosa", ...]

rows = rows.collect{it.split(",")}
//[['SepalLength', 'SepalWidth','PetalLength', 'PetalWidth', 'Name'],
// ['5.1', '3.5', '1.4', '0.2', 'Iris-setosa'],....]
//[['5.1', '3.5', '1.4', '0.2'], 'Iris-setosa']
def header = rows[0]
rows = rows[1..<rows.size()] //remaining
rows = rows.collect{r ->
      [*r[0..3].collect{it.toDouble()}, r[-1]] //* means spread
  }
//how many species
def un = rows.collect{it[-1]}.toSet() // [Iris-virginica, Iris-setosa, Iris-versicolor]

@groovy.transform.Canonical
@groovy.transform.ToString(includeNames=true)
class IrisData{
    Double sl
    Double sw
    Double pl
    Double pw
    String name 
    def toList(){
        [this.sl, this.sw, this.pl, this.pw, this.name]
    }
}
def csvList = rows.collect{new IrisData(*it)} //list of IrisData
//What is max of Sepallength for each species
csvList.groupBy{it.name}.collectEntries{k,v ->
    [k, ['max': v.collect{it.sl}.max()]]}
// [Iris-setosa:[max:5.8], Iris-versicolor:[max:7.0], Iris-virginica:[max:7.9]]
//How do we validate this complex program?
//sqlite-jdbc-3.7.2.jar

import java.sql.*
import org.sqlite.SQLite
import groovy.sql.Sql
def sql = Sql.newInstance("jdbc:sqlite:iris.db", "org.sqlite.JDBC")
sql.execute("drop table if exists IRIS")
sql.execute("""create table IRIS (sl double,
    sw double, pl double, pw double, name string)""")
    
csvList.each { r->
    sql.execute("insert into IRIS values(?,?,?,?,?)", r.toList())
}
def rows2 = sql.rows("select name, max(sl) from IRIS group by name")
println rows2
sql.close()




