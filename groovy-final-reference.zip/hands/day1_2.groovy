def s = "Hello"
s = 'Hello'
s = """Hello
World"""
println s
// s = "Hello\nWorld"
def a = "10"
//conversion - to*()
a.toInteger()
a.toDouble()
//length 
s.size() //11
//checking substring
s.contains("Hello") //true 
//access
s[0]            //H
s[s.size()-1]   //d
s[-1]           //d
s[-s.size()]    //H
//raw 
def rs = /\n/
def ns = "\n"
println "${rs.size()} ${ns.size()}"
//slice
// s = "Hello\nWorld"
s[0..4]  //Hello , start..end , end is inclusive 
s[0..<5] //Hello , end is exclusive 
//comp
s == "OK"  //false 
s != "OK"  //true 
//concat 
def s2 = s + " Earth"  // "Hello\nWorld Earth"
s2  = s << " Earth"
//immutable, original s remains same 
s
//Many Java methods 
//String     trim()
//Returns a copy of the string, with leading and trailing whitespace omitted.
//String[] split(String regex)
"   Hello   ".trim() //Hello
"A:B:C".split(":") //['A', 'B', 'C']

//Many GDK Methods 
//each(Closure closure) //iterating each char of string
s.each {
    println it 
}
//equivalent
for (ch in s){
    println ch 
}
//
def str = "Hello World"
/*
pick each char, ch1 from str 
    initialize a counter 
    Again pick each char, ch2 from str
        if ch1 and ch2 are same 
            increment counter 
    print ch1 and counter
*/
for (ch1 in str){
    def counter = 0
    for (ch2 in str){
       if(ch1 == ch2){
           counter++          // = counter + 1
       }
    }
    println "$ch1 $counter"
}
str.each {ch1 ->
   def counter = 0
   str.each { ch2 ->
       if(ch1 == ch2){
           counter++         // = counter + 1
       }
    }
    println "$ch1 $counter"
}











