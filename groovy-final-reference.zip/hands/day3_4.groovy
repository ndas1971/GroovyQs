import groovy.xml.*

def dir = /output/
def files = new File(dir).listFiles().findAll{it.name.endsWith('xml')}

def process(filename){
    def root = new XmlSlurper().parse(filename)
    def data = root.eventData.event.collect{ n->
                n.'**'.findAll{!(it.name() in  ['event','originalData']) }
               .collect{it.text().replaceAll("\n", " ")}
           }
   data
}
def data = files.collectMany{f -> process(f.path)}.collect{ it.join(",")}

def filename = /output\test-${new Date().toString().replaceAll(':','')}.csv/
data.each{
    def of = new File(filename)
    of << it << "\r\n"
}


