//switch 
def values = [ abc:'abc', 'xyz': 'list', 40: 'Integer', 'other':20]
values.each{
    switch(it.key){
        case 'abc':           //literal match
            println it.value
            break
        case [10,11,'xyz']:   //checks 'in' List
            println it.value
            break
        case Integer:         //checks .class
            println it.value
            break
        default:        //if not matched by earlier
            println it.value                
    }
}