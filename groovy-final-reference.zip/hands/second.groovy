def a = 1
a.class
def b = 1.2
b.class
def s = "OK"
s.class
def b1 = true // false 
b1.class
if (a == 1) {
    c = a + b
    println "a+b=${c}"
    println "a+b=$c"
    println "a+b=${a+b}"
}  
else if (a > 1){
    println "a>1"
}
else {
    println "else"
}
/*
define two variables , name and age 
if name is "XYZ" and age is below 40, 
print "suitable" 
else if age is greater than 50, print "old", 
else print "OK"
For all other names, print "not known" 
*/
def compare(n, a, default_name="XYZ"){
    if (n == default_name) {
        if (a < 40){
            return "suitable" 
        } else if (a > 50){
            return "old"
        } else {
            return "OK"
        }
    } else {
        return  "not known"
    }
}
def name = "XYZ"
def age = 40 
println compare(name, age)
println compare("ABC", 50)
println compare("CV", 10)