trait Greet{
    abstract String name()   
    def greet(prefix="hello"){ 
        "$prefix ${name()}" 
     }      
}
trait Hobby{
     String hobby() { 'i love football' }
}

class Person{
    String firstName
    String lastName
}
//infusing trait to person
//inheritance 
class PersonG extends Person implements Greet, Hobby{    
    String name(){
        "$firstName $lastName"
    }   
    String hobby(){
        'i love chess' + Hobby.super.hobby()
    }
}

def p = new PersonG(firstName: 'XYZ', lastName: 'ABC')
p.greet()
p.hobby()