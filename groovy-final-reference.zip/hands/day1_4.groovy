//map - key,value pair, keys are unique 
def map1 = [ 'ok' : 2, 'nok': 3]
def em = [:]
em.isEmpty()  //is empty - true 
//how many elements 
map1.size() 
//Given key, get value 
map1['ok'] 
//if key is string
map1.nok
//create new key, value 
map1['new'] = 4
map1 // [ok:2, nok:3, new:4]
//update old value given a key 
map1['ok'] = 40
map1 //[ok:40, nok:3, new:4]
//add new k,v
map1 << ['new1' : 30]
map1 //[ok:40, nok:3, new:4, new1:30]
//remove a key,value 
map1 - ['new1' : 30]
//check key exists or not 
'ok' in map1 
//iteration
map1.each{ k, v ->
    println "$k $v"
}
//or 
for (kv in map1){
    println "${kv.key} ${kv.value}"
}

///prob-1:  Frequency of words 
def str = "Hello World Welcome to World"
def output = [:]
def count(lst, word){
   def counter = 0
   lst.each { w ->
       if(word == w){
           counter++         // = counter + 1
       }
    }
    return counter
}
str.split(" ").each {ch1 ->
  output[ch1] = count(str.split(" ")  , ch1)
}
println output 
//or 
output = [:]
str.split(" ").each {ch1 ->
    if (ch1 in output){
        output[ch1]++
    }
    else {
        output[ch1] = 1
    }
}
println output