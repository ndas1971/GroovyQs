def books = '''
<response version-api="2.0">
    <value>
        <books>
            <book available="20" id="1">
                <title>Don Xijote</title>
                <author id="1">Manuel De Cervantes</author>
            </book>
            <book available="14" id="2">
                <title>Catcher in the Rye</title>
               <author id="2">JD Salinger</author>
           </book>
           <book available="13" id="3">
               <title>Alice in Wonderland</title>
               <author id="3">Lewis Carroll</author>
           </book>
           <book available="5" id="4">
               <title>Don Xijote</title>
               <author id="4">Manuel De Cervantes</author>
           </book>
       </books>
   </value>
</response>
'''
import groovy.xml.*
def root = new XmlSlurper().parseText(books)
root.value.books.book[0].author.text()
def book = root.value.books.book[0]
book.@id 
book['@id'].toInteger()
book.name()
root.value.books.book[1].@available.toInteger()
//File parsing
def data = new XmlSlurper().parse(new File(/data\country.xml/))
data.country.rank*.toInteger() //spread operation 
data.country.rank.collect{it.toInteger()}
data.country*.@name //data.country.collect{it.@name}
//country name vs it's neighbor
data.country.collectEntries{[it.@name, it.neighbor*.@name]}
//OR - '**' is called breathFirst Search 
data.country.collectEntries{[it.@name, 
    it.'**'.findAll{n ->
        n.name() == 'neighbor'}.collect{n -> n.@name}]}

//With namespace 
def str = '''
<bib:bibliography xmlns:bib="http://bibliography.org"
  xmlns:lit="http://literature.org">
  <bib:author >William Shakespeare</bib:author>
  <lit:play>
    <lit:year>1589</lit:year>
    <lit:title lang='Eng'>The Two Gentlemen of Verona.</lit:title>
  </lit:play>
  <lit:play>
    <lit:year>1594</lit:year>
    <lit:title lang='ita'>Love's Labour's Lost.</lit:title>
  </lit:play>
  <lit:play>
    <lit:year>1594</lit:year>
    <lit:title lang='Eng'>Romeo and Juliet.</lit:title>
  </lit:play>
  <lit:play>
    <lit:year>1595</lit:year>
    <lit:title lang='esp'>A Midsummer-Nights Dream.</lit:title>
  </lit:play>
</bib:bibliography>
'''
root = new XmlSlurper().parseText(str)
root.play.title*.@lang //all the langs, without namespace 
//understanding '**' iteration 
root.'**'.each{println it.name()}
//Give me title which contains 'Dream'
root.'**'.findAll{ it.title.text().contains('Dream')}.each{println it.title}
//Give me titles where year >= 1594
root.'**'.findAll{ n->
    def v = null
    try{
         v = n.year.toInteger()
       } catch(Exception){    
      }
    v >= 1594
}.each{ println it.title}
//groovy shortcut 
root.'**'.findAll{ n->
     n.year?.toInteger() >= 1594 ?: false        
}.each{ println it.title}

//building
def wr = new StringWriter()
def xml = new MarkupBuilder(wr)
xml.bibliography{
    author 'William Shakespeare'
    play {
        year '1595'
        title ([lang:'esp'],'A Midsummer-Nights Dream')
    }
}
wr.toString()






