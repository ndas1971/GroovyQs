//Safe navigation
//@groovy.transform.Field String x = "ABC"
String x = "ABC"
x?.size()
//Elvis operation - ?:
def length = x ? x.size() : 0
length = x?.size() ?: 0 

//method to closure conversion - this.&
def lst = [1,2,3]
def p(y){
    println y
}
lst.each(this.&p)
def pst = [2,3,4]
(lst + pst).each(this.&p)
