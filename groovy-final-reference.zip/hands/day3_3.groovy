//import java.util.*  //by default groovy imports 
def d = new Date()
d.toString()
d.class.methods

import groovy.time.*

use(TimeCategory){
    println 1.minute.from.now 
    println 10.hours.ago
    def now = new Date()
    println now-3.months
    println now + 1.week - 4.days + 2.hours -3.seconds
    def d2 = now + 6.days
    println d2.format('yyyy-MM-dd')
    def future = new Date(2020-1900, 0, 0)
    println future.format('yyyy-MMM-dd')
}
///How to implement Category 
class NumberCategory{
    static String getMeters(Number self){
        self.toString()+"m"
    }
   static String getKm(Number self){
        self.toString()+"km"
    }
    static String getCap(String self){
        def str = self.toLowerCase()
        def mid = (str.size()/2).toInteger()
        str[0..<mid] + str[mid].toUpperCase() + str[mid+1..<str.size()]
    }
}
use(NumberCategory){
    println 1.meters  //1.getMeters()
    println 1.km      //1.Km()
    println "abc".cap
}
