def timer = new Timer()

timer.schedule(
    new TimerTask(){
        void run(){
            println "1 executed"
        }
    }, 1000)  //scheduling after 1sec 
    
//repeated 
timer.schedule(
    new TimerTask(){
        void run(){
            println "2 executed @ ${new Date()}"
        }
    }, 0, 1000)
