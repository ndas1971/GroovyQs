//Given a directory, Find the fileName with maxsize 

def filesList(dir){
    def files = new File(dir).listFiles()
    def only_files = files.findAll{it.isFile()}
    def dirs = files.findAll{it.isDirectory()}
    def subfiles = dirs.collectMany{subdir ->
            filesList(dir + "/" + subdir.name)
        }
    only_files + subfiles
}
def dir = /D:\Desktop\PPT\Groovy\hands/
//file Name with max size 
def filesWithSize = filesList(dir).collectEntries{
    [it.path, it.length()]}
filesWithSize.sort{kv -> kv.value}.collect{[it.key, it.value]}[-1]
//dirs with dir size 
filesWithSize = filesList(dir).collectEntries{
    [it.path, [it.parent, it.length()]]}
filesWithSize.groupBy{it.value[0]}
             .collectEntries{k,v -> [k, v.collect{it.value[1]}.sum()]}
filesWithSize.sort{kv -> kv.value}.collect{[it.key, it.value]}[-1]