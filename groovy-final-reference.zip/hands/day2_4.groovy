//functions taking closure - HOF
def lst = [1,2,3]
def map = [ok:1, nok:2]
//each 
lst.each{println it}
map.each{k,v -> println k}
//collect
lst.collect{it*it} // [1,4,9]
map.collect{k, v -> v*v} //[1,4]
//findAll 
lst.findAll{ it % 2 ==1 } //[1,3]
lst.findAll{ it % 2 ==1 }.collect{it*it} //[1,9]
//collectMany 
lst.collectMany{ [ it, it*it, it*it*it]} //[1, 1, 1, 2, 4, 8, 3, 9, 27]
lst.collect{ [ it, it*it, it*it*it]} //[[1, 1, 1], [2, 4, 8], [3, 9, 27]]
//or
lst.collect{ [ it, it*it, it*it*it]}.flatten()
//collectEntries - collect and then toMap 
lst.collectEntries{[it, it*it]} // [1:1, 2:4, 3:9]
//count
lst.count{ e -> e%2 == 1 } //2
//freq of each char in a string
def str = "Hello World"
str.toList().collectEntries{ch -> [ch, str.toList().count{it==ch}]}
// [H:1, e:1, l:3, o:2,  :1, W:1, r:1, d:1]
str.toList()
//sort, false means return a new copy 
['aa', 'b','xyz', 'c'].sort(false){it} //[aa, b, c, xyz]
['aa', 'b','xyz', 'c'].sort(false){it.size()} //[b, c, aa, xyz]
map.sort{kv -> kv.value} //based on value 
map.sort{kv -> kv.key}  //based on value 
//min,max 
['aa', 'b','xyz', 'c'].min{it.size()} //b
['aa', 'b','xyz', 'c'].max{it.size()} //'xyz'
//groupby 
lst.groupBy{it%2}  //[1:[1, 3], 0:[2]]
//inject 
lst.inject(0){r,e -> r+e}  //6 , p = { r,e -> r+e}
// lst = [1,2,3]
// (((0+1)+2)+3)  // p(p(p(0,1),2),3)
//transpose
[['a', 'b'], [10,11] ].transpose() //[[a, 10], [b, 11]]
['a', 'b'].withIndex()  //[[a, 0], [b, 1]]
['a', 'b'].join(" ") // "a b"











