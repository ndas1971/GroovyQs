// multiple assignment
def (aa, bb) = [1,2]
println "$aa $bb"
(aa, bb) = [bb,aa]
println "$aa $bb"

//
//def a = 1G
//111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111 
//a = 2L 
//a = 3 
//a = 3.2 
//a = 3.5D 
//a = 3.6f 
//println "${a*a}"
//println a.class

//function 
def add(x,y){
    def z = x+y
    //return z
    z
}




def result = add(2,3)  //positional arg passing
add(y=3, x=2)  //keyword arg passing 
add(2, y=3) //mix of two style.. but positional should come first




def add2(x,y=20){
    def z = x+y
    //return z
    z
}
//add2(2)
add2(2,10)
//var args 
def sum(Integer... args){
    println args
}
sum(1)
sum(1,2)
sum(1,2,3,4,5,6)

//overloading 
def f(x){
    return "x"
}
def f(x,y){
    return "x,y"
}
f(2,3)
f(10)

//Closure 
def add3 = { x, y=20 -> 
                   def z = x+y
                   z
                }                
println add3(2,3)
println add3(2)
def fx = { x -> x*2} //1
fx(3)
fx = {2 * it } //equal to 1
fx(2)
fx = { -> 0 }
fx()
//times(Closure closure)
2.times{
    println "${it}: hello"
}
2.times({ x ->
    println "${x}: hello"
})

//Understand Number.step and use it 
//void Number.step(Number to, Number stepNumber, Closure closure)
2.step(10, 2){
    println it + 10
}
//Understand Number.downto(Number to, Closure closure) and use it 
10.downto(2){
    println it
}
//upto
2.upto(10){ x ->
    println x
}

//find pythogorous triplet under 100 
def limit = 99
3.upto(limit){ x ->
    x.upto(limit){ y ->
        y.upto(limit){ z ->
            if( z*z == x*x + y*y){
                println "($x,$y,$z)"
            }
        }
    }
} //99*99*99









