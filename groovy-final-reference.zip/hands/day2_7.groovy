import groovy.json.*
def j = new JsonSlurper()
def obj = j.parse(new File(/D:\Desktop\PPT\Groovy\hands\data\emp.json/))
//get all firstName
obj.collect{it.details.firstName}
//shortcut- GPATH
obj.details.firstName
//fullName 
obj.details.collect{it.firstName + it.lastName}
//Get all office phone numbers
obj.details.phoneNumbers.collectMany{ar ->
    ar.findAll{it.type == 'office'}.collect{it.number}
}
//building json
def jb = new JsonBuilder()
jb.records{
    car{
        name "Honda"
        make "Honda"
        year  2006,2007,2008
        record{
            type 'speed'
            description 'ok'
        }
    }
}
jb.toPrettyString()
//{"records":{"car":{"name":"Honda","make":"Honda","year":[2006,2007,2008],"record":{"type":"speed","description":"ok"}}}
