//String 
s = 'hello world'
s = "Hello World"
s = """Hello
World"""
s == "Hello\nWorld" //true 

s2 = s + "OK"  //concatenation
//Use casting for Character
ch = 'A' as char 
ch = (char)'A'
ch.class 

//slashy string 
s1 = "\n"
s1.size()  //1
s2 = /\n/ //raw string, no meaning escape sequence 
s2.size() //2

//other methods 
s = "Hello World"
s.size()
s.contains("He") //true 
s == "OK"  //false
//iteration
for (ch in s){
    println ch 
}
//HandsON 
s = "Hello World"
/*
H - 1
e - 1
l - 3

For each ch from s 
    initialize counter 
    for each ch1 from s 
        if ch and ch1 are same 
            increment counter
    print ch and it's counter
*/
def freq(s){
    for (ch in s){
        count = 0 
        for (ch1 in s){
            if (ch == ch1)
                count++
        }
        println("$ch -> $count")
    }
}
freq(s)
//check GDK 
s = "Hello World"
s[0]   //indexing 
s[-1]  //from the end 
s[-s.size()]
//slicing
s[0..2]  // 2 is enclusive 
s[0..<2]
s[-1..-s.size()] //reversing

//trim, split 
//toUpperCase, startsWith 
"  Hello  ".trim()  //"Hello"
"Hello:World".split(":") // [ "Hello", "World"]

//command from gdk 
p = "systeminfo".execute()
//println(p.getText().size())
println(p.text.size())

//download 
url = "http://www.google.com"
println(url.toURL().text.size()) //.getText()












