//JSON
import groovy.json.* 

def s = new JsonSlurper()
def json = s.parse(new File("../data/example.json")) //parseText(str)
//{details={person={name=John Doe, age=40, cars=[bmw, ford]}}}
json.details.person.name
json.details.person.cars[0]

//complex 
json = s.parse(new File("../data/example-o.json"))
//Result: {details=[{person={name=John Doe, age=40, cars=[bmw, ford]}}, {person={name=John Doe, age=42, cars=[bmw, ford]}}, {person={name=John Doe, age=45, cars=[bmw, ford]}}, {person={name=John Doe, age=45, cars=[honda, toyota]}}, {person={name=John Doe, age=46, cars=[bmw, ford]}}, {person={name=John Doe, age=47, cars=[nano, audi]}}]}
json.details.collect{it.person}.collect{it.age}
//spread
json.details*.person*.age
//GPATH
json.details.person.age
//All unique Cars?
json.details.person.cars.flatten().toSet()
//all unique cars when age >=45?
json.details.person.findAll{it.age >= 45}.cars.flatten().toSet()

//Building 
def builder = new JsonBuilder()
builder.records {
   car {
        name "bmw"
        year 1970,1980
     }
}
def str = builder.toString()
//{"records":{"car":{"name":"bmw","year":[1970,1980]}}}

//from groovy map to Json 
def o = [ ok: [1,2,3], nok: [4,5,6]]
new JsonBuilder(o).toString() // {"ok":[1,2,3],"nok":[4,5,6]}

//XML - XmlParser, XmlSlurper 
//.name() , .text(), .@attributeKey, ["@attributeKey"]

def xml = new XmlParser().parse(new File("../data/books.xml"))

xml.value.books.book.title.text()
xml.value.books.book[0].title.text()
xml.value.books.book.@id  
xml.value.books.book.author.@id  
xml.value.books.book.findAll{it.@available.toInteger() >= 14}.author*.@id

//Building 
import groovy.xml.* 
def wr = new StringWriter()
builder = new MarkupBuilder(wr)

builder.books{
    author 'Somebody'
    company {
        status(['published':'yes'], 1970)
    }
}

wr.toString()
/*
 <books>
  <author>Somebody</author>
  <company>
    <status published='yes'>1970</status>
  </company>
</books>
*/

//HTML
@Grab(group= 'org.ccil.cowan.tagsoup', module= 'tagsoup', version= '1.2')
import org.ccil.cowan.tagsoup.Parser

def url = "http://www.google.com"
str = url.toURL().text
def html = new XmlParser(new Parser()).parseText(str)
html.body.'**'.a.@href  //.'**'  means  //  

//GET - REST call 
@Grab(group='io.github.http-builder-ng', module='http-builder-ng-core', version='1.0.3')
import static groovyx.net.http.HttpBuilder.configure 
//Text, CSV, XML, JSON and HTML if  jsoup is in path 

def http = configure{
    request.uri = "http://httpbin.org"
}

def result = http.get{
    request.uri.path = "/get"
}
println result.headers  //result is in json 
//[args:[:], headers:[Accept:text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2, Accept-Encoding:gzip, deflate, Host:httpbin.org, User-Agent:Java/1.8.0_65], origin:157.33.156.20, 157.33.156.20, url:https://httpbin.org/get]


result = http.post{
    request.uri.path = "/post"
    request.contentType = "application/json"
    request.body = [user:"XYZ", age: 20]
}
println result.headers  //result is in json 
//[Accept:text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2, Accept-Encoding:gzip, deflate, Content-Length:23, Content-Type:application/json; charset=utf-8, Host:httpbin.org, User-Agent:Java/1.8.0_



















//XML