//HOF : higher order function 
//function takes Closure as arg 
//Currying :  function returns a Closure 
//Partial application : functin takes many args => curry form with all except one applied 
// Compose :  call functions one after another 
//memoize  : DP , creating cache of used args 
//TCO : tail call optimization , in groovy trampoline 
def lst = [ 1, 2, 3, 4, 5]
// List findAll(Closure closure)  //filter
lst.findAll{ it > 3 }
lst.findAll{ e -> e > 3 } //[4,5]
// List collect(Closure transform)  //map
lst.collect { it* it }   //[1,4,9,16,25]]
lst.collect{ e -> e*e}
//filter+map 
lst.findAll{ e -> e > 3 }.collect{ e -> e*e}//[16,25]
//Object inject(Object initialValue, Closure closure)  //reduce 
lst.inject(0){r,e -> r+e}  //actually sum 
lst.inject([]){r,e -> r + [e*e]} //map
//List collectMany(Closure projection) // flatmap 
lst.collect{ e -> [e*e]}      //[[1], [4], [9], [16], [25]]
lst.collectMany{ e -> [e*e]}  //[1, 4, 9, 16, 25]
// Map collectEntries(Closure transform)
lst.collectEntries{ e -> [e, e*e]} //[1:1, 2:4, 3:9, 4:16, 5:25]

//Number count(Closure closure)
def s = "Hello World"
s.toList().collectEntries{e -> [e, s.toList().count{e1 -> e == e1}]}
//[H:1, e:1, l:3, o:2,  :1, W:1, r:1, d:1]
s.split(/\s+/).collectEntries{e -> [e, s.split(/\s+/).count{e1 -> e == e1}]}
//[Hello:1, World:1]

//Map countBy(Closure closure)


def lsts = [ 'a', 'abc', 'bb','b', 'xyzl']
// Object sum(Closure closure)
lsts.sum{ e -> e.size()} //10
//Object max(Closure closure)
lsts.max{ e -> e.size()}  //'xyzl'
// Collection takeWhile(Closure condition)
lsts.takeWhile{ e -> e.size() == 1} //[a]
lsts.findAll{ e -> e.size() == 1} //[a,b]
// Collection dropWhile(Closure condition)
lsts.dropWhile{ e -> e.size() == 1}  //[abc, bb, b, xyzl]
// boolean  every(Closure predicate) //all 
// boolean     any(Closure predicate)
lsts.every{e -> e.size() == 2} //false 
lsts.any{e -> e.size() == 2} //true 

// List sort(boolean mutate, Closure closure) 
lsts.sort(false)  //false, means return new list , true = inplace 
//[a, abc, b, bb, xyzl]
lsts.sort(false) { e -> e.size()}
//[a, b, bb, abc, xyzl]
//Map countBy(Closure closure)
lsts.countBy{ e -> e.size()}  // [1:2, 3:1, 2:1, 4:1]
// Map groupBy(Closure closure) 
lsts.groupBy{ e -> e.size()} //[1:[a, b], 3:[abc], 2:[bb], 4:[xyzl]]
lsts.groupBy{ e -> e.size()}.collectEntries{e -> [e.key, e.value.size()]}
//[1:2, 3:1, 2:1, 4:1]
//Map groupBy(Object closures)
lsts.groupBy({ e -> e.size()}, {it.size() % 2} )
//[1:[1:[a, b]], 3:[1:[abc]], 2:[0:[bb]], 4:[0:[xyzl]]]

//withIndex 
lsts.withIndex()  //[[a, 0], [abc, 1], [bb, 2], [b, 3], [xyzl, 4]]
lsts.withIndex().collect{ [it.last(), it.head()]}
//join, take, drop, head, last, tail, init 
lst = [1,2,3,4]
lst.head()   //1 
lst.tail()  // [2,3,4]
lst.last()  //4
lst.init()  //[1,2,3]
lst.take(2) //[1,2]
lst.drop(1).take(1) //[2]
lst.join(",") //"1,2,3,4"
lst.join(",").split(",").collect{ it.toInteger()} //[1,2,3,4]


///Lazy list
lst = (0..10).toList()
def lst1 = lst.stream().filter{it > 5}.map{ it*it} //lazy 
//java.util.stream.ReferencePipeline$3@1d8b1c1
lst1.collect()//[36, 49, 64, 81, 100]

///Map Functional 
//arg kv , kv.key or kv.value 
//arg k,v 
//collect , collectEntries
def m1 = [ ok:1, nok:10]
m1.collect{ kv -> kv.key}  //collecting keys //[ok, nok]
m1.collectEntries{ kv -> [kv.key, kv.value*kv.value]}  //[ok:1, nok:100]
//findAll 
m1.findAll{ kv -> kv.key.size() > 2}  //[nok:10]
m1.findAll{ k,v -> k.size() > 2} //[nok:10]
//each 
m1.each{ k,v -> println "$k=$v"}
//inject
m1.inject(0){ r, k, v ->  r+v} //11
//sort by 
m1.sort{kv -> kv.value} //[ok:1, nok:10]
m1.sort{kv -> -kv.value}  //[nok:10, ok:1]





///File 
File f = new File(/..\first2.groovy/) //writing 
f.text = "First line"  //file opened and closed 
f << "\n2nd line\n" << "3rd line"  //append 

//reading 
f.text //full file in one string 
f.eachLine{ line ->
    println line 
}
f.readLines()  //each line in a list 
//copying
def f2 = new File("../first.groovy")
def f3 = new File("../first.groovy.bk")

f3.withPrintWriter{ wr ->
    f2.eachLine{ line ->
        wr.println(line)
    }
}

//HandsOn - finding max line 
def file = new File("../first.groovy")
file.readLines().withIndex().collect{ line, index ->
        [line.size(), index+1]
    }.sort(false){si -> si[0]}.last().last() //line 11 
     
     
//in = stdout of process , err=stderr of process, out=stdin of process
def lines = "systeminfo".execute().in.readLines()
//latest hotfix installed 
lines.findAll{ it.contains("KB") }.collect{ 
        it.split("KB").last().trim().split("_").head().toInteger()
        }.max() //4038806

      
///Handson - total dir size given a dir 




















