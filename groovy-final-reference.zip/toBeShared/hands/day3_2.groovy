//metaClass
@groovy.transform.Canonical
class Person{
    String firstName 
    String secondName
}

def pmg = new Person("XYZ", "ABC")
pmg.metaClass.fullName = { -> "$firstName $secondName"}
println pmg.fullName()

//it is not applicable for any other instances 
def pmg1 = new Person("DFE", "LMJ")
//println pmg1.fullName()  //Exception

//class 
Person.metaClass.fullName << { -> "$firstName $secondName"}
Person.metaClass.fullName << { String pre-> "$pre $firstName $secondName"}
Person.metaClass{
    greet { ->  "Hello ${fullName()}"}
    //another one     
}
//similarly can inject 'constructor' and property/static property 
Person.metaClass.'static'.whatIsMyType << { -> Person }
def pmg2 = new Person("DFE", "LMJ")
println pmg2.fullName()
println pmg2.fullName("Mr.")
println pmg2.greet()
println Person.whatIsMyType()

//For builtin Classes
ExpandoMetaClass.enableGlobally()
List.metaClass.sizeDoubled << { -> delegate.size() * 2}
List.metaClass.freq << { -> delegate.collectEntries{ e -> [e, delegate.count{ it == e}] } }

def lst = [1,2,3,1,2,1]
println "${lst.size()} ${lst.sizeDoubled()}"
println "${lst.freq()}" //[1:3, 2:2, 3:1]























