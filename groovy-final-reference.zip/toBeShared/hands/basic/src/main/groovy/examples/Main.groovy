package examples 
import grails.spring.BeanBuilder 

@groovy.transform.ToString(includeNames=true)
class Login{
    def authorize(User user){
        println user 
    }
}
@groovy.transform.Canonical
@groovy.transform.ToString(includeNames=true)
class User{
    String name 
    Credentials cre
}
@groovy.transform.Canonical
@groovy.transform.ToString(includeNames=true)
class Credentials{
    String username 
    String password
}

class Main{
    static void main(String[] args){
        //def p = new Person(name:"XYZ")
        //println p
        //println 3.triple
        beanDemo()
    }
    static void beanDemo(){
        def bb= new BeanBuilder()
        bb.beans{
            login(Login)
            user(User){ bean ->
                cre = new Credentials("me","guess")
                name = "Xyz Der"
            }        
        }
        
        def ctx = bb.createApplicationContext()
        
        def l = ctx.getBean("login")
        def u = ctx.getBean("user")
        l.authorize(u)       
    
    }
}


