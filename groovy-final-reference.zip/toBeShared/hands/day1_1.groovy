int a = 1
println(a.class)  //a.getClass() //java.lang.Integer
f = 1.2d
println(f.class)
b = true 
println b.class 
s = "OK"
println s.class

//operations 
c = a + 1
g = f/2 
println "$c $g"

s == "OK"
s == "OK" && a == 1
s == "OK" || a == 1
!(s != "OK")
//convert 
"1".toInteger() //toDouble(), toBigDecimal()// from gdk
1.2.toInteger()
//if - true is anything which is not empty , "" , 0 -> false 
if ( a >= 1){
    println a 
} else if ( a < 1) {
    println a 
} else {
    println "true"
}
//HandsON 
/*
define two variables , name and age 
if name is "XYZ" and age is below 40, 
print "suitable" 
else if age is greater than 50, print "old", 
else print "OK"
For all other names, print "not known" 
*/
//While
def c = 0 
while (c < 3){
    println c 
    c++
}

//for 
for(e in 1..10){ //1..10 is called Range 
    println(e) 
}
slc = "Hello World"
for (e in slc){
    println e
}
//multiple assignments 
def (aa,bb) = [1,2]
println "$aa $bb"
(bb,aa) = [aa,bb]
println "$aa $bb"

//Closure

def fxc = {x -> x*x }
fxc(2)

fxc = { it * it }   //it is keyword, single arg closure 
fxc(2)

fxc = { -> println("OK")}
fxc = { x,y, z=30 ->        //multiline and default 
                cv = x+y+z 
                println(cv)
                cv    //last line is return
       }
x = fxc(1,2)
