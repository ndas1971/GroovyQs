//operator overload
class Operator implements Comparable<Operator>{
    def plus(other) {
        println("plus")
    }
    def call(Integer... args){
        println("call")
    }
    int compareTo(other){
        println("compareTo")
        1
    }
}

def o1 = new Operator()
def o2 = new Operator()

o1 + o2 
o1(1,2,3,4)
o1 == o2 
o1 > o2 
//interface is same as java, in Groovy we have trait 
//abstract class is same as java , static inner class is same as java 
//nonstatic inner class is completly changed in usage in groovy- better to avoid 

//Anonymous object is similar 
//import java.util.concurrent.* 
//Timer timer = new Timer()
//timer.schedule(
//    new TimerTask(){
//        void run(){
//            println "executed"
//       }
//    }, 1000)  //millis delay 

//trait 
trait Greet{
    abstract String name()
    def greet() { "hello ${name()}"}
}
class Person{
    String surname
    String firstName
}
class PersonG extends Person implements Greet{
    String name() { "${this.firstName} $surname" }
}
def pg = new PersonG(surname:"X", firstName:"Y")
println pg.greet()
//runtime mixing 
trait Name{
    String name() {"$firstName $surname"}
}
def pg1 = new Person(surname:"X", firstName:"Y")
def pgg1 = pg1.withTraits Name, Greet 
println pgg1.greet()
//stackable trait 
trait Log{
    String name() {
        println "LOG>>> something "
        def res = super.name()
        println "LOG>>> happned"
        res
    }
}
def pgg2 = pg1.withTraits Name, Log, Greet // search from here 
println pgg2.greet()
//anonymous object with trait not possible 
//SAM 
def pg2 = { -> "Hello" } as Greet 
println pg2.greet()

//MAM 
def pg3 = [name :{ -> "Again hello"}] as Greet 
println pg3.greet()

//Delegate 
@groovy.transform.Canonical
class Event{
    String title 
    @Delegate Date when //all methods of Date would be proxied to 'when'
}
def ev = new Event("XYZ", Date.parse('yyyy/MM/dd', '2014/08/08'))
println ev.title 
Date.methods.name 
def now = new Date() //current time
println ev.before(now)//true  //ev.when.before(now)
ev.class.methods.name
//Categories 

use(groovy.time.TimeCategory){
    println 1.minute.from.now 
    println 10.hours.ago
    def n = new Date()
    println(n - 3.months)
}

class Distance{
    def n
    String toString() {"${n}m"}
}

@Category(Number)
class NumberCategory{
    Distance getMeters(){
        new Distance (n:this)
    }
}
use(NumberCategory){
    println 20.meters //20m
}
//Another sytax for extension methods/catgeories
class NumberToDouble{
    static Double getDouble(Integer self){
        self.toDouble()
    }
}
use(NumberToDouble){
    println 20.double 
}









































