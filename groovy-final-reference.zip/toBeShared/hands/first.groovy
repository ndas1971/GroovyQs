@GrabConfig(systemClassLoader=true)
@Grab(value='org.jsoup:jsoup:1.9.2', initClass=true)
@Grab('io.github.http-builder-ng:http-builder-ng-core:0.14.1')
@GrabExclude('org.codehaus.groovy:groovy-all')

import static groovyx.net.http.HttpBuilder.configure
import org.jsoup.nodes.Document
import groovyx.net.http.optional.Html

Document page = configure {
    request.uri = 'https://mvnrepository.com/artifact/org.codehaus.groovy/groovy-all'
}.get()

String license = page.select('span.b.lic').collect { it.text() }.join(', ')

println "Groovy is licensed under: ${license}"