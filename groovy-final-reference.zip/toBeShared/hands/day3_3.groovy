//a b c d  => a(b).c(d) 
//please show the square_root of 100 
//please(show).the(square_root).of(100)
// lst.findAll(..).collect().each(..)
//m = [ok: {x -> x*x}]
//m.ok(2)

import static java.lang.Math.* 

def show = { println it}
def square_root = { sqrt(it) }

def please = {displayFn ->
    [ the : { actionFn ->
                [ of : { val -> displayFn(actionFn(val))}]
             }
    ]
}
//DSL show(square_root(100))
please show the square_root of 100
//please add(2,3) then minus with 16 
//please show the sum of 2,3 then minus with 16 

def minus = {x,y -> x-y  }
def sum = {Integer... args -> args.toList().sum() }
please = {displayFn ->
    [ the : { actionFn ->
                [ of : { Integer... args  -> 
                       [ then: { actionFn2 -> 
                                [with: {val -> displayFn(actionFn2(actionFn(*args),val)) }]
                       }]
                }]
             }
    ]
}
please show the sum of 2,3,3,4,6 then minus with 16 //2
//DSL2
def sendmail() {
    email {
        from     "das@company.name"
        to       "somebody@another.name"
        subject  "Hello"
        header   "X=Y","Z=Z"
        authentication  "XYZVBGRT"
        body {
            header()
            p "Yes, How are you?"
            h1 "Br ..."    
            footer()   
        }   
    }
}

def email(Closure cl){
    def  del = new EmailSpec()
    def nc = cl.rehydrate(del, null, null) //basically doing  cl.delegate = del 
    nc.resolveStrategy = Closure.DELEGATE_ONLY
    nc()
}

class EmailSpec{
    def from(String arg) {println "From:$arg" }
    def to(String arg) {println "To:$arg" }
    def subject(String arg) {println "Subject:$arg" }
    def body(String arg) {println "------\n$arg\n-----" }
    def body(Closure cl) {
        def  del = new BodySpec()
        def nc = cl.rehydrate(del, null, null) //basically doing  cl.delegate = del 
        nc.resolveStrategy = Closure.DELEGATE_ONLY
        nc()
    }
    def methodMissing(String name, args){
        println "${name.toUpperCase()} ${args.join(",")}"
    }
}
class BodySpec{
    def header() { println "<html><body>"}
    def footer() { println "</body></html>"}
    def methodMissing(String name, args){
        println "<${name}> ${args.join(",")} </${name}>"
    }
}

sendmail()


/*
From:das@company.name
To:somebody@another.name
Subject:Hello
HEADER X=Y,Z=Z
AUTHENTICATION XYZVBGRT
<html><body>
<p>Yes, How are you?</p>
<h1>Br ...</h1>
</body></html>
*/















