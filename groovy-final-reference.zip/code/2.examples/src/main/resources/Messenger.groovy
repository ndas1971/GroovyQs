package groovy.refresh;

// import the Messenger interface (written in Java) that is to be implemented
import examples.*

// define the implementation in Groovy
class GroovyMessenger implements Messenger {
    String message = "Hello !"
}