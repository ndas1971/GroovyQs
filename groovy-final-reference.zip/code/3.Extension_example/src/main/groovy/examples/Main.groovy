package examples


class Main {
    public static void main(String[] args){
       String originalText = "Hi, Groovy is the greatest language of the JVM."
       println originalText.likeAPirate()
       //static 
       println String.talkLikeAPirate()       
    }
}
