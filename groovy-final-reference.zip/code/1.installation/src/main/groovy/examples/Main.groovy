package examples


class Main {
    public static void main(String[] args){
        println("hello $args")
    }
}